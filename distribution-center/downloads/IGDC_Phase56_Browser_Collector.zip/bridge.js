'use strict';
(()=>{
 const origin=location.origin;
 const reply=(id,data)=>window.postMessage({channel:'igdc55-extension',id,...data},origin);
 window.addEventListener('message',async e=>{
  const m=e.data;if(e.source!==window||e.origin!==origin||m?.channel!=='igdc55-admin'||!(/^[a-f0-9-]{36}$/.test(m.id||''))||!['ping','start','cancel'].includes(m.action))return;
  try{const result=await chrome.runtime.sendMessage({action:m.action,id:m.id,url:m.url});reply(m.id,result||{ok:false,error:'연결 응답 없음'});}catch{reply(m.id,{ok:false,error:'확장 프로그램을 다시 설치하거나 관리자 화면을 새로고침하세요.'});}
 });
 chrome.runtime.onMessage.addListener((m,sender)=>{if(sender.id===chrome.runtime.id&&m?.action==='result')reply(m.id,{finished:true,...m.result});});
})();

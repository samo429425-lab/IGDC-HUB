'use strict';
const admin=u=>{try{const x=new URL(u);return ['https://igdcglobal.com','https://www.igdcglobal.com'].includes(x.origin)&&x.pathname.startsWith('/distribution-center/');}catch{return false;}};
const target=u=>{try{const x=new URL(u);if(x.protocol!=='https:'||x.username||x.password||x.port||!x.hostname.includes('.')||/^\d|^\[|\.(local|internal|localhost|test|invalid|lan|home)$/i.test(x.hostname)||admin(x.href))return '';x.hash='';return x.href;}catch{return '';}};
const key=id=>'job:'+id;
const validId=id=>typeof id==='string'&&/^[a-f0-9-]{36}$/.test(id);
let queue=Promise.resolve();
chrome.runtime.onMessage.addListener((m,s,respond)=>{
 const task=async()=>{
  if(!validId(m?.id))throw Error('요청 식별자 오류');
  if(['ping','start','cancel'].includes(m.action)){
   if(!admin(s.url)||!s.tab?.id)throw Error('IGDC 관리자 화면에서만 실행 가능합니다.');
   if(m.action==='ping')return {ok:true,version:56};
   if(m.action==='cancel'){const job=(await chrome.storage.session.get(key(m.id)))[key(m.id)];if(job&&(job.tab!==s.tab.id||job.frame!==(s.frameId||0)))throw Error('다른 관리 화면의 수집 요청입니다.');if(job){await chrome.storage.session.remove(key(m.id));if(job.collectTab)try{await chrome.tabs.remove(job.collectTab);}catch{}}return {ok:true,version:56,cancelled:true};}
   const url=target(m.url);if(!url)throw Error('공개 HTTPS 상품 주소를 확인하세요.');
   const all=await chrome.storage.session.get(null);const expired=Object.keys(all).filter(k=>k.startsWith('job:')&&Date.now()-all[k].at>600000);if(expired.length)await chrome.storage.session.remove(expired);
   if(all[key(m.id)])throw Error('중복 요청');
   if(Object.values(all).some(j=>j?.tab===s.tab.id&&j?.frame===(s.frameId||0)&&Date.now()-j.at<600000))throw Error('기존 수집 창을 완료하거나 닫은 뒤 다시 시도하세요.');
   const job={url,tab:s.tab.id,frame:s.frameId||0,at:Date.now()};await chrome.storage.session.set({[key(m.id)]:job});
   try{const t=await chrome.tabs.create({url:chrome.runtime.getURL('collect.html')+'?id='+m.id});job.collectTab=t.id;await chrome.storage.session.set({[key(m.id)]:job});}catch(e){await chrome.storage.session.remove(key(m.id));throw e;}
   return {ok:true,started:true,version:56};
  }
  if(!s.url?.startsWith(chrome.runtime.getURL('collect.html')+'?'))throw Error('수집 도구 요청 오류');
  const job=(await chrome.storage.session.get(key(m.id)))[key(m.id)];if(!job||Date.now()-job.at>600000||job.collectTab!==s.tab?.id)throw Error('수집 요청 만료 또는 변경');
  if(m.action==='get')return {ok:true,url:job.url};
  if(m.action==='finish'){
   const result=m.result;if(!result||typeof result.ok!=='boolean'||JSON.stringify(result).length>1000000)throw Error('수집 결과 형식 오류');
   await chrome.storage.session.remove(key(m.id));await chrome.tabs.sendMessage(job.tab,{action:'result',id:m.id,result},{frameId:job.frame});return {ok:true};
  }throw Error('지원하지 않는 명령');
 };const run=queue.then(task);queue=run.catch(()=>{});run.then(respond,e=>respond({ok:false,error:String(e.message||e).slice(0,250)}));return true;
});
chrome.tabs.onRemoved.addListener(tab=>{queue=queue.then(async()=>{const all=await chrome.storage.session.get(null);for(const [k,j] of Object.entries(all)){if(!k.startsWith('job:')||!(j.tab===tab||j.collectTab===tab))continue;await chrome.storage.session.remove(k);if(j.collectTab===tab)try{await chrome.tabs.sendMessage(j.tab,{action:'result',id:k.slice(4),result:{ok:false,error:'수집 창을 닫았습니다.'}},{frameId:j.frame});}catch{}}}).catch(()=>{});return queue;});

'use strict';
const $=id=>document.getElementById(id),id=new URLSearchParams(location.search).get('id');let url='',tab=null,busy=false;
const msg=(action,extra={})=>chrome.runtime.sendMessage({action,id,...extra});
const status=t=>{$('status').textContent=t;};
const update=()=>{$('open').disabled=!url||busy||!!tab;$('run').disabled=!tab||busy||!$('permit').checked;};
$('permit').onchange=update;
(async()=>{try{let r=await msg('get');if(!r.ok){await new Promise(r=>setTimeout(r,350));r=await msg('get');}if(!r.ok)throw Error(r.error);url=r.url;$('url').textContent=url;status('상품 페이지 열기를 누르세요.');update();}catch(e){status(e.message);}})();
$('open').onclick=async()=>{try{const t=await chrome.tabs.create({url,active:true});tab=t.id;status('상품 페이지를 확인한 뒤 이 수집 탭으로 돌아와 가져오기를 누르세요.');update();}catch(e){status(e.message);}};
$('run').onclick=async()=>{if(busy||!tab||!$('permit').checked)return;busy=true;update();const pattern=new URL(url).origin+'/*';try{
 const granted=await chrome.permissions.request({origins:[pattern]});if(!granted)throw Error('사이트 접근 권한이 승인되지 않았습니다.');
 let t;try{t=await chrome.tabs.get(tab);}catch{tab=null;throw Error('상품 페이지가 닫혔습니다. 다시 상품 페이지 열기를 누르세요.');}if(t.status!=='complete')throw Error('상품 페이지 로딩 완료 후 다시 시도하세요.');if(new URL(t.url).origin!==new URL(url).origin)throw Error('다른 사이트로 이동했습니다. IGDC에서 해당 출처를 선택하세요.');
 await chrome.scripting.executeScript({target:{tabId:tab},files:['source-profile-core.js','capture-core.js']});
 const [r]=await chrome.scripting.executeScript({target:{tabId:tab},func:()=>window.DCenterCapture.fromDocument(document,location.href)});const packet=r?.result;if(!packet||!Array.isArray(packet.records)||!packet.records.length)throw Error('상품 자료 없음. 실제 상품 상세 페이지를 열고 다시 시도하세요.');if(new URL(packet.page_url).origin!==new URL(url).origin)throw Error('수집 출처 변경');packet.permission_confirmed=true;
 const result=await msg('finish',{result:{ok:true,packet}});if(!result.ok)throw Error(result.error);status('IGDC 관리자 화면으로 '+packet.records.length+'개 자료를 전달했습니다. 관리자 화면에서 확인하세요.');url='';tab=null; $('cancel').textContent='닫기'; $('cancel').onclick=()=>window.close();
 }catch(e){status(e.message||'수집 실패');}finally{busy=false;update();}};
$('cancel').onclick=async()=>{try{await msg('finish',{result:{ok:false,error:'사용자 취소'}});window.close();}catch(e){status(e.message);}};

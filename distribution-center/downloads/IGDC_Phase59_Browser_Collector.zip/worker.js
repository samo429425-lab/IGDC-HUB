'use strict';
const admin=u=>{try{const x=new URL(u);return ['https://igdcglobal.com','https://www.igdcglobal.com'].includes(x.origin)&&x.pathname.startsWith('/distribution-center/');}catch{return false;}};
const target=u=>{try{const x=new URL(u);if(x.protocol!=='https:'||x.username||x.password||x.port||!x.hostname.includes('.')||/^\d|^\[|\.(local|internal|localhost|test|invalid|lan|home|example)$/i.test(x.hostname)||admin(x.href)||x.href.length>2048)return '';x.hash='';return x.href;}catch{return '';}};
const key=id=>'job:'+id,ttl=1200000;
const validId=id=>typeof id==='string'&&/^[a-f0-9-]{36}$/.test(id);
const get=async id=>(await chrome.storage.session.get(key(id)))[key(id)];
const save=(id,j)=>chrome.storage.session.set({[key(id)]:j});
async function focus(id){try{const t=await chrome.tabs.update(id,{active:true});if(t?.windowId!=null)await chrome.windows.update(t.windowId,{focused:true});}catch{}}
async function close(id){if(id!=null)try{await chrome.tabs.remove(id);}catch{}}
async function discard(id,j,returnToAdmin=false){await chrome.storage.session.remove(key(id));if(returnToAdmin)await focus(j.tab);await close(j.sourceTab);await close(j.collectTab);}
async function notify(id,j){if(!j.result)return;try{await chrome.tabs.sendMessage(j.tab,{action:'result',id,result:j.result},{frameId:j.frame});}catch{/* retained for polling */}}
let queue=Promise.resolve();
chrome.runtime.onMessage.addListener((m,s,respond)=>{
 const task=async()=>{
  if(!validId(m?.id))throw Error('요청 식별자 오류');
  if(['ping','start','cancel','poll','ack','resume','recover','abandon'].includes(m.action)){
   if(!admin(s.url)||!s.tab?.id)throw Error('IGDC 관리자 화면에서만 실행 가능합니다.');
   if(m.action==='ping')return {ok:true,version:59};
   const job=await get(m.id);if(job&&job.tab!==s.tab.id)throw Error('다른 관리 화면의 수집 요청입니다.');if(m.action==='abandon'){if(job)await discard(m.id,job,false);return {ok:true,cancelled:true};}if(m.action==='recover'){if(!job)return {ok:false,error:'이전 수집 요청이 없습니다.',code:'job_missing'};job.frame=s.frameId||0;await save(m.id,job);return {ok:true,waiting:!job.result,finished:!!job.result,stage:job.stage,metrics:job.metrics||{},...(job.result?{result:job.result}:{})};}if(job&&job.frame!==(s.frameId||0))throw Error('다른 관리 화면의 수집 요청입니다.');
   if(m.action==='resume'){if(!job)throw Error('열린 수집 작업이 없습니다.');if(job.collectTab!=null){try{await chrome.tabs.get(job.collectTab);}catch{job.collectTab=null;}}if(job.collectTab==null){const t=await chrome.tabs.create({url:chrome.runtime.getURL('collect.html')+'?id='+m.id,windowId:s.tab.windowId,active:true});job.collectTab=t.id;await save(m.id,job);}else await focus(job.collectTab);return {ok:true,resumed:true};}
   if(m.action==='ack'){if(job?.result){const rec=m.receipt;if(job.result.ok){const total=job.result.packet?.records?.length;if(!rec||!Number.isSafeInteger(rec.received)||rec.received<1||!Number.isSafeInteger(rec.rejected)||rec.rejected<0||rec.submitted!==total||rec.received+rec.rejected!==total)throw Error('관리자 수신 수량 불일치 · 자료 보존');}else if(rec?.failed!==true)throw Error('실패 확인 누락');await discard(m.id,job,true);}return {ok:true,acknowledged:true};}
   if(m.action==='cancel'){if(job)await discard(m.id,job,true);return {ok:true,cancelled:true};}
   if(m.action==='poll'){if(!job)return {ok:false,error:'수집 요청을 찾을 수 없습니다.',code:'job_missing'};if(Date.now()-job.at>ttl&&!job.result&&!job.draft){job.stage='retry';job.code='job_timeout';await save(m.id,job);}return {ok:true,waiting:!job.result,finished:!!job.result,stage:job.stage,metrics:job.metrics||{},code:job.code||'',...(job.result?{result:job.result}:{})};}
   if(job)throw Error('중복 요청');
   const url=target(m.url);if(!url)throw Error('공개 HTTPS 상품 주소를 확인하세요.');
   const all=await chrome.storage.session.get(null);for(const [k,j] of Object.entries(all)){if(k.startsWith('job:')&&Date.now()-j.at>ttl&&!j.result&&!j.draft)await discard(k.slice(4),j);}
   if(Object.entries(all).filter(([k,j])=>k.startsWith('job:')&&(j.result||j.draft||Date.now()-j.at<ttl)).length>=4)throw Error('동시 수집 작업 한도에 도달했습니다. 기존 작업을 완료하세요.');
   if(Object.values(all).some(j=>j?.tab===s.tab.id&&j?.frame===(s.frameId||0)&&(j.result||j.draft||Date.now()-j.at<ttl)))throw Error('기존 수집 창을 완료하거나 취소한 뒤 다시 시도하세요.');
   const j={url,tab:s.tab.id,frame:s.frameId||0,at:Date.now(),stage:'permission'};await save(m.id,j);
   try{const t=await chrome.tabs.create({url:chrome.runtime.getURL('collect.html')+'?id='+m.id,windowId:s.tab.windowId,active:true});j.collectTab=t.id;await save(m.id,j);}catch(e){await chrome.storage.session.remove(key(m.id));throw e;}
   return {ok:true,started:true,version:59};
  }
  if(!s.url?.startsWith(chrome.runtime.getURL('collect.html')+'?'))throw Error('수집 도구 요청 오류');
  const job=await get(m.id);if(!job||job.collectTab!==s.tab?.id)throw Error('수집 요청 만료 또는 변경');
  if(m.action==='get')return {ok:true,url:job.url,sourceTab:job.sourceTab??null,stage:job.stage,delivered:!!job.result,draft:job.draft||null};
  if(m.action==='open'){
   if(job.result)throw Error('이미 수집 자료를 전달했습니다.');
   if(job.sourceTab!=null){try{const t=await chrome.tabs.get(job.sourceTab);if(t)return {ok:true,tab:t.id};}catch{}}
   if(!await chrome.permissions.contains({origins:[new URL(job.url).origin+'/*']}))throw Error('사이트 접근 권한을 먼저 승인하세요.');
   const t=await chrome.tabs.create({url:job.url,windowId:s.tab.windowId,active:false});job.sourceTab=t.id;job.stage='source_open';await save(m.id,job);return {ok:true,tab:t.id};
  }
  if(m.action==='view'){if(job.sourceTab==null)throw Error('원본 페이지가 없습니다.');await focus(job.sourceTab);return {ok:true};}
  if(m.action==='return'){await focus(job.tab);return {ok:true};}
  if(m.action==='progress'){if(['scanning','selecting','detail_reading','retry'].includes(m.stage)&&!job.result){job.at=Date.now();job.stage=m.stage;job.metrics={...(job.metrics||{})};for(const k of ['scanned','attempted','failed','accepted'])if(Number.isSafeInteger(m.metrics?.[k])&&m.metrics[k]>=0)job.metrics[k]=Math.min(m.metrics[k],1000);if(m.draft&&typeof m.draft==='object'&&Array.isArray(m.draft.rows)&&m.draft.rows.length<=100&&Array.isArray(m.draft.results)&&m.draft.results.length<=100&&Array.isArray(m.draft.failures)&&m.draft.failures.length<=100&&JSON.stringify(m.draft).length<=750000)job.draft=m.draft;job.code=typeof m.code==='string'&&/^[a-z_]{1,40}$/.test(m.code)?m.code:'';await save(m.id,job);}return {ok:true};}
  if(m.action==='finish'){
   const result=m.result;if(!result||typeof result.ok!=='boolean'||JSON.stringify(result).length>1000000)throw Error('수집 결과 형식 오류');
   if(job.result){await notify(m.id,job);return {ok:true,retained:true};}
   job.result=result;job.stage='awaiting_ack';await save(m.id,job);await focus(job.tab);await notify(m.id,job);return {ok:true,retained:true};
  }throw Error('지원하지 않는 명령');
 };const run=queue.then(task);queue=run.catch(()=>{});run.then(respond,e=>respond({ok:false,error:String(e.message||e).slice(0,250)}));return true;
});
chrome.tabs.onRemoved.addListener(tab=>{queue=queue.then(async()=>{const all=await chrome.storage.session.get(null);for(const [k,j] of Object.entries(all)){if(!k.startsWith('job:'))continue;const id=k.slice(4);if(j.tab===tab){await discard(id,j);continue;}if(j.collectTab===tab){if(j.result){j.collectTab=null;await save(id,j);continue;}j.collectTab=null;if(j.draft){j.stage='selecting';j.code='collector_closed';await save(id,j);await focus(j.tab);continue;}j.result={ok:false,error:'수집 창을 닫았습니다.',code:'collector_closed'};j.stage='awaiting_ack';await save(id,j);await close(j.sourceTab);await notify(id,j);continue;}if(j.sourceTab===tab){j.sourceTab=null;await save(id,j);}}}).catch(()=>{});});

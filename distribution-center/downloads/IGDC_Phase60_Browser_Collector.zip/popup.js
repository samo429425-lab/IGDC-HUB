"use strict";
const permit=document.getElementById('permit'),run=document.getElementById('run'),status=document.getElementById('status');
let busy=false;permit.onchange=()=>{run.disabled=busy||!permit.checked;};
run.onclick=async()=>{if(busy||!permit.checked)return;busy=true;run.disabled=true;status.textContent='현재 페이지 분석 중';try{
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id||!tab.url?.startsWith('https://'))throw Error('허용된 HTTPS 상품 페이지를 먼저 여세요.');
 await chrome.scripting.executeScript({target:{tabId:tab.id},files:['source-profile-core.js','capture-core.js']});
 const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>window.DCenterCapture.fromDocument(document,location.href)});
 const packet=result?.result;if(!packet||packet.page_url!==new URL(tab.url).href.split('#')[0]||!Array.isArray(packet.records))throw Error('페이지 변경 또는 수집 자료 오류');
 if(!packet.records.length)throw Error('현재 페이지에서 상품 자료를 찾지 못했습니다. 개별 상품 상세 페이지에서 다시 시도하세요.');
 packet.permission_confirmed=true;const data=JSON.stringify(packet);if(new Blob([data]).size>1000000)throw Error('자료 크기 초과. 개별 상품 상세 페이지를 사용하세요.');
 const u=URL.createObjectURL(new Blob([data],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='IGDC_Product_Capture_'+Date.now()+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000);
 status.textContent=packet.records.length+'개 자료 저장 요청 완료. IGDC에서 동일 출처를 선택하고 브라우저 수집 JSON 가져오기를 사용하세요.';
 }catch(e){status.textContent=e.message||'수집 실패';}finally{busy=false;run.disabled=!permit.checked;}};

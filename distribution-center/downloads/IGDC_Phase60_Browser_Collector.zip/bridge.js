'use strict';
(()=>{
 const origin=location.origin;
 const reply=(id,data)=>window.postMessage({channel:'igdc55-extension',id,...data},origin);
 window.addEventListener('message',async e=>{
  const m=e.data;if(e.source!==window||e.origin!==origin||m?.channel!=='igdc55-admin'||!(/^[a-f0-9-]{36}$/.test(m.id||''))||!['ping','start','cancel','poll','ack','resume','recover','abandon'].includes(m.action))return;
  try{const r=await chrome.runtime.sendMessage({action:m.action,id:m.id,url:m.url,receipt:m.receipt});if(m.action==='ack'){reply(m.id,{ack_result:true,ok:r?.ok===true,error:r?.error||''});return;}if(m.action==='cancel'||m.action==='abandon')return;if(m.action==='resume'){if(!r?.ok)reply(m.id,{...r,code:'resume_failed'});return;}if(['poll','recover'].includes(m.action)&&r?.finished){reply(m.id,{finished:true,...r.result});return;}reply(m.id,r||{ok:false,error:'연결 응답 없음'});}catch{if(m.action==='ack'){reply(m.id,{ack_result:true,ok:false,error:'수신 확인 전송 실패'});return;}if(m.action!=='cancel'&&m.action!=='abandon')reply(m.id,{ok:false,error:'확장 프로그램을 다시 설치하거나 관리자 화면을 새로고침하세요.',code:'bridge_error'});}
 });
 chrome.runtime.onMessage.addListener((m,sender)=>{if(sender.id===chrome.runtime.id&&m?.action==='result')reply(m.id,{finished:true,...m.result});});
})();

"use strict";

/**
 * Builds and validates a Social release from approved Supabase candidates.
 * Runtime functions never write deployed static files. A confirmed release is
 * stored in the durable Social release store and becomes visible immediately via
 * social-snapshot-current. A static Netlify rebuild is optional (forceBuild=true)
 * and is no longer required for normal Social content rotation/publication.
 * Commerce/Distribution canonical SearchBank is never rewritten by this path.
 */
const fs = require("fs");
const path = require("path");
const SocialStore = require("./lib/social-candidate-store.v1");
const SharedAdminAuth = require("./lib/global-slot-console-auth");
const CountryRouting = require("./lib/social-country-routing.v1");
const SocialSearchBankReleaseAdapter = require("./lib/social-searchbank-release-adapter.v1");

const VERSION =
  "social-snapshot-publish-v1.18.1-server-authoritative-front";
function text(value) {
  return value == null ? "" : String(value).trim();
}
async function actorFor(event) {
  const actor = await SharedAdminAuth.resolveUser(event);
  const member = {
    memberId: text(actor && (actor.memberId || actor.sub)),
    email: text(actor && actor.email),
    roles: Array.isArray(actor && actor.roles) ? actor.roles : [],
  };
  SocialStore.requireRole(member, "write");
  return member;
}
function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (_e) {
    return null;
  }
}
function baseSnapshot() {
  const root = process.cwd();
  const files = [
    path.join(root, "data", "social.snapshot.json"),
    path.join(root, "netlify", "functions", "data", "social.snapshot.json"),
    path.join(__dirname, "data", "social.snapshot.json"),
  ];
  for (const file of files) {
    const doc = readJson(file);
    if (doc) return { file, doc };
  }
  const sections = {};
  SocialStore.Policy.SECTION_KEYS.forEach((sectionKey) => {
    sections[sectionKey] = [];
  });
  return {
    file: "generated-empty",
    doc: {
      version: "social.snapshot.empty",
      type: "social_snapshot",
      pages: { social: { sections } },
      meta: {},
    },
  };
}
function releaseCountry(row) {
  return text(
    row &&
      row.snapshot &&
      row.snapshot.meta &&
      row.snapshot.meta.applicationScope &&
      row.snapshot.meta.applicationScope.countryCode,
  ).toUpperCase();
}
function scopeToken(route) {
  const country = text(route && route.countryCode).toUpperCase();
  const region = text(route && (route.worldRegion || route.regionId));
  const mode = text(route && route.scopeMode).toLowerCase();
  if (mode === "global") return "GLOBAL";
  if (country) return country;
  if (region) return "REGION:" + region;
  return "GLOBAL";
}
function fullStructuralBase(storedSnapshot) {
  const seed = baseSnapshot();
  const base = JSON.parse(JSON.stringify((seed && seed.doc) || {}));
  const stored = storedSnapshot && typeof storedSnapshot === "object"
    ? JSON.parse(JSON.stringify(storedSnapshot))
    : null;
  if (!stored) return { file: seed && seed.file || "static-social-snapshot", doc: base };

  if (!base.pages) base.pages = {};
  if (!base.pages.social) base.pages.social = {};
  if (!base.pages.social.sections) base.pages.social.sections = {};

  const storedSocial = stored.pages && stored.pages.social || {};
  const storedSections = storedSocial.sections || {};

  // Only the nine managed SNS sections may be inherited from a stored release.
  // Reserved structural sections (social-maru, rightPanel) always stay exactly
  // as deployed in the static Social snapshot so a partial release can never
  // erase the right-side product cards or the MARU reserved section.
  SocialStore.Policy.SECTION_KEYS.forEach((sectionKey) => {
    if (Array.isArray(storedSections[sectionKey])) {
      base.pages.social.sections[sectionKey] = JSON.parse(
        JSON.stringify(storedSections[sectionKey]),
      );
    }
  });

  if (storedSocial.candidatePool && typeof storedSocial.candidatePool === "object") {
    const currentPool = base.pages.social.candidatePool && typeof base.pages.social.candidatePool === "object"
      ? base.pages.social.candidatePool
      : {};
    SocialStore.Policy.SECTION_KEYS.forEach((sectionKey) => {
      if (Array.isArray(storedSocial.candidatePool[sectionKey])) {
        currentPool[sectionKey] = JSON.parse(
          JSON.stringify(storedSocial.candidatePool[sectionKey]),
        );
      }
    });
    base.pages.social.candidatePool = currentPool;
  }

  return { file: seed && seed.file || "static-social-snapshot", doc: base };
}

async function latestStoredBase(route) {
  const countryCode = text(route && route.countryCode).toUpperCase();
  const regionId = text(route && (route.worldRegion || route.regionId));
  let exactRows;
  try {
    exactRows = await SocialStore.selectReleases(
      "select=release_id,snapshot,created_at,notes&status=eq.stored&notes=like." +
        encodeURIComponent("scope=" + scopeToken(route) + ";%") +
        "&order=created_at.desc&limit=1",
    );
    let latest = Array.isArray(exactRows) && exactRows[0];
    if (!latest && (countryCode || regionId)) {
      const globalRows = await SocialStore.selectReleases(
        "select=release_id,snapshot,created_at,notes&status=eq.stored&notes=like." +
          encodeURIComponent("scope=GLOBAL;%") +
          "&order=created_at.desc&limit=1",
      );
      latest = Array.isArray(globalRows) && globalRows[0];
    }
    if (!latest) {
      const legacyRows = await SocialStore.selectReleases(
        "select=release_id,snapshot,created_at,notes&status=eq.stored&order=created_at.desc&limit=25",
      );
      const list = Array.isArray(legacyRows) ? legacyRows : [];
      const exact = list.find((row) => releaseCountry(row) === countryCode);
      const global = list.find((row) => !releaseCountry(row));
      latest = exact || ((countryCode || regionId) ? global : null);
    }
    if (latest && latest.snapshot) {
      const structural = fullStructuralBase(latest.snapshot);
      return {
        file: "stored-current:" + latest.release_id + "+static-structural-base",
        doc: structural.doc,
      };
    }
  } catch (error) {
    // Never turn a temporary release-store read failure into a new static-base
    // publication. That could replace a valid persistent front with an older
    // repository snapshot. Abort this publication and leave the live front as-is.
    const wrapped = new Error(
      "마지막 Social Release를 읽지 못해 기존 프론트를 보존했습니다. 저장소 연결이 복구된 뒤 다시 실행해 주세요.",
    );
    wrapped.code = "social_release_base_unavailable";
    wrapped.statusCode = 503;
    wrapped.cause = error;
    throw wrapped;
  }
  return baseSnapshot();
}
function approvedQuery(limit) {
  const safeLimit = Math.max(1, Math.min(5000, Number(limit) || 3500));
  return (
    "select=*&review_status=eq.approved&candidate_only=eq.false&seed_content=eq.false&order=section_key.asc,rotation_score.desc,approved_at.desc&limit=" +
    safeLimit
  );
}
function candidateIdsFrom(params) {
  return Array.from(
    new Set(
      SocialStore.array(
        params.candidateIds || params.ids || params.candidateId || params.id,
      )
        .map(SocialStore.text)
        .filter(Boolean),
    ),
  ).slice(0, 1000);
}
function requestedSectionsFrom(params, sectionKey) {
  const raw = SocialStore.array(
    params.requestedSections || params.sectionKeys || params.sections || [],
  );
  const normalized = Array.from(new Set(raw.map((value) =>
    SocialStore.Policy.normalizeSectionKey(value),
  ).filter((value) => SocialStore.Policy.ALLOWED_SECTIONS.has(value))));
  if (normalized.length) return normalized;
  if (sectionKey && SocialStore.Policy.ALLOWED_SECTIONS.has(sectionKey)) return [sectionKey];
  return SocialStore.Policy.SECTION_KEYS.slice();
}
function publishModeFrom(params, sectionKey) {
  const requested = text(params.publishMode || params.actionType || params.reportMode)
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
  const allowed = new Set([
    "social_full_run",
    "selected_sections_front_publish",
    "all_sections_front_publish",
    "selected_content_front_publish",
    "single_section_front_publish",
  ]);
  if (allowed.has(requested)) return requested;
  return sectionKey ? "single_section_front_publish" : "all_sections_front_publish";
}
function publishReportType(mode) {
  const map = {
    social_full_run: "igdc-social-full-run-report",
    selected_sections_front_publish: "igdc-social-selected-sections-front-publish-report",
    all_sections_front_publish: "igdc-social-all-sections-front-publish-report",
    selected_content_front_publish: "igdc-social-selected-content-front-publish-report",
    single_section_front_publish: "igdc-social-single-section-front-publish-report",
  };
  return map[mode] || "igdc-social-front-publish-report";
}
function publicationPlanDiff(beforePlan, afterPlan) {
  const before = beforePlan && typeof beforePlan === "object" ? beforePlan : {};
  const after = afterPlan && typeof afterPlan === "object" ? afterPlan : {};
  const sections = {};
  const changedSections = [];
  let addedTotal = 0;
  let removedTotal = 0;
  let retainedTotal = 0;
  SocialStore.Policy.SECTION_KEYS.forEach((sectionKey) => {
    const beforeIds = Array.from(new Set(SocialStore.array(before[sectionKey]).map(text).filter(Boolean)));
    const afterIds = Array.from(new Set(SocialStore.array(after[sectionKey]).map(text).filter(Boolean)));
    const beforeSet = new Set(beforeIds);
    const afterSet = new Set(afterIds);
    const added = afterIds.filter((id) => !beforeSet.has(id));
    const removed = beforeIds.filter((id) => !afterSet.has(id));
    const retained = afterIds.filter((id) => beforeSet.has(id));
    if (added.length || removed.length) changedSections.push(sectionKey);
    addedTotal += added.length;
    removedTotal += removed.length;
    retainedTotal += retained.length;
    sections[sectionKey] = {
      before: beforeIds.length,
      after: afterIds.length,
      addedCount: added.length,
      removedCount: removed.length,
      retainedCount: retained.length,
      addedIds: added,
      removedIds: removed,
    };
  });
  return {
    changed: changedSections.length > 0,
    changedSections,
    unchangedSections: SocialStore.Policy.SECTION_KEYS.filter((key) => !changedSections.includes(key)),
    totals: { added: addedTotal, removed: removedTotal, retained: retainedTotal },
    sections,
  };
}
function buildHookSetting() {
  // The Social publisher triggers the same site build that runs the canonical
  // Social release -> SearchBank adapter -> Snapshot Engine chain. Reuse an
  // already configured site-level Commerce hook when a Social-specific hook
  // is not present; this avoids silently stopping at release_stored_waiting_for_build.
  const names = [
    "SOCIAL_NETLIFY_BUILD_HOOK_URL",
    "IGDC_NETLIFY_BUILD_HOOK_URL",
    "NETLIFY_BUILD_HOOK_URL",
    "COMMERCE_RELEASE_BUILD_HOOK_URL",
    "BUILD_HOOK_URL",
  ];
  for (const name of names) {
    const value = text(process.env[name]);
    if (value) return { name, value };
  }
  return { name: names[0], value: "" };
}
function buildHookStatus() {
  const setting = buildHookSetting();
  return {
    configured: !!setting.value,
    environment: setting.value ? setting.name : "SOCIAL_NETLIFY_BUILD_HOOK_URL",
    acceptedEnvironmentNames: [
      "SOCIAL_NETLIFY_BUILD_HOOK_URL",
      "IGDC_NETLIFY_BUILD_HOOK_URL",
      "NETLIFY_BUILD_HOOK_URL",
      "COMMERCE_RELEASE_BUILD_HOOK_URL",
      "BUILD_HOOK_URL",
    ],
  };
}
async function triggerCanonicalBuild(release, operation, route, handoff) {
  const setting = buildHookSetting();
  if (!setting.value) {
    return {
      ok: false,
      status: "not_configured",
      requiredEnvironment: "SOCIAL_NETLIFY_BUILD_HOOK_URL (or existing site build hook)",
      acceptedEnvironmentNames: [
        "SOCIAL_NETLIFY_BUILD_HOOK_URL",
        "IGDC_NETLIFY_BUILD_HOOK_URL",
        "NETLIFY_BUILD_HOOK_URL",
        "COMMERCE_RELEASE_BUILD_HOOK_URL",
        "BUILD_HOOK_URL",
      ],
      message:
        "승인본은 저장됐지만 정식 정적 스냅샷 배포를 시작할 Netlify Build Hook을 찾지 못했습니다.",
    };
  }
  let parsed;
  try {
    parsed = new URL(setting.value);
  } catch (_error) {
    return {
      ok: false,
      status: "invalid_configuration",
      environment: setting.name,
      message: "Netlify Build Hook 주소 형식이 올바르지 않습니다.",
    };
  }
  if (parsed.protocol !== "https:") {
    return {
      ok: false,
      status: "invalid_configuration",
      environment: setting.name,
      message: "Netlify Build Hook은 HTTPS 주소여야 합니다.",
    };
  }
  const plan = handoff && handoff.publicationPlan && typeof handoff.publicationPlan === "object"
    ? handoff.publicationPlan
    : {};
  const planHash = text(handoff && handoff.publicationPlanHash) || SocialStore.sha256(plan);
  const planCount = Object.values(plan).reduce((sum, list) =>
    sum + (Array.isArray(list) ? list.length : 0), 0);
  // A zero-row publish is never equivalent to an unpublish. Treat it as a
  // safe no-op before Netlify is called so a temporary/empty candidate read
  // cannot replace a valid Social release or fail a site build. An explicit
  // unpublish is the only operation allowed to carry an empty publication plan.
  if (text(operation).toLowerCase() !== "unpublish" && planCount === 0) {
    return {
      ok: false,
      status: "empty_publication_plan",
      environment: setting.name,
      releaseId: text(release && release.release_id) || null,
      message: "공개할 승인 소셜 콘텐츠가 0건이므로 기존 프론트를 보존하고 Netlify 배포를 시작하지 않았습니다.",
    };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(setting.value, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        trigger_title:
          "IGDC Social " + operation + " " + text(release.release_id),
        // Netlify exposes a build-hook JSON body as INCOMING_HOOK_BODY.
        // Carry only the exact already-stored release identity/scope so the
        // build-time Social adapter can verify that it consumes the same
        // administrator-approved release even when Supabase secrets are scoped
        // to Functions instead of Builds. This is a server-side handoff marker,
        // never a browser/front rendering shortcut.
        trigger: "approved-social-snapshot-release",
        releaseId: text(release.release_id),
        snapshotHash: text(release.snapshot_hash),
        scopeMode: text(route && route.countryCode) ? "country" : "global",
        countryCode: text(route && route.countryCode).toUpperCase() || null,
        worldRegion: text(route && (route.worldRegion || route.regionId)) || null,
        operation: text(operation) || "publish",
        publishMode: text(handoff && handoff.publishMode) || null,
        requestedSections: Array.isArray(handoff && handoff.requestedSections)
          ? handoff.requestedSections
          : [],
        // Canonical publication manifest.  This is intentionally only the
        // candidate IDs per managed SNS section, not rendered card payload.
        // The Netlify build re-reads those exact approved candidates from the
        // existing Supabase candidate store and then passes them through the
        // existing SearchBank contract.  This removes the empty release-table
        // lookup as a hard dependency without creating a browser/front bypass.
        publicationPlan: plan,
        publicationPlanHash: planHash,
        publicationPlanCount: planCount,
        requestedAt: new Date().toISOString(),
      }),
      signal: controller.signal,
    });
    if (!response.ok) {
      return {
        ok: false,
        status: "request_failed",
        environment: setting.name,
        httpStatus: response.status,
        message: "Netlify 정식 배포 요청이 접수되지 않았습니다.",
      };
    }
    return {
      ok: true,
      status: "queued",
      environment: setting.name,
      httpStatus: response.status,
      releaseId: text(release.release_id),
      message:
        "정식 빌드가 접수됐습니다. 승인 소셜 콘텐츠는 정책·PSOM 검증을 거쳐 Social 전용 SearchBank 인계 파일에 저장되고, 기존 Snapshot Engine의 Social 대상 경로로 이어집니다.",
    };
  } catch (error) {
    return {
      ok: false,
      status: error && error.name === "AbortError" ? "timeout" : "request_failed",
      environment: setting.name,
      message:
        error && error.name === "AbortError"
          ? "Netlify 정식 배포 요청 시간이 초과됐습니다."
          : "Netlify 정식 배포 요청 중 오류가 발생했습니다.",
    };
  } finally {
    clearTimeout(timeout);
  }
}

function releaseSchemaMismatch(error) {
  const message = text(error && error.message).toLowerCase();
  return !!(
    error &&
    error.code === "social_supabase_http_error" &&
    /column|schema cache|could not find/.test(message)
  );
}
function releaseSequencePermissionError(error) {
  const message = text(error && error.message).toLowerCase();
  return !!(
    error &&
    error.code === "social_supabase_http_error" &&
    /permission denied for sequence/.test(message) &&
    /social_snapshot_releases_id_seq|_id_seq/.test(message)
  );
}
function releaseDuplicateIdError(error) {
  const message = text(error && error.message).toLowerCase();
  return !!(
    error &&
    (String(error.statusCode || "") === "409" || /duplicate key|unique constraint|already exists/.test(message))
  );
}
function minimalReleaseShape(release) {
  const minimal = {
    release_id: release.release_id,
    status: release.status,
    snapshot_hash: release.snapshot_hash,
    snapshot: release.snapshot,
    notes: release.notes,
    created_at: release.created_at,
  };
  if (release.id != null) minimal.id = release.id;
  return minimal;
}
async function insertReleaseShapeCompat(release) {
  try {
    return await SocialStore.insertRelease(release);
  } catch (error) {
    if (!releaseSchemaMismatch(error)) throw error;
    return SocialStore.insertRelease(minimalReleaseShape(release));
  }
}
async function nextExplicitReleaseId() {
  // The production diagnostics showed table INSERT permission but no USAGE on
  // social_snapshot_releases_id_seq. Reading the latest id and supplying the
  // serial/bigserial id explicitly avoids nextval() without changing schema or
  // weakening the release-table persistence contract.
  try {
    const rows = await SocialStore.selectReleases(
      "select=id&order=id.desc&limit=1",
    );
    const latest = Array.isArray(rows) && rows[0] ? Number(rows[0].id) : 0;
    if (Number.isFinite(latest) && latest >= 0) return Math.floor(latest) + 1;
  } catch (_error) {
    /* Epoch-second fallback stays within signed 32-bit range through 2038. */
  }
  return Math.floor(Date.now() / 1000);
}
async function storeReleaseCompat(release) {
  // First preserve the canonical insert behavior.  The current Supabase role
  // may legitimately insert the row but lack sequence USAGE; in that exact
  // case retry with an explicit id.  This is still the same release table and
  // the exact same snapshot/hash -- not a browser/session fallback.
  try {
    return await insertReleaseShapeCompat(release);
  } catch (error) {
    if (!releaseSequencePermissionError(error)) throw error;
    let explicitId = await nextExplicitReleaseId();
    for (let attempt = 0; attempt < 4; attempt += 1) {
      try {
        return await insertReleaseShapeCompat(
          Object.assign({}, release, { id: explicitId + attempt }),
        );
      } catch (retryError) {
        if (!releaseDuplicateIdError(retryError)) throw retryError;
      }
    }
    const finalError = new Error("social release explicit-id persistence retry exhausted");
    finalError.code = "social_release_explicit_id_exhausted";
    finalError.statusCode = 409;
    throw finalError;
  }
}

async function verifyStoredRelease(release) {
  const rows = await SocialStore.selectReleases(
    "select=release_id,status,snapshot_hash,snapshot,created_at&release_id=eq." +
      encodeURIComponent(text(release.release_id)) +
      "&status=eq.stored&limit=1",
  );
  const row = Array.isArray(rows) && rows[0];
  return !!(
    row &&
    row.snapshot &&
    text(row.release_id) === text(release.release_id) &&
    text(row.snapshot_hash) === text(release.snapshot_hash) &&
    SocialStore.sha256(row.snapshot) === text(release.snapshot_hash)
  );
}

async function latestStoredReleaseForRoute(route) {
  const token = scopeToken(route);
  const exactRows = await SocialStore.selectReleases(
    "select=release_id,status,snapshot_hash,snapshot,created_at,notes&status=eq.stored&notes=like." +
      encodeURIComponent("scope=" + token + ";%") +
      "&order=created_at.desc&limit=1",
  );
  let latest = Array.isArray(exactRows) && exactRows[0];
  if (!latest && token !== "GLOBAL") {
    const globalRows = await SocialStore.selectReleases(
      "select=release_id,status,snapshot_hash,snapshot,created_at,notes&status=eq.stored&notes=like." +
        encodeURIComponent("scope=GLOBAL;%") +
        "&order=created_at.desc&limit=1",
    );
    latest = Array.isArray(globalRows) && globalRows[0];
  }
  return latest || null;
}
function releasedIdsBySection(snapshot) {
  const sections = snapshot && snapshot.pages && snapshot.pages.social && snapshot.pages.social.sections || {};
  const result = {};
  SocialStore.Policy.SECTION_KEYS.forEach((sectionKey) => {
    result[sectionKey] = (Array.isArray(sections[sectionKey]) ? sections[sectionKey] : [])
      .filter((slot) => text(slot && slot.type) === "external_social" && text(slot && slot.audit && slot.audit.origin) === "social_candidates")
      .map((slot) => text(slot && (slot.contentId || slot.candidateId || slot.id || slot.audit && slot.audit.candidate_id)))
      .filter(Boolean);
  });
  return result;
}
function searchBankSnapshotState(root, expectedIds) {
  const files = SocialSearchBankReleaseAdapter.socialBankPaths(root);
  const mirrorRows = [];
  let primary = null;
  for (const file of files) {
    const doc = readJson(file);
    const valid = !!(doc && Array.isArray(doc.items));
    const hash = valid ? SocialSearchBankReleaseAdapter.sha256(doc) : null;
    const rel = path.relative(root, file).replace(/\\/g, "/");
    mirrorRows.push({ file: rel, present: valid, hash, itemCount: valid ? doc.items.length : 0 });
    if (!primary && valid) primary = { file: rel, doc, hash };
  }
  const expected = new Set(Array.isArray(expectedIds) ? expectedIds : []);
  const idsBySection = {};
  const presentIds = new Set();
  let candidateCount = 0;
  let sampleCount = 0;
  let socialTotal = 0;
  if (primary) {
    for (const item of primary.doc.items) {
      const section = text(item && (item.psom_key || item.section || item.bind && item.bind.section));
      if (!section.startsWith("social-")) continue;
      socialTotal += 1;
      const auditOrigin = text(item && item.audit && item.audit.origin);
      const socialCandidate = auditOrigin === "social_candidates" || !!(item && item.socialCandidatePublication && item.socialCandidatePublication.candidateId);
      if (socialCandidate) {
        candidateCount += 1;
        const id = text(item && (item.id || item.contentId || item.candidateId));
        if (id) {
          if (!idsBySection[section]) idsBySection[section] = [];
          idsBySection[section].push(id);
          if (expected.has(id)) presentIds.add(id);
        }
      } else {
        const url = text(item && (item.url || item.link || item.href)).toLowerCase();
        const image = text(item && (item.thumbnail || item.thumb || item.image)).toLowerCase();
        const title = text(item && (item.title || item.name)).toLowerCase();
        if (item && (item.sample === true || item.placeholder === true || item.replaceableSlot === true) || url === "#" || url.includes("example.com") || image.includes("placeholder") || title.includes("seed placeholder")) sampleCount += 1;
      }
    }
  }
  const hashes = mirrorRows.filter((row) => row.present).map((row) => row.hash);
  const mirrorConsensus = hashes.length > 0 && new Set(hashes).size === 1;
  return {
    checked: true,
    source: primary ? primary.file : null,
    mirrors: mirrorRows,
    mirrorConsensus,
    totalItems: primary ? primary.doc.items.length : 0,
    socialItems: socialTotal,
    socialCandidateItems: candidateCount,
    socialSampleItemsPreserved: sampleCount,
    idsBySection,
    presentExpectedIds: Array.from(presentIds),
  };
}
async function runtimePipelineDiagnostic(route) {
  const root = process.cwd();
  const release = await latestStoredReleaseForRoute(route);
  const out = {
    ok: false,
    reportType: "igdc-social-searchbank-handoff-verification",
    version: VERSION,
    generatedAt: SocialStore.nowIso(),
    scope: {
      countryCode: text(route && route.countryCode).toUpperCase() || null,
      worldRegion: text(route && (route.worldRegion || route.regionId)) || null,
      mode: text(route && route.scopeMode) || (text(route && route.countryCode) ? "country" : "global"),
    },
    pipelineModel: [
      "stored_social_release",
      "social_policy_and_psom_gate",
      "data/social-searchbank.release.snapshot.json",
      "existing_snapshot_engine_social_target",
      "data/social.snapshot.json",
      "existing_social_automap",
    ],
    buildHook: buildHookStatus(),
    release: release
      ? {
          releaseId: text(release.release_id),
          status: text(release.status),
          snapshotHash: text(release.snapshot_hash),
          createdAt: text(release.created_at),
          notes: text(release.notes),
        }
      : null,
    policyGate: null,
    searchBankSnapshot: null,
    comparison: {
      expectedApprovedItems: 0,
      presentInSearchBankSnapshot: 0,
      missingIds: [],
    },
    pipeline: {
      storedRelease: release ? "passed" : "missing",
      policyAndPsomGate: "not_run",
      searchBankSnapshotHandoff: "not_run",
      downstream: "existing_automatic_pipeline_not_mutated",
    },
    safety: {
      readOnly: true,
      runtimeFileWrite: false,
      searchBankEngineMutation: false,
      snapshotEngineMutation: false,
      socialSnapshotMutation: false,
      frontOrAutomapMutation: false,
      buildTrigger: false,
    },
  };
  if (!release || !release.snapshot) {
    out.reason = "stored_social_release_not_found";
    return out;
  }

  const converted = SocialSearchBankReleaseAdapter.releaseToBank(release);
  const gate = SocialSearchBankReleaseAdapter.policyGate(root, converted.bank);
  out.policyGate = {
    ok: gate.ok,
    psomFile: gate.psomFile,
    acceptedCount: gate.accepted.length,
    rejectedCount: gate.rejected.length,
    counts: gate.counts,
    rejected: gate.rejected.slice(0, 100),
  };
  out.pipeline.policyAndPsomGate = gate.ok ? "passed" : "failed";
  if (!gate.ok) {
    out.reason = "social_searchbank_policy_gate_rejected";
    return out;
  }

  const expectedIds = gate.accepted.map((item) => text(item && item.id)).filter(Boolean);
  const searchBank = searchBankSnapshotState(root, expectedIds);
  const present = new Set(searchBank.presentExpectedIds || []);
  const missingIds = expectedIds.filter((id) => !present.has(id));
  out.searchBankSnapshot = searchBank;
  out.comparison = {
    expectedApprovedItems: expectedIds.length,
    presentInSearchBankSnapshot: expectedIds.length - missingIds.length,
    missingIds,
  };
  out.pipeline.searchBankSnapshotHandoff =
    searchBank.mirrorConsensus && missingIds.length === 0 ? "passed" : "mismatch";
  out.ok =
    gate.ok &&
    searchBank.mirrorConsensus &&
    missingIds.length === 0;
  if (!out.ok) {
    out.reason = !searchBank.mirrorConsensus
      ? "search_bank_snapshot_mirror_mismatch"
      : "approved_social_items_missing_from_search_bank_snapshot";
  }
  return out;
}

exports.handler = async function (event) {
  if (event && event.httpMethod === "OPTIONS")
    return SocialStore.response(204, {});
  try {
    if (!["GET", "POST"].includes(event.httpMethod))
      return SocialStore.response(405, {
        ok: false,
        error: "method_not_allowed",
      });
    const actor = await actorFor(event);
    const params = Object.assign(
      {},
      event.queryStringParameters || {},
      event.httpMethod === "POST" ? SocialStore.parseBody(event) : {},
    );
    const operation = text(params.operation || params.action)
      .toLowerCase()
      .replace(/[\s-]+/g, "_");
    const unpublishSelected =
      operation === "unpublish_selected" ||
      operation === "selected_front_unpublish";
    const candidateIds = candidateIdsFrom(params);
    const actualApplyOperation =
      operation === "actual_front_apply" || operation === "publish_actual" || operation === "apply_actual";
    const storeRelease =
      actualApplyOperation || params.storeRelease === true || params.storeRelease === "true";
    if (
      storeRelease &&
      !unpublishSelected &&
      params.confirmPublish !== true &&
      params.confirmPublish !== "true"
    ) {
      return SocialStore.response(400, {
        ok: false,
        version: VERSION,
        error: "actual_apply_confirmation_required",
        message: "실제 화면 적용 확인값이 필요합니다.",
      });
    }
    if (
      storeRelease &&
      unpublishSelected &&
      params.confirmUnpublish !== true &&
      params.confirmUnpublish !== "true"
    ) {
      return SocialStore.response(400, {
        ok: false,
        version: VERSION,
        error: "actual_unpublish_confirmation_required",
        message: "선택 콘텐츠 실제 적용 취소 확인값이 필요합니다.",
      });
    }
    if (unpublishSelected && !candidateIds.length) {
      return SocialStore.response(400, {
        ok: false,
        version: VERSION,
        error: "candidate_ids_required",
        message: "실제 적용을 취소할 콘텐츠를 선택해 주세요.",
      });
    }
    const sectionKey = SocialStore.Policy.normalizeSectionKey(
      params.sectionKey || params.section || params.targetSection,
    );
    if (
      (params.sectionKey || params.section || params.targetSection) &&
      !SocialStore.Policy.ALLOWED_SECTIONS.has(sectionKey)
    ) {
      return SocialStore.response(400, {
        ok: false,
        version: VERSION,
        error: "invalid_social_section",
        allowedSections: SocialStore.Policy.SECTION_KEYS,
      });
    }
    const publishMode = publishModeFrom(params, sectionKey);
    const requestedSections = requestedSectionsFrom(params, sectionKey);
    const omittedSections = SocialStore.Policy.SECTION_KEYS.filter(
      (key) => !requestedSections.includes(key),
    );
    // Full and multi-section publication is recalculated from the durable
    // server store. Browser lists are capped/operator views and must not define
    // the authoritative front plan. Exact IDs remain only for deliberately
    // selected content (or explicitly selected rows in one section).
    const serverAuthoritativeCandidateSelection =
      publishMode === "social_full_run" ||
      publishMode === "all_sections_front_publish" ||
      publishMode === "selected_sections_front_publish" ||
      (publishMode === "single_section_front_publish" && candidateIds.length === 0);
    const exactCandidateSelection =
      !serverAuthoritativeCandidateSelection && candidateIds.length > 0;
    const reportType = publishReportType(publishMode);
    const route = CountryRouting.resolve(event, params);
    if (operation === "pipeline_diagnostic" || operation === "pipeline_verification") {
      const report = await runtimePipelineDiagnostic(route);
      return SocialStore.response(200, report);
    }
    if (
      event.httpMethod === "GET" &&
      (operation === "current_front_state" ||
        operation === "published_state" ||
        operation === "front_state")
    ) {
      const latest = await latestStoredReleaseForRoute(route);
      if (latest && latest.snapshot) {
        const calculatedHash = SocialStore.sha256(latest.snapshot);
        if (text(latest.snapshot_hash) && calculatedHash !== text(latest.snapshot_hash)) {
          return SocialStore.response(409, {
            ok: false,
            version: VERSION,
            error: "stored_release_hash_mismatch",
            message: "저장된 Social Release 해시가 일치하지 않아 현재 프론트 상태로 사용하지 않았습니다.",
            preservedExistingFront: true,
          });
        }
        const bySection = releasedIdsBySection(latest.snapshot);
        const ids = Array.from(new Set(Object.values(bySection).flat()));
        return SocialStore.response(200, {
          ok: true,
          version: VERSION,
          operation: "current_front_state",
          source: "supabase.social_snapshot_releases",
          stored: true,
          releaseId: text(latest.release_id),
          snapshotHash: text(latest.snapshot_hash) || calculatedHash,
          createdAt: text(latest.created_at) || null,
          publishedIdsBySection: bySection,
          publishedContentIds: ids,
          publishedCount: ids.length,
          readOnly: true,
          buildQueued: false,
        });
      }
      const fallback = baseSnapshot();
      const bySection = releasedIdsBySection(fallback.doc);
      const ids = Array.from(new Set(Object.values(bySection).flat()));
      return SocialStore.response(200, {
        ok: true,
        version: VERSION,
        operation: "current_front_state",
        source: fallback.file,
        stored: false,
        releaseId: null,
        snapshotHash: SocialStore.sha256(fallback.doc),
        publishedIdsBySection: bySection,
        publishedContentIds: ids,
        publishedCount: ids.length,
        readOnly: true,
        buildQueued: false,
      });
    }
    const base = await latestStoredBase(route);
    const previousPublicationPlan = releasedIdsBySection(base.doc);
    const previousPublicationPlanHash = SocialStore.sha256(previousPublicationPlan);
    const hasDurablePreviousRelease = /^stored-current:/i.test(text(base.file));
    const deployedBase = baseSnapshot();
    const deployedPublicationPlan = releasedIdsBySection(deployedBase.doc);
    const deployedPublicationPlanHash = SocialStore.sha256(deployedPublicationPlan);
    let rows = [];
    let unpublish = null;
    let snapshot;
    if (unpublishSelected) {
      const seed = baseSnapshot();
      unpublish = SocialStore.unpublishSnapshot(
        base.doc,
        seed.doc,
        candidateIds,
        { route, sectionKey },
      );
      snapshot = unpublish.snapshot;
    } else {
      const allRows = await SocialStore.selectCandidates(
        approvedQuery(params.limit),
      );
      const approvedRows = Array.isArray(allRows) ? allRows : [];
      const requestedIds = new Set(candidateIds);
      const requestedSectionSet = new Set(requestedSections);
      rows = approvedRows.filter((row) => {
        const rowId = SocialStore.text(row && row.id);
        const rowSection = SocialStore.text(
          row && (row.section_key || row.sectionKey),
        );
        if (exactCandidateSelection && requestedIds.size > 0 && !requestedIds.has(rowId)) return false;
        if (sectionKey && rowSection !== sectionKey) return false;
        if (publishMode === "selected_sections_front_publish" && !requestedSectionSet.has(rowSection)) return false;
        return true;
      });
      const authoritativeReconcile = serverAuthoritativeCandidateSelection;
      snapshot = SocialStore.buildSnapshot(
        base.doc,
        Array.isArray(rows) ? rows : [],
        {
          rotationSalt: params.rotationSalt || params.salt,
          limitPerSection: params.limitPerSection,
          route,
          sectionKey,
          requestedSections,
          seedSnapshot: deployedBase.doc,
          reconcileTargetSections: authoritativeReconcile,
        },
      );
    }
    // Canonicalize to the exact JSON shape that Supabase JSONB stores before
    // calculating the release hash. publicSocialSlot intentionally uses
    // undefined for optional fields; JSON storage removes those keys. Hashing
    // the in-memory pre-serialization object would therefore produce a hash
    // that can never match the stored release read back by the build.
    snapshot = JSON.parse(JSON.stringify(snapshot));
    const hash = SocialStore.sha256(snapshot);
    const rotation = (snapshot.meta && snapshot.meta.rotation) || {};
    const eligible = Array.isArray(rows)
      ? SocialStore.approvedContentRows(rows).length
      : 0;
    if (storeRelease && !unpublishSelected && eligible < 1) {
      return SocialStore.response(409, {
        ok: false,
        version: VERSION,
        error: "no_eligible_social_candidates",
        message:
          "검증을 통과한 실제 소셜 후보가 0개이므로 빈 적용본은 저장·배포하지 않았습니다.",
        appliedSection: sectionKey || null,
        approvedRows: Array.isArray(rows) ? rows.length : 0,
        eligibleRows: eligible,
        buildHook: buildHookStatus(),
      });
    }
    const release = {
      release_id:
        "social_snapshot_" +
        SocialStore.shortHash({ hash, at: SocialStore.nowIso() }),
      status: storeRelease ? "stored" : "preview",
      generated_by: SocialStore.compact(
        actor.email || actor.memberId || "admin",
        200,
      ),
      rotation_salt:
        text(params.rotationSalt || params.salt) ||
        new Date().toISOString().slice(0, 10),
      section_counts: rotation.counts || {},
      snapshot_hash: hash,
      snapshot,
      notes: SocialStore.compact(
        "scope=" +
          scopeToken(route) +
          ";" +
          (unpublishSelected
            ? sectionKey
              ? "section_selected_unpublish:" + sectionKey
              : "all_sections_selected_unpublish"
            : sectionKey
              ? "section_actual_apply:" + sectionKey
              : "all_social_sections_actual_apply") +
          ";mode=" + publishMode +
          (params.notes ? ";" + params.notes : ""),
        1000,
      ),
      created_at: SocialStore.nowIso(),
    };
    const publicationPlan = releasedIdsBySection(snapshot);
    const publicationPlanHash = SocialStore.sha256(publicationPlan);
    const publicationPlanCount = Object.values(publicationPlan).reduce(
      (sum, list) => sum + (Array.isArray(list) ? list.length : 0),
      0,
    );
    const publicationDiff = publicationPlanDiff(previousPublicationPlan, publicationPlan);

    if (
      publishMode === "selected_sections_front_publish" &&
      publicationDiff.changedSections.some((key) => !requestedSections.includes(key))
    ) {
      return SocialStore.response(409, {
        ok: false,
        version: VERSION,
        error: "selected_section_isolation_violation",
        reportType,
        actionType: publishMode,
        requestedSections,
        omittedSections,
        changedSections: publicationDiff.changedSections,
        publicationDiff,
        preservedExistingFront: true,
        buildQueued: false,
        message: "선택하지 않은 SNS 섹션의 게시 계획까지 변경되는 것으로 계산되어 기존 프론트를 보존했습니다.",
      });
    }

    // Same public candidate plan means the visible Social front would not change.
    // Do not create another release row and do not spend a Netlify build for an
    // identical publication. Metadata timestamps are intentionally ignored here;
    // the canonical candidate-ID plan is the deployment identity.
    if (
      storeRelease &&
      actualApplyOperation &&
      !unpublishSelected &&
      hasDurablePreviousRelease &&
      publicationPlanHash === previousPublicationPlanHash
    ) {
      return SocialStore.response(200, {
        ok: true,
        version: VERSION,
        reportType,
        actionType: publishMode,
        operation: "actual_front_apply",
        effectiveOperation: "actual_front_apply",
        appliedSection: sectionKey || null,
        appliedAllSections: !sectionKey,
        requestedSections,
        omittedSections,
        requestedCandidateIds: candidateIds.length,
        exactCandidateSelectionApplied: exactCandidateSelection,
        serverAuthoritativeCandidateSelection,
        resolvedCandidateRows: Array.isArray(rows) ? rows.length : 0,
        resolvedCandidateIds: Array.isArray(rows)
          ? rows.map((row) => SocialStore.text(row && row.id)).filter(Boolean)
          : [],
        approvedRows: Array.isArray(rows) ? rows.length : 0,
        eligibleRows: eligible,
        previousPublicationPlanHash,
        deployedPublicationPlanHash,
        publicationPlanHash,
        publicationPlanCount,
        publicationPlanBySection: Object.fromEntries(
          Object.entries(publicationPlan).map(([key, list]) => [key, Array.isArray(list) ? list.length : 0]),
        ),
        publicationDiff,
        noChange: true,
        duplicateDeploymentPrevented: true,
        deploymentRequired: false,
        runtimeFrontReady: true,
        releaseStored: false,
        releaseStoredVerified: false,
        actualFrontApplyStored: false,
        actualFrontApplyQueued: false,
        actualApplyRequested: true,
        storeReleaseRequested: true,
        frontPublicationStatus: "unchanged_no_deploy",
        buildHook: buildHookStatus(),
        buildTrigger: {
          ok: true,
          status: "skipped_unchanged",
          queued: false,
          duplicateDeploymentPrevented: true,
          message: "마지막 정상 Social 게시 계획과 동일하여 새 Release 저장과 Netlify 배포를 모두 생략했습니다.",
        },
        route,
        safety: {
          runtimeFileWrite: false,
          preservedExistingFront: true,
          duplicateNetlifyBuildPrevented: true,
          sharedCommerceSearchBankMutation: false,
        },
      });
    }

    // Fail closed before writing a stored release or queuing Netlify when a
    // normal publish unexpectedly resolves to zero real candidates. This is
    // intentionally different from an explicit unpublish, where zero rows is
    // the valid final state. Keeping the two operations distinct prevents an
    // intermittent empty read from becoming a destructive persisted release.
    if (storeRelease && !unpublishSelected && publicationPlanCount === 0) {
      return SocialStore.response(409, {
        ok: false,
        version: VERSION,
        reason: "empty_publication_plan",
        publicationPlanCount: 0,
        preservedExistingFront: true,
        buildQueued: false,
        message: "공개할 승인 소셜 콘텐츠가 0건으로 계산되어 기존 프론트를 보존했습니다. 후보 상태를 새로고침한 뒤 다시 실행해 주세요.",
      });
    }

    // Durable release persistence is a hard gate for the canonical build.
    // Production diagnostics showed that Netlify could previously be queued
    // even when the release-table insert failed; that made a publish appear to
    // work temporarily but left no persistent source for a later browser visit.
    // Store and read back the exact release/hash before any build is queued.
    let stored = null;
    let storedVerified = false;
    let releaseStoreWarning = null;
    if (storeRelease) {
      try {
        stored = await storeReleaseCompat(release);
        if (stored && (!Array.isArray(stored) || stored.length > 0)) {
          try {
            storedVerified = await verifyStoredRelease(release);
          } catch (verifyError) {
            releaseStoreWarning = {
              code: (verifyError && verifyError.code) || "social_release_readback_failed",
              message: text(verifyError && verifyError.message) || "stored release readback failed",
            };
          }
          if (!storedVerified && !releaseStoreWarning) {
            releaseStoreWarning = {
              code: "social_release_readback_failed",
              message: "stored release readback returned no exact matching row",
            };
          }
        } else {
          releaseStoreWarning = {
            code: "social_release_store_empty",
            message: "release insert returned no representation",
          };
        }
      } catch (storeError) {
        releaseStoreWarning = {
          code: (storeError && storeError.code) || "social_release_store_failed",
          statusCode: storeError && storeError.statusCode || null,
          message: text(storeError && storeError.message) || String(storeError),
        };
      }
    }

    let buildTrigger = null;
    const forceStaticBuild = params.forceBuild === true || params.forceBuild === "true" || params.forceBuild === "1" || process.env.SOCIAL_FORCE_STATIC_BUILD === "1";
    if (storeRelease && storedVerified) {
      if (forceStaticBuild) {
        buildTrigger = await triggerCanonicalBuild(
          release,
          unpublishSelected ? "unpublish" : "publish",
          route,
          {
            publicationPlan,
            publicationPlanHash,
            publishMode,
            requestedSections,
          },
        );
      } else {
        buildTrigger = {
          ok: true,
          queued: false,
          status: "skipped_runtime_release_live",
          releaseId: text(release && release.release_id) || null,
          message: "저장된 Social Release를 프론트가 직접 읽으므로 일반 콘텐츠 적용에서는 Netlify 재배포를 생략했습니다.",
        };
      }
    } else if (storeRelease) {
      buildTrigger = {
        ok: false,
        queued: false,
        status: "durable_release_required",
        releaseId: text(release && release.release_id) || null,
        message:
          "승인 Social Release의 영구 저장·해시 검증이 완료되지 않아 기존 프론트를 보존했습니다.",
      };
    }
    if (
      params.download === "1" ||
      params.download === true ||
      params.format === "snapshot"
    ) {
      return {
        statusCode: 200,
        headers: {
          "content-type": "application/json; charset=utf-8",
          "cache-control": "private, no-store, max-age=0",
          "content-disposition":
            "attachment; filename=social.snapshot.generated.json",
        },
        body: JSON.stringify(snapshot, null, 2) + "\n",
      };
    }
    const runtimeFrontReady = !!(storeRelease && storedVerified);
    const staticBuildQueued = !!(buildTrigger && buildTrigger.ok && buildTrigger.queued !== false && buildTrigger.status !== "skipped_runtime_release_live");
    return SocialStore.response(staticBuildQueued ? 202 : 200, {
      ok: true,
      version: VERSION,
      reportType,
      actionType: publishMode,
      requestedSections,
      omittedSections,
      baseFile: base.file,
      hash,
      approvedRows: Array.isArray(rows) ? rows.length : 0,
      eligibleRows: eligible,
      appliedSection: sectionKey || null,
      appliedAllSections: !sectionKey,
      operation: unpublishSelected
        ? "selected_front_unpublish"
        : actualApplyOperation
          ? "actual_front_apply"
          : (operation || "preview"),
      requestMethod: event.httpMethod,
      effectiveOperation: unpublishSelected
        ? "selected_front_unpublish"
        : actualApplyOperation
          ? "actual_front_apply"
          : (operation || "preview"),
      requestedCandidateIds: candidateIds.length,
      exactCandidateSelectionApplied:
        !unpublishSelected && exactCandidateSelection,
      serverAuthoritativeCandidateSelection,
      resolvedCandidateRows: Array.isArray(rows) ? rows.length : 0,
      resolvedCandidateIds: Array.isArray(rows)
        ? rows.map((row) => SocialStore.text(row && row.id)).filter(Boolean)
        : [],
      removedSlots: unpublish ? unpublish.removedSlots : 0,
      removedBySection: unpublish ? unpublish.removedBySection : {},
      releaseId: text(release && release.release_id) || null,
      releaseStored: !!stored,
      releaseStoredVerified: storedVerified,
      runtimeFrontReady,
      releaseStoreWarning,
      previousPublicationPlanHash,
      deployedPublicationPlanHash,
      publicationPlanHash,
      publicationPlanCount,
      publicationDiff,
      noChange: false,
      duplicateDeploymentPrevented: false,
      deploymentRequired: forceStaticBuild,
      publicationPlanBySection: Object.fromEntries(
        Object.entries(publicationPlan).map(([key, list]) => [key, Array.isArray(list) ? list.length : 0]),
      ),
      canonicalPublicationPlan: true,
      actualFrontApplyStored: !!stored && storedVerified && !unpublishSelected,
      actualFrontUnpublishStored: !!stored && storedVerified && unpublishSelected,
      actualFrontApplyQueued:
        staticBuildQueued && !unpublishSelected,
      actualFrontUnpublishQueued:
        staticBuildQueued && unpublishSelected,
      actualApplyRequested: actualApplyOperation,
      storeReleaseRequested: storeRelease,
      frontPublicationStatus: !storeRelease
        ? "preview_only"
        : runtimeFrontReady && !forceStaticBuild
          ? "stored_release_live"
          : staticBuildQueued
            ? "canonical_build_queued"
            : "release_stored_waiting_for_build",
      buildHook: buildHookStatus(),
      buildTrigger,
      stored,
      rotation,
      route,
      release:
        params.includeSnapshot === "1"
          ? release
          : Object.assign({}, release, { snapshot: undefined }),
      snapshot: params.includeSnapshot === "1" ? snapshot : undefined,
      safety: {
        runtimeFileWrite: false,
        socialSnapshotMutation: false,
        frontReadsLatestStoredSnapshot: true,
        adminReadsLatestStoredReleaseState: true,
        canonicalBuildPipeline: forceStaticBuild,
        normalContentPublicationRequiresDeploy: false,
        socialSearchBankIsolated: true,
        sharedCommerceSearchBankMutation: false,
        publicSnapshotSource: "/data/social.snapshot.json",
        pipelineOrder: [
          "administrator_publication_plan",
          "optional_stored_social_release_audit",
          "social_policy_and_psom_gate",
          "data/social-searchbank.release.snapshot.json",
          "existing_snapshot_engine_social_target",
          "data/social.snapshot.json",
          "existing_social_automap",
        ],
        sampleSlotsPreserved: true,
        selectedCandidatesReturnedToWaiting: unpublishSelected,
        externalProviderCalls: false,
        externalMembershipOverride: false,
      },
    });
  } catch (error) {
    return SocialStore.response(error.statusCode || 500, {
      ok: false,
      version: VERSION,
      error: error.code || "social_snapshot_publish_failed",
      message: error.message || String(error),
    });
  }
};

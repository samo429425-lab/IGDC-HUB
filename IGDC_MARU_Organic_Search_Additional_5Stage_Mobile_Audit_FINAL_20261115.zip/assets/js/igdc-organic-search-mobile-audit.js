/* IGDC/MARU Play Console CSV audit. Browser-only: never uploads CSV. */
(function(){
 "use strict";
 if(window.__IGDC_OS_PLAY_CSV__)return;
 window.__IGDC_OS_PLAY_CSV__=true;
 var root=document.getElementById("igdc-organic-search-diagnostic");
 if(!root)return;
 var holder=document.createElement("details");
 holder.id="igdc-os-play-csv";
 holder.style.cssText="margin-top:12px;border-top:1px solid #d7e5f2;padding-top:10px";
 var label=document.createElement("summary");
 label.style.cssText="font-weight:700;cursor:pointer;color:#234c76";
 label.textContent="Android Google Play Console CSV 검색 유입 분석 (로컬·선택)";
 holder.appendChild(label);
 var note=document.createElement("p");
 note.style.cssText="font-size:12px;line-height:1.55;color:#475c73";
 note.textContent="Play Console에서 내려받은 CSV/TSV 파일을 선택하면 브라우저 안에서만 분석합니다. 서버 전송 없음. 열 이름과 단위가 확인된 수치만 JSON에 기록하며 검색 순위는 추정하지 않습니다.";
 holder.appendChild(note);
 var input=document.createElement("input");
 input.type="file";input.accept=".csv,.tsv,.txt,text/csv,text/tab-separated-values";
 input.setAttribute("aria-label","Play Console CSV 파일 선택");
 holder.appendChild(input);
 var status=document.createElement("p");status.style.cssText="font-size:12px;color:#174872;white-space:pre-wrap";status.textContent="CSV를 선택하지 않았습니다.";holder.appendChild(status);
 var target=document.createElement("pre");
 target.style.cssText="max-height:220px;overflow:auto;word-break:break-word;white-space:pre-wrap;font-size:11px;background:white;border:1px solid #dbe5f1;padding:9px";
 target.textContent="분석 전";holder.appendChild(target);
 var anchor=root.querySelector("details");
 if(anchor)root.insertBefore(holder,anchor);else root.appendChild(holder);
 function delimiter(text){
  var first=text.split(/\r?\n/,1)[0]||"",options=[",","\t",";"];
  var scores=options.map(d=>({delimiter:d,count:first.split(d).length}));
  scores.sort((a,b)=>b.count-a.count);return scores[0].delimiter;
 }
 function csvRows(src,delim,limit){
  var rows=[],row=[],value="",quoted=false;
  for(var i=0;i<src.length;i++){
   var c=src[i];
   if(c==='"'){if(quoted&&src[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}
   else if(c===delim&&!quoted){row.push(value);value="";}
   else if((c==="\n"||c==="\r")&&!quoted){
    if(c==="\r"&&src[i+1]==="\n")i++;
    row.push(value);value="";
    if(row.some(x=>String(x).trim()))rows.push(row);
    row=[];
    if(rows.length>=limit)break;
   }else value+=c;
  }
  if(rows.length<limit&&(value||row.length)){row.push(value);if(row.some(x=>String(x).trim()))rows.push(row);}
  return rows;
 }
 function norm(s){return String(s||"").replace(/^\uFEFF/,"").toLowerCase().replace(/[_\s\-]+/g," ").trim();}
 function findIndex(headers,patterns){
  return headers.findIndex(h=>patterns.some(p=>p.test(h)));
 }
 function asNumber(s){
  var v=String(s==null?"":s).trim().replace(/[,\s]/g,"").replace(/%$/,"");
  return v!==""&&/^-?\d+(?:\.\d+)?$/.test(v)?Number(v):null;
 }
 function counter(obj,key,val){if(!key)return;obj[key]=(obj[key]||0)+val;}
 function top(obj){return Object.keys(obj).sort((a,b)=>obj[b]-obj[a]).slice(0,12).map(k=>({name:k,count:obj[k]}));}
 function parse(text,file){
  var delim=delimiter(text),rows=csvRows(text.replace(/^\uFEFF/,""),delim,20002);
  if(rows.length<2)throw Error("표 머리글과 데이터 행이 있는 CSV가 필요합니다.");
  var raw=rows[0],headers=raw.map(norm),data=rows.slice(1,20001);
  var iSource=findIndex(headers,[/traffic source/,/acquisition source/,/유입 경로/,/트래픽 소스/,/획득 경로/]);
  var iCountry=findIndex(headers,[/^country/,/^국가$/,/(?:user )?country /]);
  var iQuery=findIndex(headers,[/search term/,/search query/,/검색어/,/^keyword$/]);
  var iVisitor=findIndex(headers,[/store listing visitors/,/store listing visits/,/스토어 등록정보 방문자/,/^visitors$/,/^방문자$/]);
  var iAcq=findIndex(headers,[/store listing acquisitions/,/store listing installs/,/스토어 등록정보 획득/,/스토어 등록정보 설치/]);
  var iClick=findIndex(headers,[/store listing clicks/,/install or open clicks/,/설치 또는 열기 클릭/]);
  var iDate=findIndex(headers,[/^date$/,/^날짜$/]);
  var iVersion=findIndex(headers,[/version code/,/app version/,/버전 코드/,/앱 버전/]);
  var matched={source:iSource>=0,country:iCountry>=0,searchTerm:iQuery>=0,visitors:iVisitor>=0,acquisitions:iAcq>=0,clicks:iClick>=0,date:iDate>=0,version:iVersion>=0};
  if(!matched.visitors&&!matched.acquisitions&&!matched.clicks&&!matched.searchTerm)throw Error("지원되는 Google Play 방문·설치 클릭·검색어 열을 확인하지 못했습니다. CSV 머리글과 보고서 종류를 확인하세요.");
  var totalVisits=0,totalAcq=0,totalClicks=0,searchVisits=0,searchAcq=0,searchClicks=0;
  var visitsRows=0,acqRows=0,clickRows=0,tagged=0,countries=Object.create(null),queries=Object.create(null),versions=Object.create(null);
  for(var k=0;k<data.length;k++){
   var row=data[k],src=iSource>=0?norm(row[iSource]):"",isSearch=Boolean(src&&(/play (store )?search|google play search|검색/.test(src))),
       visits=iVisitor>=0?asNumber(row[iVisitor]):null,acq=iAcq>=0?asNumber(row[iAcq]):null,clicks=iClick>=0?asNumber(row[iClick]):null;
   if(visits!==null&&visits>=0){totalVisits+=visits;visitsRows++;if(isSearch)searchVisits+=visits;}
   if(acq!==null&&acq>=0){totalAcq+=acq;acqRows++;if(isSearch)searchAcq+=acq;}
   if(clicks!==null&&clicks>=0){totalClicks+=clicks;clickRows++;if(isSearch)searchClicks+=clicks;}
   if(isSearch)tagged++;
   if(iCountry>=0)counter(countries,String(row[iCountry]||"").trim().slice(0,60),1);
   if(iQuery>=0)counter(queries,String(row[iQuery]||"").trim().slice(0,110),1);
   if(iVersion>=0)counter(versions,String(row[iVersion]||"").trim().slice(0,40),1);
  }
  return {
   schema:"igdc-maru-play-console-local-csv-audit.v1",
   auditedAt:new Date().toISOString(),
   source:"User-selected Play Console CSV; not independently verified",
   processing:"browser-only; raw CSV not transmitted or retained",
   reportFileName:String(file.name||"report.csv").slice(0,120),
   rowsAnalyzed:data.length,truncated:rows.length>=20002,delimiter:delim==="\t"?"tab":delim===";"?"semicolon":"comma",
   recognizedColumns:matched,
   totals:{
    listingVisits:visitsRows?totalVisits:null,
    listingAcquisitions:acqRows?totalAcq:null,
    installOrOpenClicks:clickRows?totalClicks:null,
    taggedPlaySearchRows:matched.source?tagged:null,
    playSearchVisits:matched.source&&visitsRows?searchVisits:null,
    playSearchAcquisitions:matched.source&&acqRows?searchAcq:null,
    playSearchClicks:matched.source&&clickRows?searchClicks:null
   },
   rowsByCountry:top(countries),rowsBySearchTerm:top(queries),rowsByVersion:top(versions),
   rankingPosition:null,
   limitations:[
    "Search rows are only distinguished when a traffic-source column explicitly identifies Play search.",
    "Sum may include report subtotals or mixed date/country groupings; verify dimensions before interpreting.",
    "Counts may represent installs, acquisitions, or install/open clicks depending on original column labels and report date.",
    "CSV counts do not establish app rank, organic impression share or causation."
   ]
  };
 }
 input.addEventListener("change",async function(){
  window.IGDC_OS_MOBILE_AUDIT_DATA=null;
  var f=input.files&&input.files[0];if(!f)return;
  if(f.size>2*1024*1024){status.textContent="파일이 2MB를 초과합니다. Play Console에서 기간을 나누어 CSV를 내려받으세요.";return;}
  try{
   var content=await f.text();
   var report=parse(content,f);
   window.IGDC_OS_MOBILE_AUDIT_DATA=report;
   status.textContent="로컬 CSV 분석 완료 · "+report.rowsAnalyzed+"개 행 · Play 검색 확인 "+(report.totals.taggedPlaySearchRows===null?"소스 열 없음":report.totals.taggedPlaySearchRows+"개 행")+". 점검 JSON 다운로드에 포함됩니다.";
   target.textContent=JSON.stringify({recognizedColumns:report.recognizedColumns,totals:report.totals,rowsByCountry:report.rowsByCountry,rowsByVersion:report.rowsByVersion,limitations:report.limitations},null,2);
  }catch(e){status.textContent="CSV 분석 불가: "+String(e&&e.message||e).slice(0,180);target.textContent="열 이름·파일 인코딩을 확인하세요.";}
 });
})();

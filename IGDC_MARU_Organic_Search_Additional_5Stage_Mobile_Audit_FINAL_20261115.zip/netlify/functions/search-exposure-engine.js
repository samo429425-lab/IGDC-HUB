"use strict";
// Legacy public alias: require verified administrator permissions before submission.
const auth=require("./lib/global-slot-console-auth");
const engine=require("./global-search-exposure-engine");
exports.handler=async event=>{
 const headers={"content-type":"application/json; charset=utf-8","cache-control":"no-store","x-robots-tag":"noindex"};
 if(String(event&&event.httpMethod||"GET").toUpperCase()!=="POST")return{statusCode:405,headers,body:JSON.stringify({ok:false,error:"Administrator POST only"})};
 try{
  const actor=await auth.resolveUser(event),cap=auth.capability(actor);
  if(!cap||!(cap.owner||cap.policy))return{statusCode:403,headers,body:JSON.stringify({ok:false,error:"Administrator policy permission required"})};
  // Explicit manual submission is gated by the engine's existing secret and force controls.
  return engine.handler(event);
 }catch(e){return{statusCode:e&&e.statusCode||403,headers,body:JSON.stringify({ok:false,error:"Administrator verification required"})};}
};

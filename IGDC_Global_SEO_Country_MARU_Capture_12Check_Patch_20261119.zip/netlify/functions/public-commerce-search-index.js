"use strict";
// Read-only, public, verified market listings; no IP-based crawler cloaking.
const {buildRegistry}=require("./lib/search-exposure/registry");
const ROOT="https://igdcglobal.com/.netlify/functions/public-commerce-search-index";
function esc(x){return String(x==null?"":x).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function page(title,description,url,html,robots="index,follow"){return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><meta name="description" content="'+esc(description)+'"><meta name="robots" content="'+robots+'"><link rel="canonical" href="'+esc(url)+'"><style>body{font:16px/1.7 system-ui,sans-serif;background:#f5f8fc;color:#17324d;margin:0}main{max-width:1000px;margin:auto;padding:28px 18px 65px}a{color:#0753a0}section{background:white;border:1px solid #d9e4f2;border-radius:12px;padding:20px}li{margin:5px 0}</style></head><body><main><nav><a href="/home">IGDC Global</a> / <a href="/distributionhub">Distribution Hub</a></nav>'+html+'</main></body></html>';}
function reply(code,body){return{statusCode:code,headers:{"content-type":"text/html; charset=utf-8","cache-control":"public,max-age=180,s-maxage=600","x-content-type-options":"nosniff"},body};}
exports.handler=async event=>{
 try{
  const registry=buildRegistry(),q=event&&event.queryStringParameters||{},country=String(q.country||"").toUpperCase();
  const markets=Object.entries(registry.countryCounts||{}).filter(([code,n])=>/^[A-Z]{2}$/.test(code)&&Number(n)>0).sort((a,b)=>a[0].localeCompare(b[0]));
  if(!country){
   const links=markets.map(([cc,n])=>'<li><a href="'+ROOT+'?country='+cc+'">'+cc+' — '+n+' verified product-market pages</a></li>').join("");
   return reply(200,page("IGDC Global — verified country product directory","Public approved IGDC product listings organized by verified sales country.",ROOT,'<h1>IGDC verified product markets</h1><p>각 국가에서 공개 승인된 상품을 직접 확인할 수 있습니다. Public listings are available to crawlers and visitors regardless of IP address.</p><section><ul>'+links+'</ul></section>'));
  }
  if(!/^[A-Z]{2}$/.test(country)||!markets.some(([cc])=>cc===country))return reply(404,page("Market not found","No verified products",ROOT,"<h1>No verified products for this market</h1>","noindex,follow"));
  const list=(registry.targets||[]).filter(t=>t&&t.kind==="commerce-market"&&t.marketCountry===country&&typeof t.url==="string"&&t.url.startsWith("https://igdcglobal.com/product/"));
  const perPage=80,pages=Math.max(1,Math.ceil(list.length/perPage)),n=Number(q.page||1);
  if(!Number.isSafeInteger(n)||n<1||n>pages)return reply(404,page("Page not found","Invalid page",ROOT,"<h1>Page not found</h1>","noindex,follow"));
  const base=ROOT+"?country="+country,canonical=base+(n>1?"&page="+n:"");
  const rows=list.slice((n-1)*perPage,n*perPage).map(t=>'<li><a href="'+esc(t.url)+'">'+esc(t.title||t.id)+'</a>'+(t.category?' — '+esc(t.category):'')+'</li>').join("");
  const prev=n>1?'<a href="'+base+(n>2?'&page='+(n-1):'')+'">Previous page</a>':"";
  const next=n<pages?'<a href="'+base+'&page='+(n+1)+'">Next page</a>':"";
  const body='<h1>IGDC verified products in '+country+'</h1><p>'+list.length+' approved country-market pages · page '+n+' of '+pages+'</p><p>Actual price, inventory, delivery and seller details are determined by the verified product page and seller.</p><section><ul>'+rows+'</ul></section><nav>'+prev+' '+next+'</nav><p><a href="'+ROOT+'">All country markets</a></p>';
  return reply(200,page("IGDC products — "+country+" — page "+n,"Verified public IGDC Distribution product pages for "+country,canonical,body));
 }catch(_e){return reply(503,page("Directory temporarily unavailable","Temporary error",ROOT,"<h1>Temporary unavailable</h1>","noindex,follow"));}
};

"use strict";

/**
 * Builds a publishable media.snapshot.json from approved Supabase candidates.
 * It does not write runtime files. Use download=1 to receive JSON, or storeRelease=true
 * to save a release copy in Supabase for deployment/build tooling.
 */
const fs = require("fs");
const path = require("path");
const MediaStore = require("./lib/media-candidate-store.v1");
const SharedAdminAuth = require("./lib/global-slot-console-auth");
const MediaReleaseDispatch = require("./lib/media-release-dispatch.v1");
const MediaReleaseAdapter = require("./lib/media-searchbank-release-adapter.v1");

const VERSION = "media-snapshot-publish-v1.7.0-front-trigger-diagnostics";
const MANUAL_SECTIONS=Array.from(MediaStore.ALLOWED_SECTIONS);
const STATUS_SECTIONS=["media-trending"].concat(MANUAL_SECTIONS);

async function actorFor(event, storeRelease){
  const actor = await SharedAdminAuth.resolveUser(event);
  SharedAdminAuth.requireCapability(actor, storeRelease ? "approve" : "mediaRead");
  return actor;
}
function readJson(file){try{return JSON.parse(fs.readFileSync(file,"utf8"));}catch(_e){return null;}}
function baseSnapshot(){
  const root=process.cwd();
  const files=[
    path.join(root,"data","media.snapshot.json"),
    path.join(root,"netlify","functions","data","media.snapshot.json"),
    path.join(__dirname,"data","media.snapshot.json")
  ];
  for(const file of files){const doc=readJson(file);if(doc)return {file,doc};}
  const sections={"media-trending":[]};
  Array.from(MediaStore.ALLOWED_SECTIONS).forEach((key)=>{sections[key]={key,title:key,slots:[]};});
  return {file:"generated-empty",doc:{version:"media.snapshot.empty",type:"media_snapshot",sections,meta:{}}};
}
function queryApproved(limit){
  const safeLimit=Math.max(1,Math.min(2000,Number(limit)||1800));
  return "select=*&review_status=eq.approved&verification_status=eq.approved_for_snapshot&candidate_only=eq.false&seed_content=eq.false&order=section_key.asc,approved_at.desc,title.asc&limit="+safeLimit;
}
function clone(value){return JSON.parse(JSON.stringify(value==null?{}:value));}
function frontContentEnabled(row){
  const raw=MediaStore.plain(row&&row.raw),control=MediaStore.plain(raw.frontControl);
  return control.enabled!==false;
}
function sectionSlots(section){return Array.isArray(section)?section:(section&&Array.isArray(section.slots)?section.slots:[]);}
function blankSlot(slot,index){
  return{slotId:Number(slot&&slot.slotId)||index+1,contentId:null,title:null,thumb:"#",provider:null};
}
function cleanBaseSnapshot(snapshot){
  const next=clone(snapshot);
  next.sections=Object.assign({},next.sections||{});
  MANUAL_SECTIONS.forEach((sectionKey)=>{
    const original=next.sections[sectionKey];
    const objectSection=Array.isArray(original)?{key:sectionKey,title:sectionKey,slots:original}:Object.assign({},original||{key:sectionKey,title:sectionKey});
    const slots=sectionSlots(original).map((slot,index)=>slot&&slot.managedBy==="media-snapshot-publish"?blankSlot(slot,index):clone(slot));
    objectSection.slots=slots;
    next.sections[sectionKey]=objectSection;
  });
  return next;
}
function managedCounts(snapshot){
  const sections={};let total=0;
  MANUAL_SECTIONS.forEach((sectionKey)=>{
    const count=sectionSlots(snapshot&&snapshot.sections&&snapshot.sections[sectionKey]).filter((slot)=>slot&&slot.managedBy==="media-snapshot-publish"&&MediaStore.MediaPolicy.publicReleaseAllowed(slot)).length;
    sections[sectionKey]=count;total+=count;
  });
  return{sections,total};
}
function stampReleaseControl(snapshot, action, sectionKey, actor, publicationRequested){
  const next=clone(snapshot),counts=managedCounts(next);
  next.meta=Object.assign({},next.meta||{}, {
    generatedAt:MediaStore.nowIso(),
    generatedBy:"media-snapshot-publish",
    filled:counts.sections,
    releaseControl:{
      action,sectionKey:sectionKey||null,
      requestedAt:MediaStore.nowIso(),
      requestedBy:MediaStore.compact(actor&&actor.email||actor&&actor.memberId||"admin",200),
      publicationRequested:publicationRequested===true
    }
  });
  return next;
}
async function latestStoredRelease(){
  const query=new URLSearchParams();
  query.set("select","release_id,snapshot_hash,snapshot,status,created_at,created_by");
  query.set("status","in.(stored,applied)");
  query.set("order","created_at.desc");
  query.set("limit","1");
  const rows=await MediaStore.supabase(MediaStore.rest(MediaStore.RELEASE_TABLE,query.toString()),{method:"GET"});
  return Array.isArray(rows)&&rows[0]?rows[0]:null;
}
function statusPayload(release){
  if(!release)return{ok:true,version:VERSION,hasRelease:false,totalManagedSlots:0,sections:Object.fromEntries(MANUAL_SECTIONS.map((key)=>[key,0]))};
  const snapshot=release.snapshot&&typeof release.snapshot==="object"?release.snapshot:{};
  const counts=managedCounts(snapshot);
  const control=snapshot.meta&&snapshot.meta.releaseControl||{};
  const pipeline=snapshot.meta&&snapshot.meta.releasePipeline||{};
  return{
    ok:true,version:VERSION,hasRelease:true,
    releaseId:MediaStore.text(release.release_id),createdAt:MediaStore.text(release.created_at),
    releaseStatus:MediaStore.text(release.status)||"stored",
    action:MediaStore.text(control.action)||"legacy_release",sectionKey:MediaStore.text(control.sectionKey)||null,
    totalManagedSlots:counts.total,sections:counts.sections,
    pipelineApplied:pipeline.status==="applied",
    pipelineVersion:MediaStore.text(pipeline.version)||null,
    appliedAt:MediaStore.text(pipeline.appliedAt)||null
  };
}
function eligibleCounts(rows){
  const sections=Object.fromEntries(MANUAL_SECTIONS.map((key)=>[key,{approved:0,eligible:0,frontDisabled:0,blocked:0}]));
  (Array.isArray(rows)?rows:[]).forEach((row)=>{
    const key=MediaStore.normalizeSection(row&&row.section_key);if(!sections[key])return;
    sections[key].approved+=1;
    if(!frontContentEnabled(row)){sections[key].frontDisabled+=1;return;}
    if(MediaStore.snapshotEligible(row))sections[key].eligible+=1;else sections[key].blocked+=1;
  });
  return sections;
}
function publicOrigin(){
  for(const raw of [process.env.URL,process.env.DEPLOY_PRIME_URL]){
    try{const url=new URL(MediaStore.text(raw));if(url.protocol==="https:")return url.origin;}catch(_error){}
  }
  return"";
}
async function fetchPublicJson(origin,pathName){
  if(!origin)return{checked:false,ok:false,reason:"public_origin_unavailable",document:null};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
    const response=await fetch(origin+pathName+(pathName.includes("?")?"&":"?")+"pipeline_probe="+Date.now(),{signal:controller.signal,headers:{accept:"application/json","cache-control":"no-cache"}});
    if(!response.ok)return{checked:true,ok:false,reason:"public_http_"+response.status,document:null};
    const document=await response.json();return{checked:true,ok:true,reason:null,document};
  }catch(error){return{checked:true,ok:false,reason:/abort/i.test(String(error&&error.name||error))?"public_probe_timeout":"public_probe_failed",document:null};}
  finally{clearTimeout(timer);}
}
async function pipelineStatusDocument(release,rows,probePublic){
  const candidateSections=eligibleCounts(rows),releaseSnapshot=release&&release.snapshot||{};
  const releaseState=MediaReleaseAdapter.sectionState(releaseSnapshot),pipeline=releaseSnapshot&&releaseSnapshot.meta&&releaseSnapshot.meta.releasePipeline||{};
  let publicMedia={checked:false,ok:false,reason:"probe_not_requested",document:null};
  let publicBank={checked:false,ok:false,reason:"probe_not_requested",document:null};
  if(probePublic){
    const origin=publicOrigin();
    [publicMedia,publicBank]=await Promise.all([
      fetchPublicJson(origin,"/data/media.snapshot.json"),
      fetchPublicJson(origin,"/data/search-bank.snapshot.json")
    ]);
  }
  const publicState=publicMedia.document?MediaReleaseAdapter.sectionState(publicMedia.document):{totalManaged:0,sections:{}};
  const publicPipeline=publicMedia.document&&publicMedia.document.meta&&publicMedia.document.meta.releasePipeline||{};
  const publicBankItems=publicBank.document?MediaReleaseAdapter.ownedItems(publicBank.document,release&&release.release_id):[];
  const sections={};
  MANUAL_SECTIONS.forEach((key)=>{
    sections[key]={
      approvedCandidates:candidateSections[key].approved,
      eligibleCandidates:candidateSections[key].eligible,
      frontDisabledCandidates:candidateSections[key].frontDisabled,
      policyBlockedCandidates:candidateSections[key].blocked,
      releaseManagedSlots:releaseState.sections[key].managedCount,
      releaseContentIds:releaseState.sections[key].contentIds,
      publicManagedSlots:publicState.sections[key]?publicState.sections[key].managedCount:null,
      publicContentIds:publicState.sections[key]?publicState.sections[key].contentIds:[]
    };
  });
  const trendingSources=["media-movie","media-drama","media-variety","media-music"];
  const publicTrendingSlots=publicMedia.document?MediaReleaseAdapter.slotsOf(publicMedia.document.sections&&publicMedia.document.sections["media-trending"]):[];
  sections["media-trending"]={
    automatic:true,manualPublicationAllowed:false,sourceSections:trendingSources,
    approvedSourceCandidates:trendingSources.reduce((sum,key)=>sum+candidateSections[key].approved,0),
    eligibleSourceCandidates:trendingSources.reduce((sum,key)=>sum+candidateSections[key].eligible,0),
    releaseManagedSlots:0,releaseContentIds:[],
    publicSlotCount:publicMedia.ok?publicTrendingSlots.length:null,
    publicManagedSlots:0,publicContentIds:[]
  };
  const releaseId=MediaStore.text(release&&release.release_id),releaseApplied=pipeline.status==="applied";
  const publicReleaseMatches=publicMedia.ok===true&&MediaStore.text(publicPipeline.releaseId)===releaseId;
  const publicSectionsMatch=publicMedia.ok===true&&MANUAL_SECTIONS.every((key)=>{
    const expected=releaseState.sections[key],actual=publicState.sections[key];
    return actual&&JSON.stringify(expected.contentIds)===JSON.stringify(actual.contentIds);
  });
  const publicBankHash=publicBank.ok?MediaReleaseAdapter.sha256(publicBank.document):null;
  const publicBankMatches=publicBank.ok===true&&MediaStore.text(pipeline.searchBankHash)===publicBankHash;
  const publicMatches=publicReleaseMatches&&publicSectionsMatch&&publicBankMatches;
  const publicationTrigger=typeof MediaReleaseDispatch.configurationStatus==="function"?MediaReleaseDispatch.configurationStatus():{version:MediaReleaseDispatch.VERSION||null};
  return{
    ok:true,reportType:"igdc-media-front-pipeline-status",version:VERSION,adapterVersion:MediaReleaseAdapter.VERSION,generatedAt:MediaStore.nowIso(),
    pipelineComplete:releaseApplied&&(!probePublic||publicMatches),
    stages:{
      candidates:{source:"supabase.media_candidates",approvedRows:Array.isArray(rows)?rows.length:0,eligibleRows:(Array.isArray(rows)?rows:[]).filter(MediaStore.snapshotEligible).length,sections:candidateSections},
      release:{present:!!release,releaseId,status:MediaStore.text(release&&release.status)||null,requestHash:MediaStore.text(pipeline.requestHash||release&&release.snapshot_hash)||null,outputHash:MediaStore.text(release&&release.snapshot_hash)||null,action:MediaStore.text(releaseSnapshot&&releaseSnapshot.meta&&releaseSnapshot.meta.releaseControl&&releaseSnapshot.meta.releaseControl.action)||null,totalManagedSlots:releaseState.totalManaged,publicationTrigger},
      searchBank:{applied:releaseApplied&&!!MediaStore.text(pipeline.searchBankHash),hash:MediaStore.text(pipeline.searchBankHash)||null,releaseMediaItemCount:Number(pipeline.searchBankMediaCount||0),publicProbeChecked:publicBank.checked,publicProbeOk:publicBank.ok,publicProbeReason:publicBank.reason,publicHash:publicBankHash,publicHashMatches:publicBank.checked?publicBankMatches:null,publicReleaseMediaItemCount:publicBank.ok?publicBankItems.length:null},
      snapshotEngine:{applied:releaseApplied,version:MediaStore.text(pipeline.snapshotEngineVersion)||null,completedHandlers:Array.isArray(pipeline.snapshotEngineCompletedHandlers)?pipeline.snapshotEngineCompletedHandlers:[],appliedAt:MediaStore.text(pipeline.appliedAt)||null},
      publicMediaSnapshot:{checked:publicMedia.checked,ok:publicMedia.ok,reason:publicMedia.reason,releaseId:MediaStore.text(publicPipeline.releaseId)||null,releaseIdMatches:publicMedia.checked?publicReleaseMatches:null,sectionContentIdsMatch:publicMedia.checked?publicSectionsMatch:null,totalManagedSlots:publicMedia.ok?publicState.totalManaged:null}
    },
    sectionOrder:STATUS_SECTIONS,sections
  };
}
exports.buildPipelineStatusDocument=pipelineStatusDocument;
exports.handler = async function(event){
  if(event && event.httpMethod === "OPTIONS") return MediaStore.response(204,{});
  try{
    if(!["GET","POST"].includes(event.httpMethod)) return MediaStore.response(405,{ok:false,error:"method_not_allowed"});
    const params=Object.assign({}, event.queryStringParameters || {}, event.httpMethod === "POST" ? MediaStore.parseBody(event) : {});
    const publishFront = params.publishFront === true || params.publishFront === "true";
    const storeRelease = publishFront || params.storeRelease === true || params.storeRelease === "true";
    const actor=await actorFor(event, storeRelease);
    if(params.frontStatus === "1" || params.frontStatus === 1 || params.frontStatus === true){
      return MediaStore.response(200,statusPayload(await latestStoredRelease()));
    }
    if(params.pipelineStatus === "1" || params.pipelineStatus === 1 || params.pipelineStatus === true){
      const release=await latestStoredRelease();
      const rows=await MediaStore.selectCandidates(queryApproved(params.limit));
      const probePublic=params.probePublic === "1" || params.probePublic === 1 || params.probePublic === true;
      return MediaStore.response(200,await pipelineStatusDocument(release,rows,probePublic));
    }
    const frontAction=MediaStore.text(params.frontAction)||(publishFront?"publish_all":"preview_all");
    const sectionKey=MediaStore.normalizeSection(params.sectionKey);
    const sectionAction=frontAction==="publish_section"||frontAction==="stop_section";
    if(sectionAction&&!sectionKey){
      const error=new Error("섹션별 프론트 작업에는 올바른 미디어 섹션 키가 필요합니다.");
      error.statusCode=400;error.code="media_release_section_required";throw error;
    }
    if(!["preview_all","publish_all","publish_section","stop_section","stop_all"].includes(frontAction)){
      const error=new Error("지원하지 않는 프론트 공개 작업입니다.");
      error.statusCode=400;error.code="media_release_action_invalid";throw error;
    }
    const needsCandidates=!frontAction.startsWith("stop_");
    const allApprovedRows=needsCandidates?await MediaStore.selectCandidates(queryApproved(params.limit)):[];
    const scopedApprovedRows=sectionKey?allApprovedRows.filter((row)=>MediaStore.normalizeSection(row&&row.section_key)===sectionKey):allApprovedRows;
    const rows=scopedApprovedRows.filter(frontContentEnabled);
    const frontDisabledRows=scopedApprovedRows.filter((row)=>!frontContentEnabled(row));
    const base=baseSnapshot();
    const cleanBase=cleanBaseSnapshot(base.doc);
    const previous=publishFront?await latestStoredRelease():null;
    let snapshot;
    const buildOptions=Number(params.capacityPerSection)>0?{capacityPerSection:Number(params.capacityPerSection)}:{};
    if(frontAction==="stop_all"){
      snapshot=cleanBase;
    }else if(frontAction==="stop_section"){
      snapshot=clone(previous&&previous.snapshot||cleanBase);
      snapshot.sections=Object.assign({},snapshot.sections||{});
      snapshot.sections[sectionKey]=clone(cleanBase.sections&&cleanBase.sections[sectionKey]||{key:sectionKey,title:sectionKey,slots:[]});
    }else if(frontAction==="publish_section"){
      const generated=MediaStore.buildSnapshot(cleanBase,Array.isArray(rows)?rows:[],buildOptions);
      snapshot=clone(previous&&previous.snapshot||cleanBase);
      snapshot.sections=Object.assign({},snapshot.sections||{});
      snapshot.sections[sectionKey]=clone(generated.sections&&generated.sections[sectionKey]||cleanBase.sections[sectionKey]);
    }else{
      snapshot=MediaStore.buildSnapshot(cleanBase,Array.isArray(rows)?rows:[],buildOptions);
    }
    snapshot=stampReleaseControl(snapshot,frontAction,sectionKey,actor,publishFront);
    // Hash exactly the JSON document that will be persisted. JSON persistence drops
    // undefined-valued properties; hashing the pre-serialization object makes the
    // build-time integrity check fail even though the release itself is valid.
    snapshot=JSON.parse(JSON.stringify(snapshot));
    const hash=MediaStore.sha256(snapshot);
    const eligible=Array.isArray(rows)?rows.filter(MediaStore.snapshotEligible).length:0;
    const blocked=Array.isArray(rows)?rows.filter((row)=>!MediaStore.snapshotEligible(row)).map((row)=>({id:MediaStore.text(row&&row.id),reasons:MediaStore.MediaPolicy.releaseEligibility(row).reasons})):[]; 
    const allowEmptySection=params.allowEmptySection===true||params.allowEmptySection==="true";
    if(publishFront&&needsCandidates&&eligible===0&&!(frontAction==="publish_section"&&allowEmptySection&&scopedApprovedRows.length>0)){
      const error=new Error("프론트에 반영할 승인·권리확인·공개검증 완료 후보가 없습니다.");
      error.statusCode=409;error.code="no_verified_promotable_media";throw error;
    }
    const release={
      release_id:"media_snapshot_"+MediaStore.shortHash({hash,at:MediaStore.nowIso()}),
      snapshot_hash:hash,
      snapshot,
      status: storeRelease ? "stored" : "preview",
      policyVersion:MediaStore.MediaPolicy.VERSION,
      counts:{approvedRows:Array.isArray(scopedApprovedRows)?scopedApprovedRows.length:0,eligibleRows:eligible,frontDisabledRows:frontDisabledRows.length,policyBlockedRows:blocked.length,sections:snapshot.meta&&snapshot.meta.filled||{},frontAction,sectionKey:sectionKey||null},
      created_by:MediaStore.compact(actor.email || actor.memberId || "admin",200),
      created_at:MediaStore.nowIso()
    };
    let stored=null;
    if(storeRelease) stored=await MediaStore.insertRelease(release);
    let frontPublication=null;
    if(publishFront){
      frontPublication=await MediaReleaseDispatch.dispatch({
        releaseId:release.release_id,
        snapshotHash:hash,
        actorId:actor.email||actor.memberId,
        explicitAdminAuthorization:true
      });
      if(!frontPublication||frontPublication.ok!==true||frontPublication.queued!==true){
        const error=new Error("프론트 반영 배포가 실제로 시작되지 않았습니다: "+MediaStore.text(frontPublication&&frontPublication.reason||"build_hook_not_queued"));
        error.statusCode=503;
        error.code="media_front_publication_not_queued";
        throw error;
      }
    }
    if(params.download === "1" || params.download === true || params.format === "snapshot"){
      return {statusCode:200,headers:{"content-type":"application/json; charset=utf-8","cache-control":"private, no-store, max-age=0","content-disposition":"attachment; filename=media.snapshot.generated.json"},body:JSON.stringify(snapshot,null,2)+"\n"};
    }
    return MediaStore.response(200,{
      ok:true,version:VERSION,policyVersion:MediaStore.MediaPolicy.VERSION,
      baseFile:base.file,hash,approvedRows:Array.isArray(scopedApprovedRows)?scopedApprovedRows.length:0,
      eligibleRows:eligible,frontDisabledRows:frontDisabledRows.length,policyBlockedRows:blocked.length,
      frontAction,sectionKey:sectionKey||null,frontState:statusPayload(Object.assign({},release,{snapshot})),
      blocked:params.includeBlocked==="1"?blocked:undefined,
      releaseStored:!!stored,stored,
      frontPublicationRequested:publishFront,
      frontPublication,
      release:params.includeSnapshot === "1" ? release : Object.assign({}, release, {snapshot:undefined}),
      snapshot:params.includeSnapshot === "1" ? snapshot : undefined
    });
  }catch(error){
    return MediaStore.response(error.statusCode || 500,{ok:false,version:VERSION,error:error.code||"media_snapshot_publish_failed",message:error.message||String(error)});
  }
};

/* IGDC Global/Region/Country Commerce Control v3.11.1-3000-ledger-cleanup-ai-execution
 * Region -> country -> large-country subdivision controller.
 * Shared administrator session only. AI automation writes only to the private
 * candidate queue. Explicit administrator front matching is routed through the
 * existing go-live audit/build gate; no checkout or payment action exists.
 */
(function(){
  'use strict';
  var REVIEW='/.netlify/functions/commerce-candidate-review';
  var CONTROL='/.netlify/functions/commerce-country-control';
  var QUEUE_CONTROL='/.netlify/functions/commerce-candidate-queue-control';
  var GEO='/api/igdc-country-geo';
  var $=function(id){return document.getElementById(id);};
  var text=function(v){return String(v==null?'':v).trim();};
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(ch){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch];});};
  var stateEl=$('state'),notice=$('notice');
  var acceptedToken='',acceptedSession=null,resolvingSession=null,wired=false;
  var catalog=null,locations=null,geo=null,regions=[],countries=[],settings=[],settingMap={};
  var selectedRegion='',selectedCountry='',selectedSubdivision='NATIONWIDE',regionOnly=true,lastJson=null,lastGlobalJson=null,lastRegionalJson=null,lastCountryJson=null,lastDiagnosticJson=null,lastGlobalControlJson=null,lastProductJson=null,lastProductTransitionAuditJson=null,lastScopeCache=null,lastScopeAuditJson=null,activeScopeAudit='',selectionSource='initial',lastSignalReport=null,lastCountryPreview=null,researchStopRequested=false,researchLoopActive=false,productStopRequested=false,productLoopActive=false,productPausedForQueue=false,productQueueStageActive=false,productPauseAutoQueue=false,productPausePersistPromise=null,productPauseServerConfirmed=false,signalLoopActive=false,returnRestoreActive=false,returnRestoreRow=null,returnRestoreTimer=null,lastPassiveRestoreAt=0,supplierControlScopeKey='',queueControlScopeKey='',queueCandidateRows=[],queueFocusedCandidateIds=[],queuePage=0,supplierActiveRows=[],supplierHoldingRows=[],supplierBlockedRows=[],productRows=[],latestProductRows=[],latestProductPage=0,latestSelectedProducts={},latestQueueActionActive=false,latestRefreshActive=false,productPlacementSelections={},candidateSelectedProducts={},candidateGroupPages={},frontSelectedSections={},frontSelectedProducts={},productRenderEpoch=0,heavyPanelWired=false,productAutomationActive=false,productFrontSyncActive=false,affiliateSettlementProductId="",sessionResumeActive=false,sessionUiResume=null,sessionDataResumeAvailable=false;
  var PRODUCT_PAUSE_AUTO_QUEUE_KEY='igdc_product_pause_auto_queue_v1';
  var MANAGEMENT_PAGE_SIZE=100;
  var LATEST_MANUAL_ACTION_BATCH=10;

  var PRODUCT_SECTIONS=Object.freeze([
    {key:'home|home_1',page:'home',section:'home_1',label:'홈 · home_1'},{key:'home|home_2',page:'home',section:'home_2',label:'홈 · home_2'},{key:'home|home_3',page:'home',section:'home_3',label:'홈 · home_3'},{key:'home|home_4',page:'home',section:'home_4',label:'홈 · home_4'},{key:'home|home_5',page:'home',section:'home_5',label:'홈 · home_5'},{key:'home|home_right_top',page:'home',section:'home_right_top',label:'홈 · 우측 상단 (자동차·웹툰·패션)'},{key:'home|home_right_middle',page:'home',section:'home_right_middle',label:'홈 · 우측 중단 (푸드·리빙·책방)'},{key:'home|home_right_bottom',page:'home',section:'home_right_bottom',label:'홈 · 우측 하단 (지식·건강·기타)'},
    {key:'distribution|distribution-recommend',page:'distribution',section:'distribution-recommend',label:'유통 · 오늘의 추천'},{key:'distribution|distribution-sponsor',page:'distribution',section:'distribution-sponsor',label:'유통 · 스폰서'},{key:'distribution|distribution-trending',page:'distribution',section:'distribution-trending',label:'유통 · 실시간 인기'},{key:'distribution|distribution-new',page:'distribution',section:'distribution-new',label:'유통 · 신규'},{key:'distribution|distribution-special',page:'distribution',section:'distribution-special',label:'유통 · 특별'},{key:'distribution|distribution-others',page:'distribution',section:'distribution-others',label:'유통 · 기타'},{key:'distribution|distribution-right',page:'distribution',section:'distribution-right',label:'유통 · 우측'},
    {key:'network|network-right',page:'network',section:'network-right',label:'네트워크 · 우측'},{key:'social|rightPanel',page:'social',section:'rightPanel',label:'소셜 · 우측'},{key:'tour|tour',page:'tour',section:'tour',label:'투어 · 우측'}
  ]);
  var PRODUCT_SECTION_MAP=PRODUCT_SECTIONS.reduce(function(map,row){map[row.key]=row;return map;},{});
  var REVIEW_RETURN_KEY='igdc.country.control.review.return.v2';
  var REVIEW_SNAPSHOT_KEY='igdc.country.control.review.snapshot.v3';
  var REVIEW_DATA_CACHE_KEY='igdc.country.control.review.data.v1';
  var REVIEW_SNAPSHOT_LEGACY_KEY='igdc.country.control.review.snapshot.v2';
  var TOKEN_KEYS=['osauth.tokens.v2','osauth.tokens.v1','igdc.tokens','igdc_auth_tokens','auth0_tokens','auth0spa','igdc_id_token','id_token','auth0_id_token'];

  function show(message,kind){notice.className='notice '+(kind==='ok'?'ok':kind==='warn'?'warn':kind==='fail'?'fail':'');notice.textContent=message;notice.classList.remove('hidden');}
  function hide(){notice.classList.add('hidden');notice.textContent='';}
  function jwt(v){var t=text(v);return t.split('.').length===3&&t.length>32?t:'';}
  function parseJson(v){try{return JSON.parse(v);}catch(_e){return null;}}
  function pushToken(v,out,seen,depth){if(depth>4||v==null)return;if(typeof v==='string'){var t=jwt(v);if(t&&!seen[t]){seen[t]=1;out.push(t);return;}var p=parseJson(v);if(p)pushToken(p,out,seen,depth+1);return;}if(Array.isArray(v)){v.forEach(function(x){pushToken(x,out,seen,depth+1);});return;}if(typeof v==='object'){['id_token','idToken','access_token','accessToken','token','__raw','raw'].forEach(function(k){pushToken(v[k],out,seen,depth+1);});}}
  function sources(){var out=[],seen=[];function add(w){try{if(!w||seen.indexOf(w)>=0)return;void w.location.href;seen.push(w);out.push(w);}catch(_e){}}add(window);try{add(window.parent);}catch(_e){}try{add(window.top);}catch(_e){}return out;}
  async function tokenCandidates(){var out=[],seen={},tasks=[];sources().forEach(function(w){function add(fn){tasks.push(Promise.resolve().then(fn).then(function(v){pushToken(v,out,seen,0);}).catch(function(){}));}add(function(){return w.IGDCMemberAuth&&w.IGDCMemberAuth.getIdToken?w.IGDCMemberAuth.getIdToken():'';});add(function(){return w.osAuth&&w.osAuth.getIdToken?w.osAuth.getIdToken():'';});add(function(){return w.osAuth&&w.osAuth.getIdTokenClaims?w.osAuth.getIdTokenClaims():'';});[w.localStorage,w.sessionStorage].forEach(function(store){if(!store)return;TOKEN_KEYS.forEach(function(k){try{pushToken(store.getItem(k),out,seen,0);}catch(_e){}});});});await Promise.all(tasks);return out;}
  function conciseRequestError(message,status){var raw=text(message),code=Number(status||0);if(!raw)raw=code?'HTTP '+code:'서버 응답이 중단되었습니다.';if(raw.length>700||/<(?:!doctype|html|head|body|script|style)\b/i.test(raw)||/cloudflare|web server is down|error code 52[01]|gateway time-?out/i.test(raw))return(code?'HTTP '+code+' · ':'')+'서버 또는 상위 게이트웨이 응답이 지연·중단되었습니다. 이미 저장된 원장은 유지됩니다.';return raw;}
  function transientResearchRequestError(error){var status=Number(error&&error.status||0),code=text(error&&error.code).toLowerCase(),message=text(error&&error.message).toLowerCase();return status===0||[408,425,429,500,502,503,504,520,521,522,523,524].indexOf(status)>=0||/timeout|time.?out|gateway|temporar|connection|network|fetch/.test(code+' '+message);}
  function productProgressMark(data){var progress=data&&data.progress||{};return[text(data&&data.status),Number(progress.discovery&&progress.discovery.done||0),Number(progress.inspection&&progress.inspection.done||0),Number(progress.privateQueue&&progress.privateQueue.done||0),Number(data&&data.summary&&data.summary.latestResearchProducts||0)].join('|');}

  async function rawRequest(endpoint,action,method,params,body,token,timeoutMs){
    var u=new URL(endpoint,location.origin);u.searchParams.set('action',action);Object.keys(params||{}).forEach(function(k){if(params[k]!=null&&params[k]!=='')u.searchParams.set(k,params[k]);});
    var init={method:method||'GET',credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json',Authorization:'Bearer '+token}},controller=null,timer=null;
    if(init.method!=='GET'){init.headers['Content-Type']='application/json';init.body=JSON.stringify(Object.assign({action:action},body||{}));}
    if(Number(timeoutMs)>0&&typeof AbortController!=='undefined'){controller=new AbortController();init.signal=controller.signal;timer=setTimeout(function(){try{controller.abort();}catch(_e){}},Number(timeoutMs));}
    try{
      var res=await fetch(u.pathname+u.search,init),data=null;try{data=await res.json();}catch(_e){}
      if(!res.ok||!data||data.ok!==true){var er=new Error(conciseRequestError(data&&data.error||('HTTP '+res.status),res.status));er.status=res.status;er.code=data&&data.code;er.payload=data||null;throw er;}return data;
    }catch(error){
      if(error&&error.name==='AbortError'){var timeoutError=new Error('요청 응답 시간이 초과되었습니다. 이미 저장된 원장은 유지됩니다.');timeoutError.status=504;timeoutError.code='request_timeout';throw timeoutError;}
      if(error&&error.message)error.message=conciseRequestError(error.message,error.status);throw error;
    }finally{if(timer)clearTimeout(timer);}
  }
  async function ensureSession(force){if(!force&&acceptedToken)return acceptedSession;if(resolvingSession)return resolvingSession;resolvingSession=(async function(){stateEl.textContent='관리자 공통 세션을 확인하는 중입니다.';var list=await tokenCandidates();for(var i=0;i<list.length;i++){try{var d=await rawRequest(CONTROL,'session','GET',{},null,list[i]);acceptedToken=list[i];acceptedSession=d;stateEl.textContent='관리자 세션 확인 · '+((d.session&&d.session.roles)||[]).join(', ');return d;}catch(_e){}}acceptedToken='';acceptedSession=null;throw new Error('관리자 페이지의 공통 세션을 확인하지 못했습니다.');})();try{return await resolvingSession;}finally{resolvingSession=null;}}
  async function api(endpoint,action,method,params,body,timeoutMs){await ensureSession(false);try{return await rawRequest(endpoint,action,method||'GET',params||{},body||null,acceptedToken,timeoutMs);}catch(e){if(Number(e.status)===401){acceptedToken='';acceptedSession=null;await ensureSession(true);return rawRequest(endpoint,action,method||'GET',params||{},body||null,acceptedToken,timeoutMs);}throw e;}}

  async function geoData(){
    try{var res=await fetch(GEO,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'}}),data=await res.json();if(res.ok&&data&&data.ok===true)return data;}catch(_e){}
    try{return await api(CONTROL,'geo','GET',{});}catch(_e){return{ok:true,resolved:false,country:null,region:null,worldRegion:null,source:'unresolved'};}
  }
  async function staticRegistry(){
    try{
      var docs=await Promise.all([fetch('/data/country-region-registry.v1.json',{cache:'no-store'}),fetch('/data/country-subdivision-registry.v1.json',{cache:'no-store'})]);
      if(!docs[0].ok||!docs[1].ok)throw new Error('registry_http');
      var countryDoc=await docs[0].json(),subDoc=await docs[1].json(),subMap={};
      (subDoc.countries||[]).forEach(function(row){var code=text(row.countryCode).toUpperCase();if(code)subMap[code]=row.subdivisions||[];});
      return{regions:countryDoc.regions||[],countries:(countryDoc.countries||[]).filter(function(row){return text(row.code).toUpperCase()!=='KP';}).map(function(row){var code=text(row.code).toUpperCase();return Object.assign({},row,{code:code,subdivisions:subMap[code]||[]});})};
    }catch(_e){return{regions:[],countries:[]};}
  }

  function settingId(type,opt){opt=opt||{};if(type==='master')return'igdc_country_automation_master';if(type==='region')return'igdc_country_automation_region_'+text(opt.regionGroup).toLowerCase().replace(/[^a-z0-9_-]/g,'');if(type==='country')return'igdc_country_automation_country_'+text(opt.countryCode).toLowerCase();return'igdc_country_automation_subdivision_'+text(opt.countryCode).toLowerCase()+'_'+text(opt.subdivisionCode).toLowerCase().replace(/[^a-z0-9_-]/g,'');}
  function mapSettings(){settingMap={};settings.forEach(function(s){settingMap[s.id]=s;});}
  function country(code){return countries.filter(function(c){return c.code===code;})[0]||null;}
  function region(id){return regions.filter(function(r){return r.id===id;})[0]||null;}
  function statusCountry(code){return locations&&locations.countries&&locations.countries.filter(function(c){return c.code===code;})[0]||{};}
  function setting(type,opt){return settingMap[settingId(type,opt)]||null;}
  function effective(c,sub){
    var chain=[];if(sub&&sub!=='NATIONWIDE')chain.push(setting('subdivision',{countryCode:c,subdivisionCode:sub}));chain.push(setting('country',{countryCode:c}));var cr=country(c);if(cr)chain.push(setting('region',{regionGroup:cr.regionGroup}));chain.push(catalog&&catalog.master);chain=chain.filter(Boolean);var active=chain.filter(function(x){return x.mode&&x.mode!=='inherit';});var pick=active[0]||catalog&&catalog.master||{mode:'off'};return{mode:pick.mode||'off',sourceId:pick.id||'',intervalDays:(active.filter(function(x){return x.intervalDays;})[0]||catalog&&catalog.master||{}).intervalDays||1,maxCandidates:(active.filter(function(x){return x.maxCandidates;})[0]||catalog&&catalog.master||{}).maxCandidates||20,chain:chain};}
  function modeText(m){return({auto:'AI 자동',manual:'수동 우선',off:'OFF',inherit:'상속'})[m]||m||'상속';}
  function modeClass(m){return m==='auto'?'on':m==='manual'?'manual':m==='inherit'?'inherit':'off';}
  function trustRating10(score){var n=Math.max(0,Math.min(100,Number(score)||0));if(n>=95)return 10;if(n>=90)return 9;if(n>=82)return 8;if(n>=75)return 7;if(n>=65)return 6;if(n>=55)return 5;if(n>=45)return 4;if(n>=35)return 3;if(n>=20)return 2;return 1;}
  function scopeName(){var c=country(selectedCountry);var sub=selectedSubdivision==='NATIONWIDE'?'전국':selectedSubdivision;var row=c&&Array.isArray(c.subdivisions)?c.subdivisions.filter(function(x){return x.code===selectedSubdivision;})[0]:null;if(row)sub=(row.nameKo||row.nameEn)+' · '+row.code;return(c?(c.nameKo||c.nameEn)+' · '+c.code:'국가 미선택')+' / '+sub;}
  function scopeParams(){return{country:selectedCountry,region:selectedSubdivision||'NATIONWIDE'};}
  function scopeKey(scope){scope=scope||scopeParams();return text(scope.country).toUpperCase()+'|'+(text(scope.region).toUpperCase()||'NATIONWIDE');}
  function scopeSnapshot(source){return{country:selectedCountry,region:selectedSubdivision||'NATIONWIDE',regionGroup:selectedRegion,source:source||selectionSource||'manual-selected',detectedGeo:{country:geo&&geo.country||null,region:geo&&geo.region||null,regionGroup:geo&&geo.worldRegion||null,resolved:!!(geo&&geo.resolved),excluded:!!(geo&&geo.excluded),source:geo&&geo.source||'unresolved'}};}
  function setDownloadEnabled(enabled){$('downloadCurrentJsonBtn').disabled=!enabled;}
  function setButtonEnabled(id,enabled){var el=$(id);if(el)el.disabled=!enabled;}
  function presentJson(data){if(!data)return;lastJson=data;$('jsonOutput').textContent=JSON.stringify(data,null,2);$('jsonPanel').classList.remove('hidden');setDownloadEnabled(true);}
  function keepJsonPanelVisible(message){var panel=$('jsonPanel'),output=$('jsonOutput');if(panel)panel.classList.remove('hidden');if(output&&message!==undefined)output.textContent=message||'';}
  function resetJsonPanelForScope(){lastJson=null;lastDiagnosticJson=null;setDownloadEnabled(false);setButtonEnabled('diagnosticDownloadBtn',false);keepJsonPanelVisible('현재 선택 범위의 통합 점검 JSON을 실행하면 이 영역에 요약이 표시되고 전체 원문 다운로드가 활성화됩니다.');}
  function presentLargeReportSummary(data){
    if(!data)return;lastJson=data;
    var queue=data.queue&&data.queue.summary||{},control=data.control&&data.control.summary||{},scope=data.scope||{},preview={
      ok:data.ok===true,reportType:data.reportType||'igdc-diagnostic',generatedAt:data.generatedAt||null,
      scope:{country:scope.country||null,region:scope.region||'NATIONWIDE'},
      summary:{considered:Number(queue.considered||control.considered||0),eligibleForRelease:Number(queue.eligibleForRelease||0),registrySyncReady:Number(queue.registrySyncReady||0),publicationRequested:Number(queue.publicationRequested||0),releasedToCanonical:Number(queue.releasedToCanonical||0)},
      download:'전체 원문은 통합 JSON 다운로드 버튼으로 내려받습니다.'
    };
    $('jsonOutput').textContent=JSON.stringify(preview,null,2);$('jsonPanel').classList.remove('hidden');setDownloadEnabled(true);
  }
  function rememberReport(kind,data){if(!data)return;if(kind==='global'){lastGlobalJson=data;setButtonEnabled('globalSignalDownloadBtn',true);}else if(kind==='regional'){lastRegionalJson=data;setButtonEnabled('regionalSignalDownloadBtn',true);}else if(kind==='country'){lastCountryJson=data;setButtonEnabled('countryRunDownloadBtn',true);}else if(kind==='diagnostic'){lastDiagnosticJson=data;presentLargeReportSummary(data);setButtonEnabled('diagnosticDownloadBtn',true);}else if(kind==='globalControl'){lastGlobalControlJson=data;presentLargeReportSummary(data);setButtonEnabled('globalControlDownloadBtn',true);}else if(kind==='product'){lastProductJson=data;setButtonEnabled('productResearchDownloadBtn',true);}if(kind==='global'||kind==='regional')setButtonEnabled('downloadSignalJsonBtn',true);}
  function downloadRemembered(kind){var data=kind==='global'?lastGlobalJson:kind==='regional'?lastRegionalJson:kind==='country'?lastCountryJson:kind==='diagnostic'?lastDiagnosticJson:kind==='globalControl'?lastGlobalControlJson:kind==='product'?lastProductJson:lastJson;if(!data){show('해당 범위에서 다운로드할 JSON이 없습니다. 먼저 점검 또는 실행을 완료해 주세요.','warn');return;}lastJson=data;setDownloadEnabled(true);download();}

  function invalidateJson(){closeManagementPanels();closeSupplierControlQueue();supplierControlScopeKey='';closeQueuePanel();queueControlScopeKey='';queueCandidateRows=[];queueFocusedCandidateIds=[];queuePage=0;candidateGroupPages={};latestProductPage=0;supplierActiveRows=[];supplierHoldingRows=[];supplierBlockedRows=[];productRows=[];latestProductRows=[];latestSelectedProducts={};latestQueueActionActive=false;latestRefreshActive=false;productPlacementSelections={};frontSelectedSections={};frontSelectedProducts={};researchStopRequested=true;productStopRequested=true;productPausedForQueue=false;productPauseServerConfirmed=false;lastCountryJson=null;lastCountryPreview=null;lastProductJson=null;lastProductTransitionAuditJson=null;lastScopeCache=null;lastScopeAuditJson=null;activeScopeAudit='';if($('productTransitionAuditDownloadBtn'))$('productTransitionAuditDownloadBtn').disabled=true;if($('scopeAuditPanel'))$('scopeAuditPanel').classList.add('hidden');setButtonEnabled('countryRunDownloadBtn',false);setButtonEnabled('runNowBtn',false);setButtonEnabled('productResearchDownloadBtn',false);resetJsonPanelForScope();if($('countryResearchProgress'))$('countryResearchProgress').textContent='선택 범위가 바뀌었습니다. 새 범위의 저장 작업 상태를 읽어 주세요.';if($('productResearchState'))$('productResearchState').textContent='선택 범위가 바뀌었습니다. 이 범위의 상품 리서치 상태를 다시 읽어 주세요.';}
  function savedScope(){
    var query=new URLSearchParams(location.search),stored={},queryCountry=text(query.get('country')).toUpperCase();
    try{stored=JSON.parse(sessionStorage.getItem('igdc_admin_country_scope_v1')||'{}')||{};}catch(_e){}
    return{country:text(queryCountry||stored.country).toUpperCase(),region:text(query.get('region')||stored.region||'NATIONWIDE').toUpperCase(),regionGroup:text(stored.regionGroup),source:queryCountry?'query-scope':(stored.country?'session-saved-scope':'')};
  }
  function validSubdivision(c,code){
    if(!c||!code||code==='NATIONWIDE')return'NATIONWIDE';
    var rows=Array.isArray(c.subdivisions)?c.subdivisions:[];
    return rows.some(function(row){return text(row.code).toUpperCase()===code;})?code:'NATIONWIDE';
  }
  function persistScope(){try{sessionStorage.setItem('igdc_admin_country_scope_v1',JSON.stringify({country:selectedCountry,region:selectedSubdivision||'NATIONWIDE',regionGroup:selectedRegion,updatedAt:new Date().toISOString(),source:'country-control-session'}));}catch(_e){}window.IGDC_ADMIN_COUNTRY_SCOPE={country:selectedCountry,region:selectedSubdivision||'NATIONWIDE',regionGroup:selectedRegion};}
  function scopedUrl(path){var u=new URL(path,location.origin);if(selectedCountry)u.searchParams.set('country',selectedCountry);u.searchParams.set('region',selectedSubdivision||'NATIONWIDE');u.searchParams.set('scopeSource','country-control');u.searchParams.set('returnPath',location.pathname+location.search+location.hash);return u.pathname+u.search;}

  function renderMaster(){var m=catalog.master||{mode:'off',intervalDays:1};$('masterMode').value=m.mode==='inherit'?'off':m.mode;$('masterInterval').value=String(m.intervalDays||1);$('masterState').textContent=m.mode==='auto'?'ON':m.mode==='manual'?'MANUAL':'OFF';$('masterState').className='switchstate '+modeClass(m.mode);}
  function renderOperatingStatus(){
    var st=catalog&&catalog.operatingStatus||{},profile=text(st.profile||'custom');
    var labels={global_auto:'전 세계 자동 운영',global_pause:'전체 자동 중지',custom:'개별 국가·권역 설정 운영'};
    var active=Number(st.autoCountryCount||0),total=Number(st.supportedCountryCount||countries.length||0),perRun=Number(st.scopesPerSchedulerRun||0);
    $('operationStatus').textContent='현재 운영: '+(labels[profile]||profile);
    $('operationStatus').className=profile==='global_auto'?'on':profile==='custom'?'manual':'off';
    $('operationDetail').textContent='자동 국가 '+active+'/'+total+' · 시간당 최대 '+perRun+'개 범위 순환 · 개별 예외 '+Number(st.childOverrides||0)+'개';
  }
  function renderRegions(){
    var html=regions.map(function(r){var s=setting('region',{regionGroup:r.id})||{mode:'inherit'};var count=countries.filter(function(c){return c.regionGroup===r.id;}).length;return'<article class="region-card '+(selectedRegion===r.id?'active':'')+'" data-region="'+esc(r.id)+'"><div class="head"><div><div class="name">'+esc(r.nameKo||r.nameEn||r.id)+'</div><div class="meta">'+esc(count)+'개 국가 · '+esc(r.id)+'</div></div><span class="pill '+(s.mode==='auto'?'good':s.mode==='manual'?'manual':s.mode==='off'?'warn':'info')+'">'+esc(modeText(s.mode))+'</span></div><div class="region-settings"><select aria-label="권역 자동화 모드" data-region-mode="'+esc(r.id)+'"><option value="inherit" '+(s.mode==='inherit'?'selected':'')+'>상위 설정 상속</option><option value="auto" '+(s.mode==='auto'?'selected':'')+'>AI 자동</option><option value="manual" '+(s.mode==='manual'?'selected':'')+'>수동 우선</option><option value="off" '+(s.mode==='off'?'selected':'')+'>OFF</option></select><select aria-label="권역 점검 주기" data-region-interval="'+esc(r.id)+'"><option value="1" '+((s.intervalDays||1)===1?'selected':'')+'>1일</option><option value="2" '+(s.intervalDays===2?'selected':'')+'>2일</option><option value="3" '+(s.intervalDays===3?'selected':'')+'>3일</option><option value="7" '+(s.intervalDays===7?'selected':'')+'>7일</option><option value="14" '+(s.intervalDays===14?'selected':'')+'>14일</option><option value="30" '+(s.intervalDays===30?'selected':'')+'>30일</option></select></div></article>';}).join('');$('regionGrid').innerHTML=html;
    Array.prototype.forEach.call(document.querySelectorAll('.region-card'),function(card){card.addEventListener('click',function(e){if(e.target&&e.target.tagName==='SELECT')return;selectedRegion=card.getAttribute('data-region');regionOnly=true;var firstCountry=countries.filter(function(c){return c.regionGroup===selectedRegion;})[0];if(firstCountry)selectCountry(firstCountry.code,true,'manual-selected');else renderAll();});});
    Array.prototype.forEach.call(document.querySelectorAll('[data-region-mode]'),function(sel){sel.addEventListener('change',async function(){var id=sel.getAttribute('data-region-mode'),interval=document.querySelector('[data-region-interval="'+id+'"]');try{await saveSetting({scopeType:'region',regionGroup:id,mode:sel.value,intervalDays:Number(interval&&interval.value||1),maxCandidates:(setting('region',{regionGroup:id})||{}).maxCandidates||20});show('권역 자동화 설정을 저장했습니다.','ok');}catch(e){show(text(e.message),'fail');}});});Array.prototype.forEach.call(document.querySelectorAll('[data-region-interval]'),function(sel){sel.addEventListener('change',async function(){var id=sel.getAttribute('data-region-interval'),modeEl=document.querySelector('[data-region-mode="'+id+'"]');try{await saveSetting({scopeType:'region',regionGroup:id,mode:modeEl&&modeEl.value||'inherit',intervalDays:Number(sel.value||1),maxCandidates:(setting('region',{regionGroup:id})||{}).maxCandidates||20});show('권역 점검 주기를 저장했습니다.','ok');}catch(e){show(text(e.message),'fail');}});});
  }
  function countryStatusPill(c){var st=statusCountry(c.code),ef=effective(c.code,'NATIONWIDE');if(ef.mode==='auto')return'<span class="pill good">AI 자동</span>';if(ef.mode==='manual')return'<span class="pill manual">수동</span>';if(st.candidateCount)return'<span class="pill info">후보 '+esc(st.candidateCount)+'</span>';return'<span class="pill warn">0건</span>';}
  function renderCountries(){var q=text($('countrySearch').value).toLowerCase();var rows=countries.filter(function(c){return(!regionOnly||!selectedRegion||c.regionGroup===selectedRegion)&&(!q||c.code.toLowerCase().indexOf(q)>=0||text(c.nameKo).toLowerCase().indexOf(q)>=0||text(c.nameEn).toLowerCase().indexOf(q)>=0);});$('countryGrid').innerHTML=rows.length?rows.map(function(c){var st=statusCountry(c.code);return'<button type="button" class="country-card '+(c.code===selectedCountry?'active':'')+'" data-country="'+esc(c.code)+'"><strong><span>'+esc(c.nameKo||c.nameEn)+' · '+esc(c.code)+'</span>'+countryStatusPill(c)+'</strong><div class="meta">후보 '+esc(st.candidateCount||0)+' · 승인 전 통과 '+esc(st.releaseEligible||0)+' · 수동 고정 '+esc(st.manualPinnedCount||0)+'<br>'+(c.requiresSubdivision?'주·성·지역 '+esc((c.subdivisions||[]).length)+'개':'국가 단위 관리')+'</div></button>';}).join(''):'<div class="small">조건에 맞는 국가가 없습니다.</div>';Array.prototype.forEach.call(document.querySelectorAll('.country-card'),function(card){card.addEventListener('click',function(){selectCountry(card.getAttribute('data-country'),true,'manual-selected');});});}
  function renderSubdivisions(){var c=country(selectedCountry);if(!c||!c.requiresSubdivision){$('subdivisionPanel').classList.add('hidden');selectedSubdivision='NATIONWIDE';return;}$('subdivisionPanel').classList.remove('hidden');$('subdivisionTitle').textContent='3단계 · '+(c.nameKo||c.nameEn)+' 주·성·지역 선택';var rows=[{code:'NATIONWIDE',nameKo:'전국 범위'}].concat(c.subdivisions||[]);$('subdivisionGrid').innerHTML=rows.map(function(s){var ef=effective(c.code,s.code==='NATIONWIDE'?'':s.code);return'<button type="button" class="subdivision-card '+(selectedSubdivision===s.code?'active':'')+'" data-subdivision="'+esc(s.code)+'"><strong>'+esc(s.nameKo||s.nameEn||s.code)+'</strong><div class="meta">'+esc(s.code)+' · '+esc(modeText(ef.mode))+'</div></button>';}).join('');Array.prototype.forEach.call(document.querySelectorAll('.subdivision-card'),function(card){card.addEventListener('click',function(){var next=card.getAttribute('data-subdivision');if(next!==selectedSubdivision)invalidateJson();selectedSubdivision=next;selectionSource='manual-selected';persistScope();renderSubdivisions();renderScope();loadScope();});});}
  function renderScope(){
    var c=country(selectedCountry),ef=effective(selectedCountry,selectedSubdivision==='NATIONWIDE'?'':selectedSubdivision),specific=selectedSubdivision!=='NATIONWIDE'?setting('subdivision',{countryCode:selectedCountry,subdivisionCode:selectedSubdivision}):setting('country',{countryCode:selectedCountry}),masterMode=catalog&&catalog.master&&catalog.master.mode||'off',scheduleNote=(ef.mode==='auto'&&masterMode!=='auto')?' · 전 세계 예약 중지 상태이므로 정기 자동 실행은 멈춰 있고 수동 검색·실행만 가능합니다.':'';
    $('scopeTitle').textContent=scopeName();
    $('scopeMeta').innerHTML='실효 모드 <strong class="'+modeClass(ef.mode)+'">'+esc(modeText(ef.mode))+'</strong> · 기준 '+esc(ef.sourceId||'기본값')+' · 주기 '+esc(ef.intervalDays)+'일 · 1회 최대 '+esc(ef.maxCandidates)+'개'+esc(scheduleNote);
    $('scopeMode').value=specific&&specific.mode||'inherit';$('scopeInterval').value=String(specific&&specific.intervalDays||ef.intervalDays||1);$('maxCandidates').value=String(specific&&specific.maxCandidates||ef.maxCandidates||20);$('expandField').classList.toggle('hidden',!(c&&c.requiresSubdivision&&selectedSubdivision==='NATIONWIDE'));$('expandSubdivisions').value=String(!!(specific&&specific.expandSubdivisions));
    $('scopeLinks').innerHTML=[['queue','상품 후보·중개수익 대기열','비공개 후보 심사·수익·PSOM 승인'],['go_live','실상품 공급업체·상품 개방 점검','공개 직전 최종 감사·게재 요청']].map(function(x){return'<button type="button" class="linkbtn '+(activeScopeAudit===x[0]?'active':'')+'" data-scope-audit="'+esc(x[0])+'"><strong>'+esc(x[1])+'</strong><small>'+esc(x[2])+' · '+esc(scopeName())+'</small></button>';}).join('');
    Array.prototype.forEach.call(document.querySelectorAll('[data-scope-audit]'),function(b){b.addEventListener('click',function(){openScopeAudit(b.getAttribute('data-scope-audit'),false);});});
    if($('supplierManualScopeLabel'))$('supplierManualScopeLabel').textContent='현재 선택 범위: '+scopeName();
  }
  function renderAll(){renderMaster();renderOperatingStatus();renderRegions();renderCountries();renderSubdivisions();renderScope();var r=region(selectedRegion);$('selectedRegionSignalName').textContent=r?((r.nameKo||r.nameEn||r.id)+' · '+r.id+' 권역의 수요·물류·규제·문화·행사 흐름을 점검합니다.'):'권역을 선택하면 해당 권역의 특별 이슈와 수요 변화를 점검합니다.';persistScope();}
  function selectCountry(code,load,source){var next=text(code).toUpperCase();if(next!==selectedCountry||selectedSubdivision!=='NATIONWIDE')invalidateJson();selectedCountry=next;selectionSource=source||'manual-selected';var c=country(selectedCountry);if(c)selectedRegion=c.regionGroup;selectedSubdivision='NATIONWIDE';persistScope();renderAll();if(load)loadScope();}

  async function saveSetting(input){var d=await api(CONTROL,'setting_save','POST',{}, {setting:input});settings=settings.filter(function(x){return x.id!==d.setting.id;});settings.push(d.setting);mapSettings();catalog.settings=settings;if(d.setting.scopeType==='master')catalog.master=d.setting;renderAll();return d.setting;}
  function stat(title,value,small){return'<article class="stat"><h3>'+esc(title)+'</h3><div class="num">'+esc(value)+'</div><div class="small">'+esc(small||'')+'</div></article>';}
  function auditScopeOf(data){var scope=data&&data.scope||data&&data.selectedScope||{};return{country:text(scope.country||selectedCountry).toUpperCase(),region:text(scope.region||selectedSubdivision||'NATIONWIDE').toUpperCase()||'NATIONWIDE',regionGroup:text(scope.regionGroup||selectedRegion)};}
  function auditList(values){var rows=Array.isArray(values)?values.filter(Boolean):[];return rows.length?'<ul>'+rows.map(function(v){return'<li>'+esc(v)+'</li>';}).join('')+'</ul>':'<div class="small">기록된 항목이 없습니다.</div>';}
  function setScopeAuditLoading(kind){activeScopeAudit=kind;$('scopeAuditPanel').classList.remove('hidden');$('scopeAuditTitle').textContent=kind==='go_live'?'실상품 공급업체·상품 개방 점검':'상품 후보·중개수익 대기열';$('scopeAuditScope').textContent=scopeName();if($('scopeAuditOpenBtn'))$('scopeAuditOpenBtn').textContent=kind==='go_live'?'전체 개방 점검 화면 열기':'전체 대기열 관리 화면 열기';$('scopeAuditStatus').textContent='현재 선택 범위의 저장 원장을 읽는 중입니다. 별도 페이지로 이동하거나 검색 작업을 다시 시작하지 않습니다.';$('scopeAuditGrid').innerHTML='';$('scopeAuditDetail').classList.add('hidden');$('scopeAuditRows').classList.add('hidden');setButtonEnabled('scopeAuditDownloadBtn',false);renderScope();}
  function renderScopeAudit(data,kind){
    kind=kind||activeScopeAudit||'queue';lastScopeAuditJson=data;activeScopeAudit=kind;var panel=$('scopeAuditPanel'),scope=auditScopeOf(data);panel.classList.remove('hidden');$('scopeAuditTitle').textContent=kind==='go_live'?'실상품 공급업체·상품 개방 점검':'상품 후보·중개수익 대기열';if($('scopeAuditOpenBtn'))$('scopeAuditOpenBtn').textContent=kind==='go_live'?'전체 개방 점검 화면 열기':'전체 대기열 관리 화면 열기';$('scopeAuditScope').textContent=(scope.country||selectedCountry)+' / '+(scope.region||'NATIONWIDE')+' · 현재 관제 화면 내부 점검';
    var grid='',detail='',rows='';
    if(kind==='queue'){
      var q=data.queue||{},sum=data.summary||{},up=data.upstream||{},gate=data.releaseGate||{},blockers=data.blockingConditions||[];
      grid=stat('비공개 후보',q.totalCandidates||sum.considered||0,'관리자 검토 원장')+stat('개방 점검 후보',q.goLiveAuditCandidates||sum.goLiveAuditCandidates||0,'시장·증빙·수익·PSOM 완료')+stat('게재 요청 상태',q.publicationRequested||sum.publicationRequested||0,'개방 점검 최종 요청')+stat('검토 보류',q.held||sum.held||0,'증빙·계약·승인 누락')+stat('상품 리서치 입력',up.liveProductResearchQueue||0,'비공개 후보 원천')+stat('릴리스 게이트',gate.enabled===true?'ON':'OFF',gate.mode||'staging_only');
      detail='<strong>현재 상태</strong><br>'+(gate.enabled===true?'릴리스 키가 확인됐지만 후보별 검증은 계속 필요합니다.':'비공개 검토 단계입니다. 프런트 슬롯으로 자동 공개하지 않습니다.')+'<br><strong>차단 조건</strong>'+auditList(blockers);
      var list=Array.isArray(q.rows)?q.rows:[];rows=list.length?'<table><thead><tr><th>후보</th><th>상태</th><th>배치</th><th>수익</th><th>차단 사유</th></tr></thead><tbody>'+list.slice(0,100).map(function(r){return'<tr><td><strong>'+esc(r.title||r.id||r.candidateId||'-')+'</strong><br><span class="small mono">'+esc(r.destinationHost||r.sellerHost||'')+'</span></td><td>'+esc(r.status||r.reviewState||'-')+'</td><td>'+esc(r.page||r.section||(r.placement||{}).page||'-')+'</td><td>'+esc(r.revenueType||(r.revenue||{}).type||'-')+'</td><td>'+esc((r.reasons||r.issues||[]).join(', ')||'-')+'</td></tr>';}).join('')+'</tbody></table>':'<div class="scope-audit-empty">현재 범위의 비공개 상품 후보가 없습니다. 공급업체·상품 리서치 결과가 이 원장으로 승인 전달되기 전에는 0건이 정상입니다.</div>';
      $('scopeAuditStatus').textContent='상품 후보·중개수익 대기열을 읽었습니다. 이 점검은 읽기 전용이며 공개·결제·외부 판매처 이동을 실행하지 않습니다.';
    }else{
      var gate2=data.gate||{},summary=data.summary||{},runtime=data.runtime||{},switches=runtime.supplySwitches||{},release=data.releaseControl||{},privateStage=data.pipeline&&data.pipeline.privateCandidateStage||{},blocking=[];if(gate2.reason)blocking.push(gate2.reason);if(data.status&&data.status!=='ok')blocking.push('status: '+data.status);
      grid=stat('공개 준비 상태',gate2.state||'unknown',gate2.reason||'')+stat('개방 점검 후보',privateStage.goLiveAuditCandidates||summary.goLiveAuditCandidates||0,'대기열 승인 완료')+stat('최종 게재 요청 전',privateStage.auditReady||summary.auditReady||0,'별도 확인 필요')+stat('게재 빌드 요청됨',privateStage.publicationRequested||summary.publicationRequested||0,'선택 상품 요청 상태')+stat('공개 스냅샷 실상품',summary.realProductCandidates||0,'현재 사이트 감지')+stat('게재 제어',release.actionAvailable===true?'준비':'보류',(release.armed?'게이트 ON':'게이트 OFF')+' · '+(release.hookConfigured?'훅 설정':'훅 미설정'));
      detail='<strong>현재 단계</strong><br>이 통합 점검은 상태 확인용입니다. 실제 사이트 게재 요청은 전체 실상품 공급업체·상품 개방 점검 화면에서 상품 한 건을 선택하고 별도 확인 문구를 입력해야 실행됩니다.<br><strong>공급 스위치</strong><br><span class="mono">PRODUCT_SUPPLY_ON='+esc(switches.productSupplyOn||'not-configured')+' · DATA_UPLOAD_ON='+esc(switches.dataUploadOn||'not-configured')+' · FRONT_SLOT_AUTO_FILL='+esc(switches.frontSlotAutoFill||'not-configured')+' · PAYMENT_LIVE='+esc(switches.paymentLive||'not-configured')+'</span><br><strong>현재 게이트</strong>'+auditList(blocking);
      var privateRows=Array.isArray(privateStage.rows)?privateStage.rows:[];rows=privateRows.length?'<table><thead><tr><th>상품</th><th>현재 단계</th><th>PSOM</th><th>판매시장</th><th>게재 상태</th><th>확인 사항</th></tr></thead><tbody>'+privateRows.slice(0,100).map(function(r){var a=r.assignment||{};return'<tr><td><strong>'+esc(r.title||r.candidateId||'-')+'</strong><br><span class="small mono">'+esc(r.candidateId||'-')+'</span></td><td>'+esc(r.stageStatus||'-')+'</td><td>'+esc((a.hubKey||'-')+' / '+(a.slotKey||'-'))+'</td><td>'+esc((r.marketKeys||[]).join(', ')||((a.countryCode||'-')+' / '+(a.regionCode||'-')))+'</td><td>'+esc(a.publicationStatus||'-')+'</td><td>'+esc((r.reasons||[]).join(', ')||'최종 점검 가능')+'</td></tr>';}).join('')+'</tbody></table>':'<div class="scope-audit-empty">현재 범위에 개방 점검 후보가 없습니다. 상품 후보 대기열에서 시장·증빙·수익·PSOM 승인을 먼저 완료해야 합니다.</div>';
      $('scopeAuditStatus').textContent='실상품 공급 개방 상태를 읽었습니다. 이 통합 화면은 상태 확인용이며, 최종 사이트 게재는 전체 개방 점검 화면의 별도 위험 표시 버튼에서만 요청합니다.';
    }
    $('scopeAuditGrid').innerHTML=grid;$('scopeAuditDetail').innerHTML=detail;$('scopeAuditDetail').classList.remove('hidden');$('scopeAuditRows').innerHTML=rows;$('scopeAuditRows').classList.remove('hidden');setButtonEnabled('scopeAuditDownloadBtn',true);renderScope();saveReviewSnapshot();
  }
  async function fetchGoLiveAudit(){await ensureSession(false);var u=new URL('/.netlify/functions/product-go-live-audit',location.origin);u.searchParams.set('mode','pre-product');u.searchParams.set('limit','120');u.searchParams.set('country',selectedCountry);u.searchParams.set('region',selectedSubdivision||'NATIONWIDE');u.searchParams.set('ts',String(Date.now()));var headers={Accept:'application/json'};if(acceptedToken)headers.Authorization='Bearer '+acceptedToken;var res=await fetch(u.pathname+u.search,{credentials:'same-origin',cache:'no-store',headers:headers}),data=null;try{data=await res.json();}catch(_e){}if(!res.ok||!data||data.ok!==true){var error=new Error(data&&data.error||('HTTP '+res.status));error.status=res.status;error.payload=data||null;throw error;}data.scope=data.selectedScope||scopeSnapshot('inline-go-live-audit');return data;}
  async function openScopeAudit(kind,refresh){if(!selectedCountry)return;kind=kind==='go_live'?'go_live':'queue';var cached=lastScopeAuditJson&&activeScopeAudit===kind&&scopeKey(auditScopeOf(lastScopeAuditJson))===scopeKey();if(cached&&!refresh){renderScopeAudit(lastScopeAuditJson,kind);$('scopeAuditPanel').scrollIntoView({behavior:'smooth',block:'start'});return;}setScopeAuditLoading(kind);try{var data=kind==='queue'?await api(REVIEW,'diagnostic','GET',scopeParams()):await fetchGoLiveAudit();data.scope=auditScopeOf(data);renderScopeAudit(data,kind);$('scopeAuditPanel').scrollIntoView({behavior:'smooth',block:'start'});}catch(e){lastScopeAuditJson=e&&e.payload||{ok:false,reportType:'igdc-inline-scope-audit-error',generatedAt:new Date().toISOString(),scope:scopeSnapshot('inline-audit-error'),auditKind:kind,error:text(e&&e.message)};$('scopeAuditStatus').textContent='점검 실패: '+(text(e&&e.message)||'알 수 없는 오류')+'. 기존 국가·상품 리서치 상태는 유지됩니다.';$('scopeAuditDetail').innerHTML='<strong>오류 JSON은 다운로드할 수 있습니다.</strong>';$('scopeAuditDetail').classList.remove('hidden');setButtonEnabled('scopeAuditDownloadBtn',true);show(text(e&&e.message)||'선택 범위 점검에 실패했습니다.','fail');}}
  function openFullScopeAudit(){
    if(!selectedCountry)return;
    var path=activeScopeAudit==='go_live'?'/product-go-live-audit.html':'/commerce-candidate-pipeline.html';
    var u=new URL(path,location.origin);u.searchParams.set('country',selectedCountry);u.searchParams.set('region',selectedSubdivision||'NATIONWIDE');u.searchParams.set('source','commerce-country-control');u.searchParams.set('returnPath',location.pathname+location.search);location.href=u.pathname+u.search;
  }
  function closeScopeAudit(){activeScopeAudit='';lastScopeAuditJson=null;$('scopeAuditPanel').classList.add('hidden');renderScope();saveReviewSnapshot();}
  function downloadScopeAudit(){if(!lastScopeAuditJson){show('다운로드할 선택 범위 점검 JSON이 없습니다.','warn');return;}var prefix=activeScopeAudit==='go_live'?'IGDC_PRODUCT_GO_LIVE_AUDIT':'IGDC_COMMERCE_CANDIDATE_QUEUE',stamp=new Date().toISOString().replace(/[:.]/g,'-'),blob=new Blob([JSON.stringify(lastScopeAuditJson,null,2)+'\n'],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=prefix+'_'+selectedCountry+'_'+(selectedSubdivision||'NATIONWIDE')+'_'+stamp+'.json';a.style.display='none';document.body.appendChild(a);a.click();setTimeout(function(){try{a.remove();URL.revokeObjectURL(url);}catch(_e){}},1200);show('선택 범위 점검 JSON 다운로드를 시작했습니다.','ok');}
  function renderSummary(sum,scopeData,sourceLabel){
    var s=(sum&&sum.summary)?sum.summary:(sum||{}),ai=(scopeData&&scopeData.candidates)||[];
    $('summaryTitle').textContent=scopeName()+' 현황';if($('summarySource'))$('summarySource').textContent=sourceLabel||'저장 원장 기준';
    $('summaryGrid').innerHTML=stat('검색 수집',s.collected||0,'원천 검색·스냅샷')+stat('리서치 후보',s.researchCandidates!=null?s.researchCandidates:(s.considered||0),'추가 증빙 누적 대상')+stat('증빙 검토 가능',s.evidenceReady!=null?s.evidenceReady:(s.eligibleForRelease||0),'신뢰평가 진입 가능')+stat('신뢰 순위 계산',s.ranked||0,'현재 실행 결과')+stat('검토 보류',s.held||0,'증빙 보완 대상')+stat('비공개 저장 후보',ai.length,'선택 범위 원장');
    $('summaryPanel').classList.remove('hidden');
  }

  function sectionKeyOf(placement){placement=placement||{};var page=text(placement.page||placement.channel),section=text(placement.sectionKey||placement.section||placement.psom_key);return page&&section?page+'|'+section:'';}
  function sectionLabel(key){var row=PRODUCT_SECTION_MAP[key];return row?row.label:(key?key.replace('|',' · '):'미배정');}
  function productDecision(row){return text(row&&row.slotDecision||'undecided').toLowerCase();}
  function productPlacementKey(row){return sectionKeyOf(row&&row.approvedPlacement)||sectionKeyOf(row&&row.selectedPlacement)||sectionKeyOf(row&&row.primaryPlacement)||sectionKeyOf(row&&row.placement)||sectionKeyOf((row&&row.sectionAssignments||[])[0]);}
  function candidatePlacementKey(row){var list=(row&&row.sectionAssignments||[]).filter(function(item){return item&&(item.approvalEligible===true||item.reviewEligible===true);});return sectionKeyOf(row&&row.primaryPlacement)||sectionKeyOf(list[0])||'unassigned';}
  function eligiblePlacements(row){return (Array.isArray(row&&row.sectionAssignments)?row.sectionAssignments:[]).filter(function(item){return item&&item.approvalEligible===true&&PRODUCT_SECTION_MAP[sectionKeyOf(item)];});}
  function productById(id){id=text(id);return productRows.filter(function(row){return text(row&&row.id)===id;})[0]||null;}
  function productSectionCounts(){var counts={};PRODUCT_SECTIONS.forEach(function(row){counts[row.key]=0;});productRows.filter(function(row){return productDecision(row)==='slot_candidate';}).forEach(function(row){var key=productPlacementKey(row);if(Object.prototype.hasOwnProperty.call(counts,key))counts[key]+=1;});return counts;}
  function tourDiningAuxiliaryRow(row){var hay=[row&&row.productName,row&&row.title,row&&row.priorityLabel,row&&row.description,row&&row.summary,row&&row.productUrl,row&&row.url].map(text).join(' ').toLowerCase(),misleading=/(여행용\s*(?:티슈|물티슈|휴지|세면|파우치)|포켓물티슈|캠핑용?\s*(?:물티슈|휴지)|체험팩|travel\s*(?:size|tissue|wipe))/i.test(hay),packaged=/(밀키트|냉동|즉석|가공식품|포장제품|배송상품|세트상품|meal\s*kit|frozen|packaged|grocery)/i.test(hay);return!misleading&&!packaged&&/(맛집|레스토랑|식당|음식점|다이닝|카페|뷔페|브런치|비스트로|그릴|스테이크하우스|펍|restaurant|dining|cafe|café|buffet|brunch|bistro|grill|steakhouse|pub)/i.test(hay);}
  function tourDiningPlacementCount(){return productRows.filter(function(row){return productDecision(row)==='slot_candidate'&&productPlacementKey(row)==='tour|tour'&&tourDiningAuxiliaryRow(row);}).length;}
  function productManagementLocked(row){var control=row&&row.managementControl||{},placement=row&&row.approvedPlacement||{},source=text(control.source||row&&row.decisionSource).toLowerCase();return control.administratorLocked===true||control.aiReclassificationAllowed===false||source==='administrator'||(placement.administratorSelected===true&&placement.aiSelected!==true);}
  function affiliateStage(row){var settlement=row&&row.affiliateSettlement||{},stage=text(settlement.stage||row&&row.affiliateStage).toLowerCase();return['connection_required','referral_verified','online_affiliate_active','formal_partner'].indexOf(stage)>=0?stage:'connection_required';}
  function affiliateStageLabel(stage){return{connection_required:'제휴 연결 필요',referral_verified:'리퍼럴 수익 확인',online_affiliate_active:'온라인 제휴 활성',formal_partner:'정식 파트너'}[stage]||'제휴 연결 필요';}
  function affiliateStageClass(stage){return stage==='formal_partner'?'partner':stage==='online_affiliate_active'?'online':stage==='referral_verified'?'referral':'connection';}
  function affiliateSettlementSummary(row){var settlement=row&&row.affiliateSettlement||{},stage=affiliateStage(row),parts=[];if(settlement.counterparty||settlement.providerName)parts.push(text(settlement.counterparty||settlement.providerName));if(settlement.settlementMode)parts.push(text(settlement.settlementMode));if(settlement.commissionRate!=null)parts.push('수수료 '+Math.round(Number(settlement.commissionRate)*10000)/100+'%');if(settlement.payoutPerTransaction!=null)parts.push('건당 '+text(settlement.payoutPerTransaction)+(settlement.currency?' '+text(settlement.currency):''));var ready=settlement.settlementReady===true?'정산 준비 확인':stage==='connection_required'?'연결 대기':'증빙 보완 필요';return'<div class="affiliate-settlement-summary"><span class="pill affiliate-stage-pill '+affiliateStageClass(stage)+'">'+esc(affiliateStageLabel(stage))+'</span> · '+esc(ready)+(parts.length?'<br>'+esc(parts.join(' · ')):'')+'</div>'; }
  function frontPublicationPending(row){var front=row&&row.frontPublication||{},status=text(front.status).toLowerCase();return front.publicSnapshotConfirmed!==true&&['queued','publish_requested'].indexOf(status)>=0;}
  function frontPublicationLive(row){var front=row&&row.frontPublication||{},status=text(front.status).toLowerCase();return front.publicSnapshotConfirmed===true||['matched','published','active'].indexOf(status)>=0;}
  function frontPublicationActive(row){var status=text(row&&row.frontPublication&&row.frontPublication.status).toLowerCase();return frontPublicationLive(row)||frontPublicationPending(row)||status==='unpublish_failed';}
  function frontPublicationSummary(row){var front=row&&row.frontPublication||{},status=text(front.status).toLowerCase();if(!status)return'<div class="product-front-status">프론트 미매칭 · 최종 적용 전</div>';var labels={queued:'게재 대기열 등록',publish_requested:'게재 요청됨',matched:'프론트 매칭 확인',published:'프론트 게시 확인',unpublish_requested:'매칭 해제 요청',unmatched:'매칭 해제됨',blocked:'게재 차단',unpublish_failed:'해제 재확인 필요'};return'<div class="product-front-status '+(frontPublicationActive(row)?'active':'')+'">프론트 상태: '+esc(labels[status]||status)+(front.reason?' · '+esc(front.reason):'')+'</div>';}
  function productManagementOptions(row,mode,groupKey,slotAllowed){var counts=productSectionCounts(),current=mode==='section'?groupKey:'',recommended=sectionKeyOf(row&&row.primaryPlacement)||candidatePlacementKey(row),selected=productPlacementSelections[row.id]||((current||recommended)&&slotAllowed?'section:'+(current||recommended):'');if(selected.indexOf('section:')===0){var selectedKey=selected.slice(8),selectedFull=Number(counts[selectedKey]||0)>=100&&current!==selectedKey;if(!slotAllowed||selectedFull){selected='';delete productPlacementSelections[row.id];}}if(selected)productPlacementSelections[row.id]=selected;var pages={home:'홈',distribution:'유통',network:'네트워크',social:'소셜',tour:'투어'},groups=[];Object.keys(pages).forEach(function(page){var options=PRODUCT_SECTIONS.filter(function(section){return section.page===page;}).map(function(section){var full=Number(counts[section.key]||0)>=100&&current!==section.key,disabled=!slotAllowed||full,label=section.label+(full?' · 정원 100개':'');return'<option value="section:'+esc(section.key)+'" '+(selected==='section:'+section.key?'selected ':'')+(disabled?'disabled ':'')+'>'+esc(label)+'</option>';}).join('');groups.push('<optgroup label="'+esc(pages[page])+'">'+options+'</optgroup>');});var locked=productManagementLocked(row),stage=affiliateStage(row);return'<div class="product-placement-box"><div class="product-placement-title">관리 작업 선택</div><div class="product-management-row"><select class="product-management-select" data-product-management-select="'+esc(row.id)+'"><option value="">작업을 선택하세요</option>'+groups.join('')+'<optgroup label="상태 관리"><option value="hold" '+(selected==='hold'?'selected ':'')+'>보류 목록으로 이동</option><option value="reject" '+(selected==='reject'?'selected ':'')+'>제외 목록으로 이동</option><option value="purge" '+(selected==='purge'?'selected ':'')+'>영구 제외·목록 삭제</option><option value="undecided" '+(selected==='undecided'?'selected ':'')+'>미배정 후보로 되돌리기</option><option value="ai_reclassify" '+(selected==='ai_reclassify'?'selected ':'')+'>관리자 고정 해제·AI 재분류 허용</option></optgroup><optgroup label="제휴·수익 정산"><option value="affiliate:connection_required">제휴 연결 필요로 설정</option><option value="affiliate:referral_verified">리퍼럴 수익 확인</option><option value="affiliate:online_affiliate_active">온라인 제휴 활성</option><option value="affiliate:formal_partner">정식 파트너</option></optgroup></select><button type="button" class="product-management-apply" data-product-management-apply="'+esc(row.id)+'" '+(selected?'':'disabled')+'>적용</button></div><div class="product-ai-recommendation">AI 추천: '+esc(recommended&&recommended!=='unassigned'?sectionLabel(recommended):'추가 검증 필요')+' · '+(locked?'관리자 결정 고정':'AI 재분류 가능')+' · 현재 '+esc(affiliateStageLabel(stage))+'</div></div>';}
  function automationResultText(result){result=result||{};var parts=['자동 배치 '+Number(result.assigned||0)+'건','검토정보 부족 경고 배치 '+Number(result.pendingEvidenceAssigned||0)+'건','미배정 유지 '+Number(result.unassigned||0)+'건','검증 보류 '+Number(result.held||0)+'건','관리자 결정 보존 '+Number(result.manualPreserved||0)+'건'];if(Number(result.enrichmentAttempted||0)>0)parts.push('상품정보 보강 '+Number(result.enrichmentCompleted||0)+'/'+Number(result.enrichmentAttempted||0)+'건');if(Number(result.enrichmentRemaining||0)>0)parts.push('추가 보강 대기 '+Number(result.enrichmentRemaining||0)+'건');parts.push('정산 준비 '+Number(result.settlementReady||0)+'건');if(result.sectionKey)parts.unshift(sectionLabel(result.sectionKey));return parts.join(' · ');}
  function queueCandidateUrl(c){var card=c&&c.productCard||{},supplier=c&&c.supplier||{},payload=c&&c.source_payload||{};return safeExternalUrl(card.checkoutUrl||c&&c.checkoutUrl||c&&c.externalProductUrl||c&&c.productUrl||c&&c.url||c&&c.officialUrl||payload.externalProductUrl||payload.url||card.supplierUrl||supplier.officialUrl||c&&c.supplierUrl);}
  function queueSupplierUrl(c){var card=c&&c.productCard||{},supplier=c&&c.supplier||{},payload=c&&c.source_payload||{};return safeExternalUrl(card.supplierUrl||supplier.officialUrl||payload.supplier&&payload.supplier.officialUrl||c&&c.supplierUrl);}
  function syncDetailsToggle(details,label){if(label)label.textContent=details&&details.open?'목록 닫기':'목록 펼치기';}
  function clearHeavyPanel(panel){if(!panel)return;productRenderEpoch+=1;if(panel.id==='aiPanel'&&$('aiRows'))$('aiRows').innerHTML='';if(panel.id==='queuePanel'&&$('queueRows'))$('queueRows').innerHTML='';if(panel.id==='latestProductPanel'&&$('latestProductGrid'))$('latestProductGrid').innerHTML='';if(panel.id==='productCandidatePanel'&&$('productGrid'))$('productGrid').innerHTML='';if(panel.id==='excludedLedgerPanel'){if($('supplierHoldRows'))$('supplierHoldRows').innerHTML='';if($('supplierBlockedRows'))$('supplierBlockedRows').innerHTML='';if($('productHoldRows'))$('productHoldRows').innerHTML='';if($('productRejectRows'))$('productRejectRows').innerHTML='';}}
  function closeOtherHeavyPanels(current,keepGroup){Array.prototype.forEach.call(document.querySelectorAll('[data-heavy-panel]'),function(panel){if(panel!==current&&panel.open){panel.open=false;clearHeavyPanel(panel);}});Array.prototype.forEach.call(document.querySelectorAll('details[data-product-group][open]'),function(group){if(group!==keepGroup&&!(current&&current.contains(group))){group.open=false;var grid=group.querySelector('.product-group-grid');if(grid)grid.innerHTML='';}});}
  function wireHeavyPanels(){if(heavyPanelWired)return;heavyPanelWired=true;Array.prototype.forEach.call(document.querySelectorAll('[data-heavy-panel]'),function(panel){panel.addEventListener('toggle',function(){if(panel.open){closeOtherHeavyPanels(panel);if(panel.id==='aiPanel')renderSupplierActiveRows();else if(panel.id==='queuePanel')renderQueueRows();else if(panel.id==='latestProductPanel'){renderLatestProductRows();var total=Number(lastProductJson&&lastProductJson.summary&&lastProductJson.summary.latestResearchProducts||0);if(selectedCountry&&!latestRefreshActive&&(productLoopActive||latestProductRows.length<total||!latestProductRows.length)){latestRefreshActive=true;refreshLatestResearchRows(selectedCountry,selectedSubdivision||'NATIONWIDE',{state:$('productResearchState'),label:'최신 상품 리서치 목록',preserveOnFailure:true}).catch(function(error){show('최신 상품 목록 새로고침 지연: '+conciseRequestError(error&&error.message,error&&error.status),'warn');}).finally(function(){latestRefreshActive=false;});}}else if(panel.id==='productCandidatePanel')renderProductCandidateGroups();else if(panel.id==='excludedLedgerPanel')renderExcludedLedger();}else clearHeavyPanel(panel);syncManagementToggleLabels();});});}
  function syncManagementToggleLabels(){syncDetailsToggle($('aiPanel'),$('aiToggleLabel'));syncDetailsToggle($('queuePanel'),$('queueToggleLabel'));syncDetailsToggle($('latestProductPanel'),$('latestProductToggleLabel'));syncDetailsToggle($('productCandidatePanel'),$('productCandidateToggleLabel'));syncDetailsToggle($('excludedLedgerPanel'),$('excludedLedgerToggleLabel'));syncSupplierControlToggleLabel();Array.prototype.forEach.call(document.querySelectorAll('[data-detail-toggle-label]'),function(label){syncDetailsToggle(label.closest('details'),label);});}
  function closeManagementPanels(){Array.prototype.forEach.call(document.querySelectorAll('[data-heavy-panel]'),function(panel){panel.open=false;clearHeavyPanel(panel);});Array.prototype.forEach.call(document.querySelectorAll('#productSectionList details[open]'),function(panel){panel.open=false;var grid=panel.querySelector('.product-group-grid');if(grid)grid.innerHTML='';});syncManagementToggleLabels();}
  function renderInBatches(container,rows,renderer,limit){if(!container)return;productRenderEpoch+=1;var token=productRenderEpoch,visible=rows.slice(0,Math.max(0,limit||100)),cursor=0;container.innerHTML='';function step(){if(token!==productRenderEpoch||!container.isConnected)return;var end=Math.min(cursor+20,visible.length),html='';for(;cursor<end;cursor++)html+=renderer(visible[cursor],cursor);container.insertAdjacentHTML('beforeend',html);wireProductImages(container);syncFrontSelectionControls();if(cursor<visible.length){if(window.requestIdleCallback)window.requestIdleCallback(step,{timeout:120});else setTimeout(step,16);}}step();}
  function pageCount(total,size){return Math.max(1,Math.ceil(Math.max(0,Number(total)||0)/Math.max(1,Number(size)||MANAGEMENT_PAGE_SIZE)));}
  function clampPage(page,total,size){return Math.max(0,Math.min(Math.max(0,Number(page)||0),pageCount(total,size)-1));}
  function pagerMarkup(kind,key,page,total,size){size=Math.max(1,Number(size)||MANAGEMENT_PAGE_SIZE);page=clampPage(page,total,size);var pages=pageCount(total,size),start=total?page*size+1:0,end=Math.min(total,(page+1)*size);if(pages<=1)return'<div class="management-pager"><span class="small">'+start+'-'+end+' / '+total+'건</span></div>';return'<div class="management-pager" data-management-pager="'+esc(kind)+'" data-management-pager-key="'+esc(key||'')+'"><button type="button" class="secondary" data-page-delta="-1" '+(page<=0?'disabled':'')+'>이전</button><span class="small">'+(page+1)+' / '+pages+' 페이지 · '+start+'-'+end+' / '+total+'건</span><button type="button" class="secondary" data-page-delta="1" '+(page>=pages-1?'disabled':'')+'>다음</button></div>'; }
  function wireProductImages(root){Array.prototype.forEach.call((root||document).querySelectorAll('[data-product-image]:not([data-image-wired])'),function(img){img.setAttribute('data-image-wired','1');img.addEventListener('error',function(){img.classList.add('hidden');var fallback=img.parentNode&&img.parentNode.nextElementSibling;if(fallback)fallback.classList.remove('hidden');});});}
  function queueCandidateId(row){return text(row&&(row.candidateId||row.id));}
  function queueVisibleRows(rows){
    return (Array.isArray(rows)?rows:[]).filter(function(row){var stage=text(row&&row.stageStatus).toLowerCase(),status=text(row&&row.status).toLowerCase();return !['held','hold','rejected','reject','suppressed','deleted','removed'].includes(stage)&&!['held','hold','rejected','reject','suppressed','deleted','removed'].includes(status);});
  }
  function syncQueueToggleLabel(){syncDetailsToggle($('queuePanel'),$('queueToggleLabel'));}
  function closeQueuePanel(){var panel=$('queuePanel');if(panel&&typeof panel.open==='boolean'){panel.open=false;clearHeavyPanel(panel);}syncQueueToggleLabel();}
  function selectedQueueIds(){var body=$('queueRows');if(!body)return[];return Array.prototype.map.call(body.querySelectorAll('[data-queue-select]:checked'),function(input){return text(input.value);}).filter(Boolean);}
  function syncQueueSelectionControls(){
    var body=$('queueRows'),all=$('queueSelectAll'),boxes=body?Array.prototype.slice.call(body.querySelectorAll('[data-queue-select]')):[],selected=boxes.filter(function(box){return box.checked;});
    if(all){all.checked=boxes.length>0&&selected.length===boxes.length;all.indeterminate=selected.length>0&&selected.length<boxes.length;all.disabled=!boxes.length;}
    if($('queueSelectedCount'))$('queueSelectedCount').textContent='선택 '+selected.length+'건';
    if($('queueOpenInProductManagerBtn'))$('queueOpenInProductManagerBtn').disabled=!selected.length;
    if($('queueSelectedAiPlaceBtn'))$('queueSelectedAiPlaceBtn').disabled=!selected.length;
    if($('queueSelectedManualPlaceBtn'))$('queueSelectedManualPlaceBtn').disabled=!selected.length;
    Array.prototype.forEach.call(document.querySelectorAll('[data-queue-bulk]'),function(button){button.disabled=!selected.length;});
  }
  async function openSelectedQueueProductsInManager(){
    var ids=selectedQueueIds();if(!ids.length){show('상품 관리목록에서 확인할 대기열 상품을 선택해 주세요.','warn');return;}
    queueFocusedCandidateIds=ids.slice(0,3000);
    ids.forEach(function(id){candidateSelectedProducts[text(id)]=true;});
    try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_refreshError){}
    var panel=$('productCandidatePanel');
    if(panel){
      panel.classList.remove('hidden');
      panel.open=true;
      renderProductCandidateGroups();
      var selectedGroup=panel.querySelector('details[data-product-group="queue_selected"]');
      if(selectedGroup){selectedGroup.open=true;var selectedLabel=selectedGroup.querySelector('[data-group-toggle-label]');syncDetailsToggle(selectedGroup,selectedLabel);}
      panel.scrollIntoView({behavior:'smooth',block:'start'});
    }
    syncCandidateSelectionControls('queue_selected');
    saveReviewSnapshot();
    show('선택한 대기열 상품 '+ids.length+'건을 상품 관리목록으로 가져왔습니다. 선택 상태도 유지했으므로 바로 AI 자동배치·수동배치·보류·제외·영구 제외를 실행할 수 있습니다.','ok');
  }
  async function runSelectedQueueAiPlacement(){
    var ids=selectedQueueIds();if(!ids.length){show('AI 자동배치할 상품을 먼저 선택해 주세요.','warn');return;}
    queueFocusedCandidateIds=ids.slice(0,3000);
    try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_refreshError){}
    ids.forEach(function(id){candidateSelectedProducts[text(id)]=true;});
    await runProductAiAutomation('products','',ids);
    try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_refreshError2){}
    show('선택 상품 '+ids.length+'건의 AI 18개 섹션 자동배치를 요청했습니다. 배치 결과는 18개 섹션 배치 예정 상품 목록에서 확인할 수 있습니다.','ok');
  }
  async function runSelectedQueueManualPlacement(){
    var ids=selectedQueueIds(),placement=text($('queueSelectedManualSection')&&$('queueSelectedManualSection').value);
    if(!ids.length){show('수동 배치할 상품을 먼저 선택해 주세요.','warn');return;}
    if(!PRODUCT_SECTION_MAP[placement]){show('수동 배치할 18개 섹션을 선택해 주세요.','warn');return;}
    try{
      var result=await api(CONTROL,'product_candidate_ledger_bulk_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateIds:ids,decision:'slot_candidate',placementKey:placement},45000);
      await refreshCandidateLedgerProducts({preserveResearchReport:true});
      show('선택 상품 '+Number(result&&result.processed||ids.length)+'건을 '+sectionLabel(placement)+' 배치 예정 목록으로 이동했습니다. 프론트 공개는 아직 실행하지 않았습니다.','ok');
    }catch(error){show(conciseRequestError(error&&error.message,error&&error.status)||'선택 상품 수동배치를 완료하지 못했습니다.','fail');}
  }

  function queueActionMessage(action,count){
    if(action==='dismiss')return '선택 '+count+'건을 현재 대기열에서 삭제합니다. 차단 기록은 남기지 않아 이후 공식 상품 리서치에서 다시 발견될 수 있습니다. 계속하시겠습니까?';
    if(action==='purge')return '선택 '+count+'건을 영구 제외합니다. 이 작업은 보류·제외 관리에서만 사용하는 최종 삭제입니다. 계속하시겠습니까?';
    if(action==='reject')return '선택 '+count+'건을 현재 전체상품 대기열에서 빼고 제외 관리 목록으로 이동합니다. 영구 삭제는 하지 않습니다. 계속하시겠습니까?';
    return '선택 '+count+'건을 현재 화면 목록에서만 제거합니다. 원장과 기존 검토 기록은 유지됩니다. 계속하시겠습니까?';
  }
  async function applyQueueAction(action){
    var ids=selectedQueueIds();if(!ids.length){show('처리할 상품 후보를 선택해 주세요.','warn');return;}if(!window.confirm(queueActionMessage(action,ids.length)))return;
    try{
      var data=await api(QUEUE_CONTROL,'bulk_action','POST',{}, {candidateIds:ids,decision:action,countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE'});
      var done=new Set((data.processedIds||ids).map(text));queueCandidateRows=queueCandidateRows.filter(function(row){return !done.has(queueCandidateId(row));});renderQueue(queueCandidateRows);try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_refreshError){}
      show('선택 '+(data.processed||done.size)+'건의 상품 후보 대기열 정리를 완료했습니다. 영구 삭제는 보류·제외 관리에서만 수행합니다.','ok');
    }catch(e){show(text(e&&e.message)||'상품 후보 대기열을 정리하지 못했습니다.','fail');}
  }

  function renderQueueRows(){
    var body=$('queueRows');if(!body)return;var total=queueCandidateRows.length;queuePage=clampPage(queuePage,total,MANAGEMENT_PAGE_SIZE);var pageStart=queuePage*MANAGEMENT_PAGE_SIZE,rows=queueCandidateRows.slice(pageStart,pageStart+MANAGEMENT_PAGE_SIZE);
    var html=rows.length?rows.map(function(c,index){var absolute=pageStart+index,p=c.placement||{},r=c.revenue||{},m=c.scopeMatch||{},reasons=Array.isArray(c.reasons)?c.reasons.join(', '):'-',id=queueCandidateId(c),url=queueCandidateUrl(c),supplierUrl=queueSupplierUrl(c),title=text(c.title||c.name||id||'상품 후보'),link=url?externalReviewAnchor(url,title,'queue-primary-link'):'<strong>'+esc(title)+'</strong>',review=url?'<br>'+externalReviewAnchor(url,'상품 원본 열기','queue-review-link'):'',supplier=supplierUrl&&supplierUrl!==url?'<br>'+externalReviewAnchor(supplierUrl,'업체 사이트 열기','queue-review-link'):'';return'<tr data-review-anchor="queue-'+esc(reviewAnchorToken(id||url||title,absolute))+'"><td class="queue-number">'+(absolute+1)+'</td><td class="supplier-select-cell"><input type="checkbox" data-queue-select value="'+esc(id)+'" aria-label="'+esc((absolute+1)+'번 '+title)+' 선택" '+(!id?'disabled':'')+'></td><td>'+link+review+supplier+'<br><span class="mono">'+esc(id||'-')+'</span>'+(url?'<a class="queue-source-url mono" href="'+esc(url)+'" target="_top" data-review-link="1" rel="noreferrer external nofollow" referrerpolicy="no-referrer">'+esc(url)+'</a>':'')+'</td><td>'+esc(m.mode||'-')+'<br>'+esc((m.country||'-')+' / '+(m.region||'-'))+'</td><td>'+(c.releaseEligible?'<span class="pill good">통과</span>':'<span class="pill warn">보류</span>')+'</td><td>'+esc((p.page||'-')+' / '+(p.section||'-'))+'</td><td>'+esc((c.marketKeys||[]).join(', ')||'-')+'</td><td>'+esc(r.type||'-')+' / '+esc(r.monetizationState||'-')+'</td><td>'+esc(reasons)+'</td></tr>';}).join(''):'<tr><td colspan="9" class="small">이 범위의 기존 후보가 없습니다.</td></tr>';
    html+='<tr class="queue-pager-row"><td colspan="9">'+pagerMarkup('queue','',queuePage,total,MANAGEMENT_PAGE_SIZE)+'</td></tr>';body.innerHTML=html;syncQueueSelectionControls();
  }
  function renderQueue(rows){
    var panel=$('queuePanel'),currentScope=scopeKey(),sameScope=queueControlScopeKey===currentScope;queueControlScopeKey=currentScope;queueCandidateRows=queueVisibleRows(rows);if(!sameScope)queuePage=0;queuePage=clampPage(queuePage,queueCandidateRows.length,MANAGEMENT_PAGE_SIZE);
    if(!panel)return;panel.classList.remove('hidden');if(!sameScope)panel.open=false;if($('queueSummary'))$('queueSummary').textContent=queueCandidateRows.length+'건';syncQueueToggleLabel();if(panel.open)renderQueueRows();else if($('queueRows'))$('queueRows').innerHTML='';
  }

  function candidateLedgerFrontStatus(row){var life=row&&row.lifecycle||{},assignment=life.assignment||{},status=text(assignment.publicationStatus||assignment.publication_status).toLowerCase();if(!status||status==='audit_ready')return null;return{schema:'igdc-product-front-publication-control.v1',candidateId:text(row&&row.candidateId),status:status,queued:status==='publish_requested',persisted:true,pendingBuild:false,publicSnapshotConfirmed:false};}
  function candidateLedgerProductRow(row){
    row=row||{};var rr=row.researchReadiness||{},card=(row.productCard&&row.productCard.checkoutUrl)?row.productCard:(rr.productCard||row.productCard||{}),supplier=row.supplier||{},placement=row.placement||{},stage=text(row.stageStatus).toLowerCase(),page=text(placement.page),section=text(placement.section||placement.sectionKey),key=page&&section?page+'|'+section:'',decision='undecided';
    if(stage==='held'||stage==='hold')decision='hold';else if(stage==='rejected'||stage==='reject'||stage==='suppressed')decision='reject';else if(key&&PRODUCT_SECTION_MAP[key]&&stage!=='administrator_selection_pending')decision='slot_candidate';
    var approved=decision==='slot_candidate'?{page:page,section:section,sectionKey:section,country:selectedCountry,region:selectedSubdivision||'NATIONWIDE',administratorSelected:false,aiSelected:true,publicPublication:false,publicReleaseEvidencePending:row.releaseEligible!==true}:null;
    var url=safeExternalUrl(card.checkoutUrl||row.url||row.official_url),image=safeExternalImageUrl(card.image||row.image||row.thumbnail_url),supplierUrl=safeExternalUrl(card.supplierUrl||supplier.officialUrl||supplier.url),front=candidateLedgerFrontStatus(row);
    return{ledgerSource:'candidate',candidateId:text(row.candidateId),id:text(row.candidateId),productName:text(card.title||row.title||'상품명 확인 중'),title:text(card.title||row.title||'상품명 확인 중'),sourceTitle:text(card.sourceTitle||row.title),productUrl:url,url:url,imageUrl:image,imageOriginalUrl:image,price:card.price==null?null:card.price,priceCurrency:text(card.priceCurrency),availability:card.availability==null?null:card.availability,supplierName:text(card.supplierName||supplier.name||row.destinationHost||'판매처 확인 필요'),supplierSiteUrl:supplierUrl,supplierTrustScore:Number(supplier.trustScore||row.ranking&&row.ranking.sellerTrust||0),supplierEvidenceReady:!!(supplier.evidenceReady),researchStatus:text(rr.stage||'private_research_queue'),inspectionComplete:!!(url&&image),productPageLive:!!url,slotDecision:decision,approvedPlacement:approved,primaryPlacement:approved,sectionAssignments:Array.isArray(row.proposedPlacements)?row.proposedPlacements:[],frontPublication:front,releaseEligible:row.releaseEligible===true,marketKeys:Array.isArray(row.marketKeys)?row.marketKeys:[],revenue:row.revenue||{},review:row.review||{},queueControl:row.queueControl||{},reasons:Array.isArray(row.reasons)?row.reasons:[],managementControl:{source:'candidate_ledger',administratorLocked:false,aiReclassificationAllowed:true},publicPublication:false,automaticImport:false};
  }
  function candidateLedgerProductData(queueData){var rows=Array.isArray(queueData&&queueData.candidates)?queueData.candidates:[],products=rows.map(candidateLedgerProductRow),summary={privateResearchQueueEligible:products.length,privateResearchQueueStaged:products.length,discovered:products.length,inspected:products.filter(function(row){return row.inspectionComplete===true;}).length,withImage:products.filter(function(row){return!!row.imageUrl;}).length,readyForAdminReview:products.filter(function(row){return!!row.productUrl;}).length,slotCandidates:products.filter(function(row){return productDecision(row)==='slot_candidate';}).length,held:products.filter(function(row){return productDecision(row)==='hold';}).length,rejected:products.filter(function(row){return productDecision(row)==='reject';}).length};return{ok:true,candidateLedger:true,reportType:'igdc-candidate-ledger-product-control-snapshot',status:'candidate_ledger',scope:scopeSnapshot(),products:products,summary:summary,progress:{stage:'candidate_ledger',discovery:{done:0,total:0},inspection:{done:summary.inspected,total:products.length},privateQueue:{done:products.length,total:products.length,summary:{eligible:products.length,created:0,updated:0,preserved:products.length,failed:0}},resumable:false},pipeline:{version:'candidate-ledger-control',automaticPrivateResearchStaging:false,automaticPublicPublication:false,nextGate:'administrator_product_selection_and_front_match'}};}
  function candidateLedgerViewActive(){return productRows.some(function(row){return row&&row.ledgerSource==='candidate';});}
  async function refreshCandidateLedgerProducts(options){options=options||{};var q=await api(REVIEW,'candidates','GET',scopeParams(),null,20000);renderQueue(q.candidates||[]);var data=candidateLedgerProductData(q);renderProducts(data.products||[]);var currentStatus=text(lastProductJson&&lastProductJson.status),hasResearchState=!!lastProductJson&&currentStatus&&currentStatus!=='candidate_ledger'&&currentStatus!=='not_started',preserve=options.preserveResearchReport===true||(options.preserveResearchReport!==false&&hasResearchState);if(preserve){saveReviewSnapshot();return data;}lastProductJson=data;rememberReport('product',data);renderProductProgress(data);saveReviewSnapshot();return data;}
  function wireQueueControls(){
    var all=$('queueSelectAll');if(all)all.addEventListener('change',function(){var checked=all.checked,body=$('queueRows');if(body)Array.prototype.forEach.call(body.querySelectorAll('[data-queue-select]'),function(box){box.checked=checked;});syncQueueSelectionControls();});
    var body=$('queueRows');if(body){body.addEventListener('change',function(event){if(event.target&&event.target.matches('[data-queue-select]'))syncQueueSelectionControls();});body.addEventListener('click',function(event){var button=event.target&&event.target.closest?event.target.closest('[data-management-pager=\"queue\"] [data-page-delta]'):null;if(!button)return;event.preventDefault();queuePage=clampPage(queuePage+Number(button.getAttribute('data-page-delta')||0),queueCandidateRows.length,MANAGEMENT_PAGE_SIZE);renderQueueRows();});}
    if($('queueOpenInProductManagerBtn'))$('queueOpenInProductManagerBtn').addEventListener('click',openSelectedQueueProductsInManager);
    if($('queueSelectedAiPlaceBtn'))$('queueSelectedAiPlaceBtn').addEventListener('click',runSelectedQueueAiPlacement);
    if($('queueSelectedManualPlaceBtn'))$('queueSelectedManualPlaceBtn').addEventListener('click',runSelectedQueueManualPlacement);
    Array.prototype.forEach.call(document.querySelectorAll('[data-queue-bulk]'),function(button){button.addEventListener('click',function(){applyQueueAction(button.getAttribute('data-queue-bulk'));});});
  }
  function supplierActionLabel(action){return {keep:'계속 확인·유지',hold:'후보 제외·보류',unpin:'관리자 고정 해제',restore:'본 후보로 복원',dismiss:'목록 삭제·재수집 허용',purge:'URL 영구 제외',block:'도메인 차단',unblock:'차단 해제·보류 이동',remove_from_list:'목록에서만 제거'}[action]||action;}
  function supplierActionMessage(action,count){
    count=Number(count||0);
    if(action==='purge')return '선택 '+count+'건을 현재 목록에서 제거하고 같은 URL이 다시 수집되지 않도록 영구 제외 지문을 남깁니다. 계속하시겠습니까?';
    if(action==='block')return '선택 '+count+'건의 도메인을 차단합니다. 같은 도메인의 다른 후보도 현재 목록에서 빠지고 이후 리서치에서 다시 올라오지 않습니다. 계속하시겠습니까?';
    if(action==='dismiss')return '선택 '+count+'건을 현재 후보 제외 목록에서 삭제합니다. 차단 기록은 남기지 않아 다음 새 검색에서 다시 발견될 수 있습니다. 계속하시겠습니까?';
    if(action==='remove_from_list')return '선택 '+count+'건을 현재 화면 목록에서만 제거합니다. 기존 영구 제외·도메인 차단 기록은 그대로 유지됩니다. 계속하시겠습니까?';
    if(action==='unpin')return '선택 '+count+'건의 관리자 고정을 해제합니다. 현재 본 후보에는 남지만 다음 자동 리서치에서 고정 우선권은 유지되지 않습니다. 계속하시겠습니까?';
    return '';
  }
  async function applySupplierResearchAction(action,urlOrUrls){
    var urls=(Array.isArray(urlOrUrls)?urlOrUrls:[urlOrUrls]).map(safeExternalUrl).filter(Boolean);
    urls=Array.from(new Set(urls));if(!urls.length){show('처리할 공급업체 후보를 선택해 주세요.','warn');return;}
    var message=supplierActionMessage(action,urls.length);if(message&&!window.confirm(message))return;
    try{
      var data=await api(CONTROL,'research_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',urls:urls,url:urls[0],decision:action});
      lastCountryPreview=data;lastCountryJson=data;renderResearchProgress(data);renderSummary(data,{candidates:data.candidates||[]},'공급업체 후보 관리 반영');renderAi(data.candidates||[],data.holdingCandidates||[],data.blockedCandidates||[]);rememberReport('country',data);var hasCandidates=Array.isArray(data.candidates)&&data.candidates.length>0,complete=data.status==='complete'||data.status==='committed';setButtonEnabled('runNowBtn',hasCandidates&&complete);setButtonEnabled('productResearchBtn',hasCandidates&&complete);saveReviewSnapshot();
      var result=data&&data.candidateAction||{},processed=Number(result.processed||urls.length),missing=Number(result.notFound||0);
      show('공급업체 후보 '+processed+'건을 '+supplierActionLabel(action)+' 처리했습니다.'+(missing?' 현재 작업에서 찾지 못한 항목 '+missing+'건이 있습니다.':'')+' 상품 반입이나 사이트 공개는 실행하지 않았습니다.','ok');
    }catch(e){show(text(e.message)||'공급업체 후보 상태를 저장하지 못했습니다.','fail');}
  }
  async function registerManualSupplier(){
    if(!selectedCountry){show('먼저 등록할 국가·지역 범위를 선택해 주세요.','warn');return;}
    var name=text($('supplierManualName')&&$('supplierManualName').value),officialUrl=safeExternalUrl($('supplierManualOfficialUrl')&&$('supplierManualOfficialUrl').value),productPageUrl=safeExternalUrl($('supplierManualProductUrl')&&$('supplierManualProductUrl').value),supplierType=text($('supplierManualType')&&$('supplierManualType').value)||'responsible_seller',affiliateStageValue=text($('supplierManualAffiliateStage')&&$('supplierManualAffiliateStage').value)||'connection_required',trackingUrl=safeExternalUrl($('supplierManualTrackingUrl')&&$('supplierManualTrackingUrl').value),programId=text($('supplierManualProgramId')&&$('supplierManualProgramId').value),settlementMode=text($('supplierManualSettlementMode')&&$('supplierManualSettlementMode').value);
    if(!name||!officialUrl){show('업체명과 HTTPS 공식 업체 URL을 입력해 주세요.','warn');return;}
    if(!/^https:\/\//i.test(officialUrl)||(productPageUrl&&!/^https:\/\//i.test(productPageUrl))){show('관리자 직접 등록은 HTTPS 공식 주소만 사용할 수 있습니다.','warn');return;}
    var button=$('supplierManualRegisterBtn');if(button)button.disabled=true;
    try{
      var data=await api(CONTROL,'supplier_manual_register','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',name:name,officialUrl:officialUrl,productPageUrl:productPageUrl||null,supplierType:supplierType,affiliateSettlement:{stage:affiliateStageValue,counterparty:name,trackingUrl:trackingUrl||null,programId:programId||null,settlementMode:settlementMode||null,payoutBasisVerified:affiliateStageValue==='connection_required'?false:true,trackingVerified:!!trackingUrl,officialDestination:true,contractVerified:affiliateStageValue==='formal_partner'}});
      lastCountryPreview=data;lastCountryJson=data;renderResearchProgress(data);renderSummary(data,{candidates:data.candidates||[]},'관리자 직접 업체 등록·검증');renderAi(data.candidates||[],data.holdingCandidates||[],data.blockedCandidates||[]);rememberReport('country',data);var hasCandidates=Array.isArray(data.candidates)&&data.candidates.length>0,complete=data.status==='complete'||data.status==='committed';setButtonEnabled('runNowBtn',hasCandidates&&complete);setButtonEnabled('productResearchBtn',hasCandidates&&complete);setButtonEnabled('countryRunDownloadBtn',true);saveReviewSnapshot();
      if($('supplierManualName'))$('supplierManualName').value='';if($('supplierManualOfficialUrl'))$('supplierManualOfficialUrl').value='';if($('supplierManualProductUrl'))$('supplierManualProductUrl').value='';if($('supplierManualTrackingUrl'))$('supplierManualTrackingUrl').value='';if($('supplierManualProgramId'))$('supplierManualProgramId').value='';if($('supplierManualAffiliateStage'))$('supplierManualAffiliateStage').value='connection_required';if($('supplierManualSettlementMode'))$('supplierManualSettlementMode').value='';
      var result=data&&data.manualRegistration||{},affiliate=result.affiliateSettlement||{};show('관리자 직접 업체를 현재 범위에 등록·고정했습니다. 제휴 단계: '+affiliateStageLabel(affiliate.stage||'connection_required')+'.'+(result.verificationStatus?' 검증 상태: '+result.verificationStatus:'')+' 자동 공개나 상품 반입·정산 실행은 하지 않았습니다.','ok');
    }catch(e){show(text(e.message)||'관리자 직접 업체 등록에 실패했습니다.','fail');}
    finally{if(button)button.disabled=false;}
  }
  function wireSupplierControlButtons(root){
    root=root||document;if(root.getAttribute&&root.getAttribute('data-supplier-control-wired')==='1')return;if(root.setAttribute)root.setAttribute('data-supplier-control-wired','1');
    root.addEventListener('click',function(event){var button=event.target&&event.target.closest?event.target.closest('[data-supplier-control]'):null;if(!button||!root.contains(button))return;applySupplierResearchAction(button.getAttribute('data-supplier-control'),button.getAttribute('data-supplier-url'));});
  }
  function supplierSelectionConfig(kind){
    return {active:{all:'supplierActiveSelectAll',count:'supplierActiveSelectedCount'},hold:{all:'supplierHoldSelectAll',count:'supplierHoldSelectedCount'},blocked:{all:'supplierBlockedSelectAll',count:'supplierBlockedSelectedCount'}}[kind]||{};
  }
  function supplierSelectionBoxes(kind){return Array.prototype.slice.call(document.querySelectorAll('[data-supplier-select="'+kind+'"]')).filter(function(box){return !box.disabled;});}
  function supplierSelectedUrls(kind){return supplierSelectionBoxes(kind).filter(function(box){return box.checked;}).map(function(box){return safeExternalUrl(box.value);}).filter(Boolean);}
  function syncSupplierSelection(kind){
    var cfg=supplierSelectionConfig(kind),boxes=supplierSelectionBoxes(kind),selected=boxes.filter(function(box){return box.checked;});
    var all=cfg.all&&$(cfg.all),count=cfg.count&&$(cfg.count);if(all){all.checked=boxes.length>0&&selected.length===boxes.length;all.indeterminate=selected.length>0&&selected.length<boxes.length;all.disabled=boxes.length===0;}if(count)count.textContent='선택 '+selected.length+'건';
    Array.prototype.forEach.call(document.querySelectorAll('[data-supplier-bulk-scope="'+kind+'"]'),function(button){button.disabled=selected.length===0;});
  }
  function wireSupplierSelectionControls(root){
    root=root||document;if(root.getAttribute&&root.getAttribute('data-supplier-selection-wired')==='1')return;if(root.setAttribute)root.setAttribute('data-supplier-selection-wired','1');
    root.addEventListener('change',function(event){var all=event.target&&event.target.getAttribute&&event.target.getAttribute('data-supplier-select-all'),kind=event.target&&event.target.getAttribute&&event.target.getAttribute('data-supplier-select');if(all){supplierSelectionBoxes(all).forEach(function(box){box.checked=event.target.checked;});syncSupplierSelection(all);}else if(kind)syncSupplierSelection(kind);});
    root.addEventListener('click',function(event){var button=event.target&&event.target.closest?event.target.closest('[data-supplier-bulk]'):null;if(!button||!root.contains(button))return;var kind=button.getAttribute('data-supplier-bulk-scope'),urls=supplierSelectedUrls(kind);if(!urls.length){show('먼저 처리할 후보를 선택해 주세요.','warn');return;}applySupplierResearchAction(button.getAttribute('data-supplier-bulk'),urls);});
  }
  function closeSupplierControlQueue(){var panel=$('supplierControlQueue');if(panel&&typeof panel.open==='boolean')panel.open=false;var outer=$('excludedLedgerPanel');if(outer&&typeof outer.open==='boolean'){outer.open=false;clearHeavyPanel(outer);}syncSupplierControlToggleLabel();syncManagementToggleLabels();}
  function syncSupplierControlToggleLabel(){var panel=$('supplierControlQueue'),label=$('supplierControlActionLabel');if(label)label.textContent=panel&&panel.open?'목록 닫기':'목록 펼치기';}
  function renderSupplierControlQueues(holdingRows,blockedRows){
    supplierHoldingRows=Array.isArray(holdingRows)?holdingRows:[];supplierBlockedRows=Array.isArray(blockedRows)?blockedRows:[];var currentScope=scopeKey(),sameScope=supplierControlScopeKey===currentScope;supplierControlScopeKey=currentScope;
    if($('supplierControlToggleLabel'))$('supplierControlToggleLabel').textContent='후보 제외 업체 목록 · 보류 '+supplierHoldingRows.length+'건 · 차단 '+supplierBlockedRows.length+'건';if(!sameScope&&$('supplierControlQueue'))$('supplierControlQueue').open=false;syncExcludedLedgerCounts();if($('excludedLedgerPanel')&&$('excludedLedgerPanel').open&&$('supplierControlQueue')&&$('supplierControlQueue').open)renderSupplierExcludedRows();
  }

  function renderSupplierExcludedRows(){
    var holdBody=$('supplierHoldRows'),blockBody=$('supplierBlockedRows');if(!holdBody||!blockBody)return;
    holdBody.innerHTML=supplierHoldingRows.length?supplierHoldingRows.map(function(row,index){var url=safeExternalUrl(row.url||row.sourceCandidateUrl),reason=row.holdReason||'추가 확인 필요',title=row.title||row.host||'후보명 확인 필요';return'<tr data-review-anchor="supplier-hold-'+esc(reviewAnchorToken(url||title,index))+'"><td class="supplier-number">'+esc(index+1)+'</td><td class="supplier-select-cell"><input type="checkbox" data-supplier-select="hold" value="'+esc(url)+'" aria-label="후보 제외 업체 '+esc(index+1)+' 선택" '+(url?'':'disabled')+'></td><td>'+(url?externalReviewAnchor(url,title,'supplier-primary-link'):'<strong>'+esc(title)+'</strong>')+'<br><span class="small mono">'+esc(url||'-')+'</span></td><td>'+esc(reason)+'</td><td>'+esc(row.supplierType||'research_reference')+'</td></tr>';}).join(''):'<tr><td colspan="5" class="small">현재 후보 제외 업체 목록이 비어 있습니다.</td></tr>';
    blockBody.innerHTML=supplierBlockedRows.length?supplierBlockedRows.map(function(row,index){var url=safeExternalUrl(row.url||row.sourceCandidateUrl),reason=row.holdReason||'관리자 차단',title=row.title||row.host||'차단 후보';return'<tr data-review-anchor="supplier-blocked-'+esc(reviewAnchorToken(url||title,index))+'"><td class="supplier-number">'+esc(index+1)+'</td><td class="supplier-select-cell"><input type="checkbox" data-supplier-select="blocked" value="'+esc(url)+'" aria-label="차단 업체 '+esc(index+1)+' 선택" '+(url?'':'disabled')+'></td><td>'+(url?externalReviewAnchor(url,title,'supplier-primary-link'):'<strong>'+esc(title)+'</strong>')+'<br><span class="small mono">'+esc(url||'-')+'</span></td><td>'+esc(row.host||'-')+'</td><td>'+esc(reason)+'</td></tr>';}).join(''):'<tr><td colspan="5" class="small">현재 차단된 공급업체 URL·도메인이 없습니다.</td></tr>';
    wireSupplierSelectionControls($('supplierControlQueue'));syncSupplierSelection('hold');syncSupplierSelection('blocked');
  }
  function renderSupplierActiveRows(){
    var body=$('aiRows');if(!body)return;var rows=supplierActiveRows;
    body.innerHTML=rows.length?rows.map(function(c,index){var ai=c.ai||c||{},trust=c.trust||{},supplier=c.supplier||{type:c.supplierType},e=c.evidence||{};function yes(v,label){return'<span class="pill '+(v?'good':'warn')+'">'+esc(label)+' '+(v?'확인':'미확인')+'</span> ';}function listBlock(label,values){values=Array.isArray(values)?values:[];return'<div class="supplier-ai-box"><strong>'+esc(label)+'</strong><div class="small">'+(values.length?values.map(function(x){return'· '+esc(x);}).join('<br>'):'-')+'</div></div>';}var evidence=yes(e.official,'공식')+yes(e.responsibleEntity,'책임주체')+yes(e.directSales,'직판')+yes(e.payment,'결제')+yes(e.shipping,'배송')+yes(e.returns,'반품')+yes(e.refund,'환불')+yes(e.service,'고객지원');var score=Number(ai.trustScore!=null?ai.trustScore:(ai.score!=null?ai.score:(trust.trustScore||0))),rating=Number(ai.rating10||trust.rating10||trustRating10(score)),rank=ai.rank||c.rank||trust.rank||index+1;var recommendation=ai.recommendationLabel||trust.recommendationLabel||ai.recommendation||trust.recommendation||'보류 권고',confidence=Number(ai.assessmentConfidence||trust.assessmentConfidence||0),mode=ai.assessmentMode||trust.assessmentMode||'deterministic_fallback';var sourceLabel=mode==='openai_grounded'?'AI 추천':'규칙기반 임시추천',summary=ai.aiSummary||trust.aiSummary||ai.reason||'',strengths=Array.isArray(ai.strengths)?ai.strengths:(Array.isArray(trust.strengths)?trust.strengths:[]),concerns=Array.isArray(ai.concerns)?ai.concerns:(Array.isArray(trust.concerns)?trust.concerns:[]),nextChecks=Array.isArray(ai.nextChecks)?ai.nextChecks:(Array.isArray(trust.nextChecks)?trust.nextChecks:[]),missing=Array.isArray(c.missingEvidence)?c.missingEvidence:(Array.isArray(ai.missingEvidence)?ai.missingEvidence:[]);var detail='<div class="supplier-ai-head"><strong>'+esc(sourceLabel)+': '+esc(recommendation)+'</strong><span class="pill '+(rating>=8?'good':'warn')+'">신뢰 '+esc(rating)+'/10</span><span class="small">'+esc(score)+'/100 · 순위 '+esc(rank)+(confidence?' · 판단확신 '+esc(confidence)+'%':'')+'</span></div><div class="small supplier-ai-summary">'+esc(summary||'확인 근거를 보완해야 합니다.')+'</div><div class="supplier-ai-grid">'+listBlock('강점',strengths)+listBlock('주의',concerns)+listBlock('다음 확인',nextChecks)+listBlock('누락 증빙',missing)+'</div>';var supplierUrl=safeExternalUrl(c.url||supplier.officialUrl),supplierTitle=text(c.title||c.id||'업체명 확인 필요'),productPageUrl=safeExternalUrl(c.productPageUrl||c.sourceCandidateUrl),manual=c.adminPinned===true||c.manualPinned===true||c.manualRegistered===true;var links=supplierUrl?externalReviewAnchor(supplierUrl,supplierTitle,'supplier-primary-link')+'<br>'+externalReviewAnchor(supplierUrl,'업체·원본 사이트 열기','supplier-review-link')+'<br>'+externalReviewAnchor(supplierUrl,supplierUrl,'supplier-url mono'):'<strong>'+esc(supplierTitle)+'</strong><br><span class="small">확인 가능한 업체 사이트 링크 없음</span>';if(productPageUrl&&productPageUrl!==supplierUrl)links+='<br>'+externalReviewAnchor(productPageUrl,manual?'지정 상품 페이지 열기':'발견 원본 페이지 열기','supplier-review-link');var affiliate=c.affiliateSettlement||{},affiliateStageValue=affiliateStage(c),state='<div class="supplier-meta-block"><strong>'+esc(supplier.type||c.kind||'supplier')+'</strong> <span class="pill info">'+esc(c.status||c.persistence||'research_preview')+'</span> '+(manual?'<span class="pill manual">관리자 직접 등록·고정</span>':'')+' <span class="pill affiliate-stage-pill '+affiliateStageClass(affiliateStageValue)+'">'+esc(affiliateStageLabel(affiliateStageValue))+'</span><div class="small">'+esc((supplier.detectedCountry||c.targetCountry||'-')+' / '+(supplier.detectedRegion||c.targetRegion||'NATIONWIDE'))+' · '+esc(c.updatedAt||c.createdAt||ai.assessedAt||trust.assessedAt||'-')+'</div></div>';var supplierCell='<div class="supplier-card-head"><div>'+links+'</div></div><div class="supplier-evidence-row">'+evidence+'</div><div class="small supplier-responsibility-note">상품 자동 공개 없음 · 선정·검증된 본 후보에서만 별도 상품 리서치 · 거래는 공급업체에서 직접 진행</div>'+state;var checkbox='<input type="checkbox" data-supplier-select="active" value="'+esc(supplierUrl)+'" aria-label="본 후보 '+esc(index+1)+' 선택" '+(supplierUrl?'':'disabled')+'>';return'<tr data-review-anchor="supplier-'+esc((c.id||c.candidateId||supplierTitle).replace(/[^0-9A-Za-z가-힣_-]+/g,'-').slice(0,48))+'"><td class="supplier-number">'+esc(index+1)+'</td><td class="supplier-select-cell">'+checkbox+'</td><td>'+supplierCell+'</td><td>'+detail+'</td></tr>';}).join(''):'<tr><td colspan="4" class="small">현재 본 후보 목록이 비어 있습니다.</td></tr>';wireSupplierSelectionControls($('aiPanel'));syncSupplierSelection('active');
  }
  function renderAi(rows,holdingRows,blockedRows){
    supplierActiveRows=Array.isArray(rows)?rows:[];supplierHoldingRows=Array.isArray(holdingRows)?holdingRows:[];supplierBlockedRows=Array.isArray(blockedRows)?blockedRows:[];var panel=$('aiPanel'),currentScope=scopeKey(),sameScope=supplierControlScopeKey===currentScope;if(panel){panel.classList.remove('hidden');if(!sameScope)panel.open=false;}if($('aiSummary'))$('aiSummary').textContent=supplierActiveRows.length+'건';renderSupplierControlQueues(supplierHoldingRows,supplierBlockedRows);if(panel&&panel.open)renderSupplierActiveRows();else if($('aiRows'))$('aiRows').innerHTML='';if($('supplierManualScopeLabel'))$('supplierManualScopeLabel').textContent='현재 선택 범위: '+scopeName();syncManagementToggleLabels();
  }


  function safeExternalUrl(value){try{var u=new URL(text(value));if((u.protocol!=='https:'&&u.protocol!=='http:')||u.username||u.password||!u.hostname)return'';return u.toString();}catch(_e){return'';}}
  function safeExternalImageUrl(value){var url=safeExternalUrl(value);return /^https:\/\//i.test(url)?url:'';}
  function safeExternalVideoUrl(value){var url=safeExternalUrl(value);return /^https:\/\//i.test(url)?url:'';}
  function externalReviewAnchor(url,label,className){var safe=safeExternalUrl(url);if(!safe)return'';return'<a href="'+esc(safe)+'" target="_top" class="'+esc(className||'')+'" data-review-link="1" rel="noreferrer external nofollow">'+esc(label)+'</a>';}
  function reviewAnchorToken(value,index){var token=text(value).replace(/[^0-9A-Za-z가-힣_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,72);return token||('row-'+String(Number(index)||0));}
  function reviewDetailPath(target){var out=[],node=target;while(node&&node!==document.body){if(node.tagName==='DETAILS'){var key=node.id||node.getAttribute('data-product-group')||node.getAttribute('data-heavy-panel')||'';if(key)out.unshift(key);}node=node.parentElement;}return out.slice(-12);}
  function reviewDetailElement(key){var wanted=text(key);if(!wanted)return null;var byId=document.getElementById(wanted);if(byId&&byId.tagName==='DETAILS')return byId;var rows=document.querySelectorAll('details');for(var i=0;i<rows.length;i++){if(rows[i].getAttribute('data-product-group')===wanted||rows[i].getAttribute('data-heavy-panel')===wanted)return rows[i];}return null;}
  function reviewAnchorElement(value){var wanted=text(value);if(!wanted)return null;var rows=document.querySelectorAll('[data-review-anchor]');for(var i=0;i<rows.length;i++){if(rows[i].getAttribute('data-review-anchor')===wanted)return rows[i];}return null;}
  function reviewReturnValue(){var row=null;try{row=parseJson(sessionStorage.getItem(REVIEW_RETURN_KEY)||'');}catch(_e){}if(!row||row.path!==(location.pathname+location.search)||Date.now()-Number(row.at||0)>21600000)return null;return row;}
  function compactProductSnapshot(data){if(!data||typeof data!=='object')return null;return{ok:true,reportType:data.reportType||'igdc-country-product-reference-persisted-research',version:data.version||'',jobId:data.jobId||null,jobVersion:data.jobVersion||'',needsRefresh:data.needsRefresh===true,status:data.status||'not_started',startedAt:data.startedAt||null,finishedAt:data.finishedAt||null,updatedAt:data.updatedAt||null,scope:data.scope||scopeSnapshot('review-return-cache'),safety:data.safety||{},progress:data.progress||{},summary:data.summary||{},pipeline:data.pipeline||{},sectionQueues:data.sectionQueues||{},products:Array.isArray(data.products)?data.products.slice(0,600):[],trace:Array.isArray(data.trace)?data.trace.slice(-30):[],errors:Array.isArray(data.errors)?data.errors.slice(-30):[],lastError:data.lastError||null};}
  async function loadProductResearchCompact(country,region){return api(CONTROL,'product_research_status','GET',{country:country,region:region||'NATIONWIDE',compact:'1'});}
  async function loadProductResearchPaged(country,region,options){
    options=options||{};var pageSize=Math.max(50,Math.min(200,Number(options.pageSize||200))),offset=0,pages=0,merged=null,rows=[],latest=[],seen={},latestSeen={},state=options.state||null,maxPages=Math.max(1,Math.min(20,Number(options.maxPages||20))),partialError=null;
    while(pages<maxPages){
      var page=null,pageError=null;
      for(var attempt=0;attempt<3&&!page;attempt++){
        try{page=await api(CONTROL,'product_research_status','GET',{country:country,region:region||'NATIONWIDE',fast:'page:'+offset+':'+pageSize});}
        catch(loadError){pageError=loadError;if(attempt<2)await new Promise(function(resolve){setTimeout(resolve,500*(attempt+1));});}
      }
      if(!page){partialError=pageError;if(!merged)throw pageError||new Error('상품 관리 목록을 분할 로딩하지 못했습니다.');if(state)state.textContent=(options.label||'상품 관리 목록')+' '+rows.length+'건까지 안전 로딩 · 다음 묶음은 일시 중단됐습니다.';break;}
      if(!merged)merged=page;pages+=1;
      var pageRows=Array.isArray(page.products)?page.products:[];
      pageRows.forEach(function(row){var key=text(row&&row.id)||text(row&&row.productUrl)||text(row&&row.url);if(!key||seen[key])return;seen[key]=true;rows.push(row);});
      (Array.isArray(page.latestProducts)?page.latestProducts:[]).forEach(function(row){var key=text(row&&row.id)||text(row&&row.productUrl)||text(row&&row.url);if(!key||latestSeen[key])return;latestSeen[key]=true;latest.push(row);});
      var pg=page.pagination||{},total=Number(pg.total||rows.length);if(state)state.textContent=(options.label||'상품 관리 목록')+' '+rows.length+'/'+total+'건 분할 로딩 · '+pageSize+'건 단위';
      if(pg.hasMore!==true||pg.nextOffset==null)break;offset=Number(pg.nextOffset||0);await new Promise(function(resolve){setTimeout(resolve,180);});
    }
    if(!merged)merged={ok:true,status:'not_started',products:[],latestProducts:[],summary:{},progress:{}};
    merged=Object.assign({},merged,{products:rows,latestProducts:latest,pagination:Object.assign({},merged.pagination||{},{loadedPages:pages,loadedItems:rows.length,complete:!partialError&&(merged.pagination&&merged.pagination.total!=null?rows.length>=Number(merged.pagination.total||0):true),partial:!!partialError,error:partialError?text(partialError&&partialError.message):null})});
    return merged;
  }
  async function loadLatestResearchPaged(country,region,options){
    options=options||{};var pageSize=Math.max(50,Math.min(200,Number(options.pageSize||200))),offset=0,pages=0,rows=[],seen={},state=options.state||null,maxPages=Math.max(1,Math.min(20,Number(options.maxPages||20))),partialError=null,lastPage=null;
    while(pages<maxPages){
      var page=null,pageError=null;
      for(var attempt=0;attempt<3&&!page;attempt++){
        try{page=await api(CONTROL,'product_research_status','GET',{country:country,region:region||'NATIONWIDE',fast:'latest:'+offset+':'+pageSize});}
        catch(loadError){pageError=loadError;if(attempt<2)await new Promise(function(resolve){setTimeout(resolve,450*(attempt+1));});}
      }
      if(!page){partialError=pageError;if(!rows.length&&options.preserveOnFailure!==true)throw pageError||new Error('최신 상품 리서치 목록을 분할 로딩하지 못했습니다.');if(state)state.textContent=(options.label||'최신 상품 리서치 목록')+' '+rows.length+'건까지 안전 로딩 · 다음 묶음 응답은 보류했습니다.';break;}
      lastPage=page;pages+=1;
      var pageRows=Array.isArray(page.latestProducts)?page.latestProducts:[];
      pageRows.forEach(function(row){var key=latestProductKey(row);if(!key||seen[key])return;seen[key]=true;rows.push(row);});
      var pg=page.pagination||{},total=Number(pg.total==null?rows.length:pg.total);if(state)state.textContent=(options.label||'최신 상품 리서치 목록')+' '+rows.length+'/'+total+'건 분할 로딩 · '+pageSize+'건 단위';
      if(pg.hasMore!==true||pg.nextOffset==null)break;
      var next=Number(pg.nextOffset);if(!Number.isFinite(next)||next<=offset)break;offset=next;await new Promise(function(resolve){setTimeout(resolve,180);});
    }
    return{rows:rows,pages:pages,partial:!!partialError,error:partialError?text(partialError&&partialError.message):null,status:lastPage||null,complete:!partialError};
  }
  async function refreshLatestResearchRows(country,region,options){
    options=options||{};var previous=latestProductRows.slice(),loaded=null;
    try{loaded=await loadLatestResearchPaged(country,region,Object.assign({preserveOnFailure:true},options));}
    catch(error){if(options.throwOnFailure===true)throw error;return{rows:previous,partial:true,error:text(error&&error.message),complete:false};}
    if(loaded&&Array.isArray(loaded.rows)&&(loaded.rows.length||loaded.complete===true||!previous.length))latestProductRows=loaded.rows;
    var status=loaded&&loaded.status||{};lastProductJson=Object.assign({},lastProductJson||{},status,{products:productRows,latestProducts:latestProductRows});
    renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();return Object.assign({},loaded,{rows:latestProductRows});
  }

  function mergeCompactProductStatus(statusData){return Object.assign({},lastProductJson||{},statusData||{},{products:productRows,latestProducts:latestProductRows});}
  function compactCountrySnapshot(data){if(!data||typeof data!=='object')return null;return{ok:true,reportType:data.reportType||'igdc-country-responsible-supplier-persisted-research',version:data.version||'',jobId:data.jobId||null,status:data.status||'not_started',startedAt:data.startedAt||null,finishedAt:data.finishedAt||null,updatedAt:data.updatedAt||null,scope:data.scope||scopeSnapshot('review-return-cache'),progress:data.progress||{},summary:data.summary||{},candidates:Array.isArray(data.candidates)?data.candidates.slice(0,80):[],holdingCandidates:Array.isArray(data.holdingCandidates)?data.holdingCandidates.slice(0,160):[],blockedCandidates:Array.isArray(data.blockedCandidates)?data.blockedCandidates.slice(0,160):[],blockedSupplierKeys:Array.isArray(data.blockedSupplierKeys)?data.blockedSupplierKeys.slice(0,300):[],lastError:data.lastError||null};}
  function compactScopeCache(data){if(!data||typeof data!=='object')return null;return{scope:data.scope||scopeSnapshot('review-return-cache'),scopeData:data.scopeData?{candidates:Array.isArray(data.scopeData.candidates)?data.scopeData.candidates.slice(0,80):[],marketSignals:data.scopeData.marketSignals||{},effective:data.scopeData.effective||{}}:null,summaryData:data.summaryData||null,queueData:data.queueData?{candidates:Array.isArray(data.queueData.candidates)?data.queueData.candidates.slice(0,120):[]}:null,researchData:compactCountrySnapshot(data.researchData),productData:compactProductSnapshot(data.productData)};}
  function openDetailKeys(){return Array.prototype.slice.call(document.querySelectorAll('details[open]')).map(function(el){return el.id||el.getAttribute('data-product-group')||el.getAttribute('data-heavy-panel')||'';}).filter(Boolean).slice(0,80);}
  function sessionMemoryHost(){var rows=sources();for(var i=rows.length-1;i>=0;i--){try{void rows[i].location.href;return rows[i];}catch(_e){}}return window;}
  function sessionMemoryRead(){try{var row=sessionMemoryHost().__IGDC_COUNTRY_CONTROL_RUNTIME_V1__;return row&&row.schema==='igdc-country-control-runtime.v1'&&Date.now()-Number(row.savedAt||0)<=21600000?row:null;}catch(_e){return null;}}
  function sessionMemoryWrite(snapshot){
    try{sessionMemoryHost().__IGDC_COUNTRY_CONTROL_RUNTIME_V1__={schema:'igdc-country-control-runtime.v1',savedAt:Date.now(),path:location.pathname+location.search,scope:snapshot.scope,ui:snapshot,scopeCache:lastScopeCache,country:lastCountryPreview||lastCountryJson||null,product:lastProductJson||null,signal:lastSignalReport||null,auditKind:activeScopeAudit||'',audit:lastScopeAuditJson||null};}catch(_e){}
  }
  function sessionMemoryClear(){try{delete sessionMemoryHost().__IGDC_COUNTRY_CONTROL_RUNTIME_V1__;}catch(_e){}}
  function reviewDataCachePayload(snapshot){
    var scopeCache=compactScopeCache(lastScopeCache);
    if(scopeCache){scopeCache.productData=null;scopeCache.researchData=null;}
    return{schema:'igdc-country-control-review-data.v1',savedAt:Date.now(),path:location.pathname+location.search,scope:snapshot.scope,scopeCache:scopeCache,country:compactCountrySnapshot(lastCountryPreview||lastCountryJson),product:compactProductSnapshot(lastProductJson),signal:lastSignalReport||null,auditKind:activeScopeAudit||'',audit:lastScopeAuditJson||null};
  }
  function saveReviewDataCache(snapshot){
    try{
      var payload=reviewDataCachePayload(snapshot),raw=JSON.stringify(payload);
      if(raw.length>4200000){payload.audit=null;payload.scopeCache=null;raw=JSON.stringify(payload);}
      if(raw.length>4200000){payload.signal=null;payload.country=null;raw=JSON.stringify(payload);}
      if(raw.length<=4200000)sessionStorage.setItem(REVIEW_DATA_CACHE_KEY,raw);
    }catch(_e){}
  }
  function readReviewDataCache(resumeScope){
    var row=null;try{row=parseJson(sessionStorage.getItem(REVIEW_DATA_CACHE_KEY)||'');}catch(_e){}
    if(!row||row.schema!=='igdc-country-control-review-data.v1'||Date.now()-Number(row.savedAt||0)>21600000)return null;
    if(row.path&&row.path!==(location.pathname+location.search))return null;
    if(!row.scope||!resumeScope||scopeKey(row.scope)!==scopeKey(resumeScope))return null;
    return row;
  }
  function saveReviewSnapshot(){
    try{
      var snapshot={schema:'igdc-country-control-ui-state.v8-review-data-cache',path:location.pathname+location.search,scope:scopeSnapshot('session-resume-cache'),savedAt:Date.now(),scrollY:Math.max(0,Math.round(window.scrollY||0)),openDetails:openDetailKeys(),candidateSelectedProducts:candidateSelectedProducts,frontSelectedSections:frontSelectedSections,frontSelectedProducts:frontSelectedProducts,productPlacementSelections:productPlacementSelections,queueFocusedCandidateIds:queueFocusedCandidateIds.slice(0,250),panels:{summary:!$('summaryPanel').classList.contains('hidden'),queue:!$('queuePanel').classList.contains('hidden'),ai:!$('aiPanel').classList.contains('hidden'),product:!$('productResearchPanel').classList.contains('hidden'),json:!$('jsonPanel').classList.contains('hidden')}};
      sessionStorage.setItem(REVIEW_SNAPSHOT_KEY,JSON.stringify(snapshot));
      try{sessionStorage.removeItem(REVIEW_SNAPSHOT_LEGACY_KEY);}catch(_legacyError){}
      saveReviewDataCache(snapshot);
      sessionMemoryWrite(snapshot);
      persistScope();
    }catch(_e){try{persistScope();}catch(_scopeError){}}
  }
  function hydrateReviewSnapshot(){
    var row=returnRestoreRow||reviewReturnValue(),snapshot=null,memory=sessionMemoryRead();
    try{snapshot=parseJson(sessionStorage.getItem(REVIEW_SNAPSHOT_KEY)||sessionStorage.getItem(REVIEW_SNAPSHOT_LEGACY_KEY)||'');}catch(_e){}
    if(!snapshot||Date.now()-Number(snapshot.savedAt||0)>21600000)return false;
    var resumeScope=row||snapshot.scope;
    if(!resumeScope||!snapshot.scope||scopeKey(snapshot.scope)!==scopeKey(resumeScope))return false;
    if(!row&&snapshot.path&&snapshot.path!==(location.pathname+location.search))return false;
    selectedCountry=text(resumeScope.country||snapshot.scope.country).toUpperCase();
    selectedSubdivision=text(resumeScope.region||snapshot.scope.region||'NATIONWIDE').toUpperCase()||'NATIONWIDE';
    selectedRegion=text(resumeScope.regionGroup||snapshot.scope.regionGroup);
    selectionSource='session-resume';
    var detected=snapshot.scope.detectedGeo||{};
    geo={country:detected.country||null,region:detected.region||null,worldRegion:detected.regionGroup||null,resolved:detected.resolved===true,excluded:detected.excluded===true,source:detected.source||'session-resume'};
    if(memory&&memory.scope&&scopeKey(memory.scope)===scopeKey(resumeScope)){
      lastScopeCache=memory.scopeCache||null;lastCountryPreview=memory.country||null;lastCountryJson=memory.country||null;lastProductJson=memory.product||null;lastSignalReport=memory.signal||null;activeScopeAudit=memory.auditKind||'';lastScopeAuditJson=memory.audit||null;
    }else{
      memory=null;
      var persisted=readReviewDataCache(resumeScope);
      if(persisted){
        lastScopeCache=persisted.scopeCache||null;lastCountryPreview=persisted.country||null;lastCountryJson=persisted.country||null;lastProductJson=persisted.product||null;lastSignalReport=persisted.signal||null;activeScopeAudit=persisted.auditKind||'';lastScopeAuditJson=persisted.audit||null;
        memory={persistent:true};
      }
    }
    candidateSelectedProducts=Object.assign({},snapshot.candidateSelectedProducts||{});frontSelectedSections=Object.assign({},snapshot.frontSelectedSections||{});frontSelectedProducts=Object.assign({},snapshot.frontSelectedProducts||{});productPlacementSelections=Object.assign({},snapshot.productPlacementSelections||{});queueFocusedCandidateIds=Array.isArray(snapshot.queueFocusedCandidateIds)?snapshot.queueFocusedCandidateIds.map(text).filter(Boolean).slice(0,250):[];sessionResumeActive=true;sessionUiResume=snapshot;sessionDataResumeAvailable=!!memory;lastPassiveRestoreAt=Date.now();
    return !!selectedCountry;
  }
  function applySessionDataResume(){
    if(!sessionDataResumeAvailable)return false;var hydrated=false,cache=lastScopeCache;
    if(cache&&cache.scopeData){renderAi(cache.scopeData.candidates||[]);renderActiveSignals(cache.scopeData.marketSignals||{});hydrated=true;}
    if(cache&&cache.summaryData){renderSummary(cache.summaryData.summary||cache.summaryData,cache.scopeData||{},'현재 브라우저 세션 복원');hydrated=true;}
    if(cache&&cache.queueData){renderQueue(cache.queueData.candidates||[]);hydrated=true;}
    if(lastCountryPreview){renderResearchProgress(lastCountryPreview);renderAi(lastCountryPreview.candidates||[],lastCountryPreview.holdingCandidates||[],lastCountryPreview.blockedCandidates||[]);setButtonEnabled('countryRunDownloadBtn',true);setButtonEnabled('runNowBtn',lastCountryPreview.status==='complete'||lastCountryPreview.status==='committed');hydrated=true;}
    if(lastProductJson){renderProductProgress(lastProductJson);renderProducts(lastProductJson.products||[]);setButtonEnabled('productResearchDownloadBtn',true);setButtonEnabled('productResearchBtn',true);hydrated=true;}
    if(lastSignalReport){renderSignalReport(lastSignalReport);hydrated=true;}
    if(activeScopeAudit&&lastScopeAuditJson){renderScopeAudit(lastScopeAuditJson,activeScopeAudit);hydrated=true;}
    return hydrated;
  }
  function applySessionUiResume(){
    var snapshot=sessionUiResume;if(!snapshot)return;
    var panels=snapshot.panels||{};
    if(panels.summary&&$('summaryPanel'))$('summaryPanel').classList.remove('hidden');
    if(panels.queue&&$('queuePanel'))$('queuePanel').classList.remove('hidden');
    if(panels.ai&&$('aiPanel'))$('aiPanel').classList.remove('hidden');
    if(panels.product&&$('productResearchPanel'))$('productResearchPanel').classList.remove('hidden');
    if(panels.json&&$('jsonPanel'))$('jsonPanel').classList.remove('hidden');
    var keys=Array.isArray(snapshot.openDetails)?snapshot.openDetails:[];
    keys.forEach(function(key){var el=document.getElementById(key);if(!el){Array.prototype.some.call(document.querySelectorAll('details'),function(row){if(row.getAttribute('data-product-group')===String(key)||row.getAttribute('data-heavy-panel')===String(key)){el=row;return true;}return false;});}if(el&&el.tagName==='DETAILS')el.open=true;});
    if(Number.isFinite(Number(snapshot.scrollY)))setTimeout(function(){window.scrollTo({top:Math.max(0,Number(snapshot.scrollY)||0),left:0,behavior:'auto'});},180);
  }
  function prepareReviewReturn(){var row=reviewReturnValue();if(!row)return null;returnRestoreActive=true;returnRestoreRow=row;if(row.country)selectedCountry=text(row.country).toUpperCase();if(row.region)selectedSubdivision=text(row.region).toUpperCase()||'NATIONWIDE';if(row.regionGroup)selectedRegion=text(row.regionGroup);if(row.source)selectionSource=row.source;return row;}
  function rememberReviewReturn(target){try{var anchor=target&&target.closest?target.closest('[data-review-anchor]'):null,group=target&&target.closest?target.closest('details[data-product-group]'):null,heavy=target&&target.closest?target.closest('[data-heavy-panel]'):null,rect=anchor&&anchor.getBoundingClientRect?anchor.getBoundingClientRect():null;saveReviewSnapshot();sessionStorage.setItem(REVIEW_RETURN_KEY,JSON.stringify({path:location.pathname+location.search,scrollY:Math.max(0,Math.round(window.scrollY||0)),anchor:anchor&&anchor.getAttribute('data-review-anchor')||'',anchorOffset:rect?Math.round(window.scrollY-(rect.top+window.scrollY)):0,productGroup:group&&group.getAttribute('data-product-group')||'',productGroupKind:group&&group.getAttribute('data-product-group-kind')||'',heavyPanel:heavy&&heavy.id||'',detailPath:reviewDetailPath(target),country:selectedCountry,region:selectedSubdivision||'NATIONWIDE',regionGroup:selectedRegion,source:selectionSource||'saved-scope',at:Date.now()}));}catch(_e){}}
  function navigateReviewLink(anchor,event){
    var url=safeExternalUrl(anchor&&anchor.href);if(!url)return;
    if(event&&(event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||event.button>0))return;
    event&&event.preventDefault();
    rememberReviewReturn(anchor);
    /* Keep a single browser-history hop. When this control runs inside the admin shell,
       navigate the top browsing context straight to the product. Do not first promote
       commerce-country-control.html into the top context; that duplicate intermediate
       page loses the live admin runtime and forces a second Back click. */
    try{var topWindow=window.top||window;if(topWindow!==window&&topWindow.location){topWindow.location.assign(url);return;}}catch(_e){}
    window.location.assign(url);
  }
  function openReviewReturnGroup(row){if(!row)return;var path=Array.isArray(row.detailPath)?row.detailPath:[];path.forEach(function(key){var detail=reviewDetailElement(key);if(detail&&!detail.open)detail.open=true;});var heavy=row.heavyPanel&&$(row.heavyPanel);if(heavy&&typeof heavy.open==='boolean'&&!heavy.open)heavy.open=true;if(row.productGroup){var root=row.productGroupKind==='candidate'?$('productGrid'):$('productSectionList');if(row.productGroupKind==='candidate'&&$('productCandidatePanel')&&!$('productCandidatePanel').open)$('productCandidatePanel').open=true;var group=null;if(root){Array.prototype.some.call(root.querySelectorAll('details[data-product-group]'),function(candidate){if(candidate.getAttribute('data-product-group')===String(row.productGroup)){group=candidate;return true;}return false;});}if(group&&!group.open)group.open=true;}}
  function restoreReviewReturn(){var row=returnRestoreRow||reviewReturnValue();if(!row)return;if(returnRestoreTimer)clearInterval(returnRestoreTimer);returnRestoreActive=true;returnRestoreRow=row;openReviewReturnGroup(row);var started=Date.now(),stable=0,lastTop=-1;returnRestoreTimer=setInterval(function(){openReviewReturnGroup(row);var target=reviewAnchorElement(row.anchor),y=Math.max(0,Number(row.scrollY||0));if(target){var rect=target.getBoundingClientRect(),top=Math.max(0,Math.round(rect.top+window.scrollY+Number(row.anchorOffset||0)));window.scrollTo({top:top,left:0,behavior:'auto'});y=top;}else if(document.documentElement.scrollHeight>=Math.min(y+200,document.documentElement.scrollHeight)){window.scrollTo({top:y,left:0,behavior:'auto'});}var nowTop=Math.round(window.scrollY||0);stable=nowTop===lastTop?stable+1:0;lastTop=nowTop;if((target&&stable>=2)||(Date.now()-started>12000)){clearInterval(returnRestoreTimer);returnRestoreTimer=null;returnRestoreActive=false;returnRestoreRow=null;try{sessionStorage.removeItem(REVIEW_RETURN_KEY);}catch(_e){}}},140);}
  function directVideoUrl(value){var url=safeExternalVideoUrl(value);return /\.(?:mp4|webm|ogv|ogg)(?:$|[?#])/i.test(url)?url:'';}
  function embeddableVideoUrl(value){var url=safeExternalVideoUrl(value);if(!url)return'';try{var u=new URL(url),host=u.hostname.toLowerCase();if(host==='youtu.be'){var id=u.pathname.replace(/^\/+/, '').split('/')[0];return id?'https://www.youtube-nocookie.com/embed/'+encodeURIComponent(id):'';}if(host.endsWith('youtube.com')||host.endsWith('youtube-nocookie.com')){var id2=u.searchParams.get('v');if(!id2&&/\/embed\//.test(u.pathname))id2=u.pathname.split('/embed/')[1].split('/')[0];return id2?'https://www.youtube-nocookie.com/embed/'+encodeURIComponent(id2):'';}if(host==='vimeo.com'||host.endsWith('.vimeo.com')){var m=u.pathname.match(/(?:video\/)?(\d{5,})/);return m?'https://player.vimeo.com/video/'+m[1]:'';}}catch(_e){}return'';}
  function renderProductProgress(data){
    data=data||{status:'not_started',summary:{},progress:{}};var summary=data.summary||{},progress=data.progress||{},discovery=progress.discovery||{},inspection=progress.inspection||{},privateQueue=progress.privateQueue||{},stageSummary=data.pipeline&&data.pipeline.stageSummary||{},pause=data.pause||null;
    var failed=Number(stageSummary.failed||0),staged=Number(summary.privateResearchQueueStaged||0),status=text(data.status||'not_started'),labels={not_started:'아직 상품 리서치를 시작하지 않았습니다.',discovering:'공식 업체 사이트에서 실제 상품 페이지를 찾는 중입니다. 발견된 상품은 검증 전 상태로 바로 표시합니다.',inspecting:'상품 페이지·이미지·가격·재고·영상·원본 링크를 확인하는 중입니다.',staging:'이전 버전의 자동 대기열 단계가 감지되었습니다. 새 정책에 따라 리서치 완료·수동 대기열 대기 상태로 전환합니다.',complete:'상품 리서치를 완료했습니다. 검증 완료 상품은 최신 상품 목록에서 확인한 뒤 현재 조사분 대기열 등록을 실행할 수 있습니다.',candidate_ledger:'저장된 상품 후보 원장을 기준으로 관리 목록을 불러왔습니다.',cancelled:'상품 리서치가 중단됐습니다.'};
    if(pause&&pause.paused===true){productPausedForQueue=true;productPauseServerConfirmed=true;}else if(pause&&pause.pauseRequested===false){productPausedForQueue=false;productPauseServerConfirmed=false;}if(status==='complete'||status==='cancelled'){productPausedForQueue=false;productPauseServerConfirmed=false;}
    var retryPending=Number(discovery.retryPending||summary.supplierRetryPending||0),deferredSuppliers=Number(discovery.temporarilyDeferred||summary.temporarilyDeferredSuppliers||0),inspectRetry=Number(inspection.retryPending||0);
    if($('productResearchState'))$('productResearchState').textContent=(data.needsRefresh===true?'이전 상품 추출 결과입니다. 카테고리 페이지를 제외하고 실제 상품 상세페이지·썸네일을 다시 조사해야 합니다. · ':'')+(labels[status]||status)+' · 기존 업체 조사 '+Number(summary.existingSuppliersChecked||0)+'/'+Number(summary.existingSupplierSources==null?(summary.previouslyResearchedSuppliers||0):summary.existingSupplierSources)+' · 신규 업체 조사 '+Number(summary.newSuppliersChecked||0)+'/'+Number(summary.newSupplierSources==null?Math.max(0,Number(discovery.total||0)-Number(summary.previouslyResearchedSuppliers||0)):summary.newSupplierSources)+' · 전체 진행 '+Number(discovery.done||0)+'/'+Number(discovery.total||0)+(retryPending?' · 느린 업체 재시도 '+retryPending+'건':'')+(deferredSuppliers?' · 다음 사이클 재확인 '+deferredSuppliers+'건':'')+' · 상품 점검 '+Number(inspection.done||0)+'/'+Number(inspection.total||0)+(inspectRetry?' · 느린 상품 재시도 '+inspectRetry+'건':'')+' · 대기열 등록 '+staged+'/'+Number(privateQueue.total||summary.privateResearchQueueEligible||0)+(failed?' · 등록 실패 '+failed:'');
    if($('latestProductSummary'))$('latestProductSummary').textContent=Number(summary.latestResearchProducts||latestProductRows.length)+'건';if($('latestProductPanel'))$('latestProductPanel').classList.remove('hidden');
    if(Array.isArray(data.latestProducts)){latestProductRows=data.latestProducts.slice();if($('latestProductPanel')&&$('latestProductPanel').open)renderLatestProductRows();else if($('latestProductGrid'))$('latestProductGrid').innerHTML='';syncLatestProductQueueControls();}
    if($('productResearchStats'))$('productResearchStats').innerHTML=stat('기존 업체 조사',summary.existingSupplierSources==null?(summary.previouslyResearchedSuppliers||0):summary.existingSupplierSources,Number(summary.existingSuppliersChecked||0)+'/'+Number(summary.existingSupplierSources==null?(summary.previouslyResearchedSuppliers||0):summary.existingSupplierSources)+' 재리서치')+stat('신규 업체 조사',summary.newSupplierSources==null?Math.max(0,Number(discovery.total||0)-Number(summary.previouslyResearchedSuppliers||0)):summary.newSupplierSources,Number(summary.newSuppliersChecked||0)+'/'+Number(summary.newSupplierSources==null?Math.max(0,Number(discovery.total||0)-Number(summary.previouslyResearchedSuppliers||0)):summary.newSupplierSources)+' 신규 리서치')+stat('업체 확인',Number(summary.suppliersChecked||0)+'/'+Number(summary.suppliers||0),'공식 사이트')+stat('최신 상품',summary.latestResearchProducts||latestProductRows.length,'이번 리서치 사이클')+stat('상품 발견',summary.discovered||0,'원본 페이지 후보')+stat('상품 점검',summary.inspected||0,'상세페이지 확인')+stat('이미지 확인',summary.withImage||0,'실제 상품 이미지')+stat('영상 확인',summary.withVideo||0,'직접 재생·원본 영상')+stat('관리자 검토 가능',summary.readyForAdminReview||0,'원본 링크 포함')+stat('대기열 적격',summary.privateResearchQueueEligible||0,'비공개 검토 대상')+stat('대기열 등록',staged,'자동 공개 없음')+stat('등록 실패',failed,failed?'저장 연결 확인 필요':'정상')+stat('대기열 심사 후보',summary.slotCandidates||0,'관리자 지정')+stat('정산 준비',summary.settlementReadyProducts||0,'추적·지급 조건 확인')+stat('온라인 제휴',summary.onlineAffiliateActive||0,'활성 프로그램')+stat('정식 파트너',summary.formalPartners||0,'계약·승인 확인');
    setButtonEnabled('productResearchDownloadBtn',status!=='not_started');
    if($('productResearchBtn')&&!productLoopActive){$('productResearchBtn').textContent=data.needsRefresh===true?'상품 썸네일 다시 조사':((status==='discovering'||status==='inspecting'||status==='staging')?'상품 조사 계속':'실상품 전체 재리서치');}
    syncProductQueueStageControls();syncProductAiFinalizeControl();
  }

  function assignedSectionKey(row){var key=productPlacementKey(row);return PRODUCT_SECTION_MAP[key]?key:'';}
  function productResearchComplete(){return !!(lastProductJson&&lastProductJson.status==='complete');}
  function hasFrontMatchablePlacement(){return productRows.some(function(row){return productDecision(row)==='slot_candidate'&&!!assignedSectionKey(row);});}
  function selectedSectionKeys(){return PRODUCT_SECTIONS.map(function(row){return row.key;}).filter(function(key){return frontSelectedSections[key]===true;});}
  function selectedProductIds(sectionKey){return productRows.filter(function(row){return frontSelectedProducts[text(row&&row.id)]===true&&(!sectionKey||assignedSectionKey(row)===sectionKey);}).map(function(row){return text(row.id);}).filter(Boolean);}
  function sectionRows(sectionKey){return productRows.filter(function(row){return productDecision(row)==='slot_candidate'&&assignedSectionKey(row)===sectionKey;});}
  function syncFrontSelectionControls(){
    var busy=productLoopActive||productAutomationActive||productFrontSyncActive,matchBusy=busy,sections=selectedSectionKeys(),placed=productRows.filter(function(row){return productDecision(row)==='slot_candidate'&&!!assignedSectionKey(row);}),active=placed.filter(frontPublicationActive),refreshable=placed;
    if($('selectedSectionCount'))$('selectedSectionCount').textContent='선택 섹션 '+sections.length+'개';
    var master=$('allSectionsSelect');if(master){master.checked=sections.length===PRODUCT_SECTIONS.length;master.indeterminate=sections.length>0&&sections.length<PRODUCT_SECTIONS.length;master.disabled=busy;}
    setButtonEnabled('selectedSectionsMatchBtn',!matchBusy&&sections.length>0);setButtonEnabled('allSectionsMatchBtn',!matchBusy);setButtonEnabled('selectedSectionsUnmatchBtn',!busy&&sections.some(function(key){return sectionRows(key).some(frontPublicationActive);}));setButtonEnabled('allSectionsUnmatchBtn',!busy&&active.length>0);
    Array.prototype.forEach.call(document.querySelectorAll('[data-section-front-select]'),function(box){box.checked=frontSelectedSections[box.value]===true;box.disabled=busy;});
    Array.prototype.forEach.call(document.querySelectorAll('[data-product-front-select]'),function(box){box.checked=frontSelectedProducts[box.value]===true;box.disabled=busy;});
    PRODUCT_SECTIONS.forEach(function(section){var ids=selectedProductIds(section.key),rows=sectionRows(section.key),all=$('sectionProductSelectAll-'+section.key.replace(/[^a-z0-9_-]/gi,'_')),count=$('sectionProductSelectedCount-'+section.key.replace(/[^a-z0-9_-]/gi,'_'));if(all){all.checked=rows.length>0&&ids.length===rows.length;all.indeterminate=ids.length>0&&ids.length<rows.length;all.disabled=busy||!rows.length;}if(count)count.textContent='선택 상품 '+ids.length+'건';Array.prototype.forEach.call(document.querySelectorAll('[data-selected-products-front="'+section.key+'"]'),function(button){var unmatch=button.getAttribute('data-front-operation')==='unmatch';button.disabled=(unmatch?busy:matchBusy)||!ids.length||(unmatch&&!rows.some(function(row){return ids.indexOf(text(row.id))>=0&&frontPublicationActive(row);}));});});
  }

  function productCardHtml(row,index,mode,groupKey){
    var productUrl=safeExternalUrl(row.productUrl||row.url),imageUrl=safeExternalImageUrl(row.imageUrl||row.imageOriginalUrl),supplierUrl=safeExternalUrl(row.supplierSiteUrl),videoUrl=safeExternalVideoUrl(row.videoUrl||row.videoContentUrl||row.videoEmbedUrl),title=text(row.productName||row.title||'상품명 확인 필요'),decision=productDecision(row),researchStatus=text(row.researchStatus).toLowerCase(),risk=row.riskAssessment||{},ready=researchStatus==='ready_for_admin_review',actionable=row.inspectionComplete===true||ready||researchStatus==='needs_manual_review'||row.privatePlacementReviewEligible===true,hardInvalid=['http_404','non_html','blocked','unavailable'].indexOf(researchStatus)>=0||row.productPageLive===false||risk.explicitUnavailable===true||risk.specificProductUrl===false,slotAllowed=(!!row.id&&!!productUrl&&!hardInvalid)||decision==='slot_candidate',price=text(row.price||''),currency=text(row.priceCurrency||''),priceDisplay=price?(currency==='KRW'?price.replace(/\s*KRW\s*/ig,'').replace(/원\s*$/,'')+'원':price+(currency?' '+currency:'')):'판매처에서 현재 가격 확인';
    var image=imageUrl?'<a href="'+esc(productUrl||imageUrl)+'" target="_top" data-review-link="1" rel="noreferrer external nofollow" referrerpolicy="no-referrer"><img data-product-image="1" src="'+esc(imageUrl)+'" alt="'+esc(title)+'" loading="lazy" decoding="async" fetchpriority="low"></a><div class="product-image-missing hidden">상품 이미지 원본을 불러오지 못했습니다.</div>':'<div class="product-image-missing">상품 이미지 확인 필요</div>';
    var links=[];if(productUrl)links.push(externalReviewAnchor(productUrl,'상품 원본·판매처 열기',''));if(supplierUrl)links.push(externalReviewAnchor(supplierUrl,'업체 사이트 확인',''));var placementHtml='',actions='';
    if(mode==='candidate'||mode==='section'){
      placementHtml=productManagementOptions(row,mode,groupKey,slotAllowed);
      if(row.id&&slotAllowed)actions='<span class="product-verification-note">18개 섹션을 관리자가 직접 지정할 수 있습니다. 검증 중 상품은 비공개 경고 상태로 저장되고 최종 공개 안전 게이트는 그대로 유지됩니다.</span>';else if(row.id&&actionable)actions='<span class="product-verification-note">상품 원본 주소가 확인되면 섹션을 지정할 수 있습니다. 보류·제외·AI 재분류는 지금 처리할 수 있습니다.</span>';else actions='<span class="product-verification-note">상세페이지 검증 중입니다. 원본은 먼저 확인할 수 있습니다.</span>';
      if(mode==='section')placementHtml='<div class="product-status-note">현재 배치 예정: <strong>'+esc(sectionLabel(groupKey))+'</strong><br><span class="small">비공개 배치 예정 · 관리자 지정은 AI보다 우선</span></div>'+placementHtml;
    }
    var priority=text(row.priorityLabel||''),decisionLabel={slot_candidate:'섹션 배치 예정',hold:'보류',reject:'제외',purge:'영구 제외',undecided:'미결정'}[decision]||decision,settlementHtml=affiliateSettlementSummary(row),singleFront='';
    if(mode==='section'&&row.id&&decision==='slot_candidate')singleFront='<button type="button" class="product-section-unmatch-button" data-product-section-release="'+esc(row.id)+'">이 상품 섹션 해제</button><span class="small">이 버튼은 현재 섹션 배치만 해제하며 GitHub/Netlify 프론트 빌드를 실행하지 않습니다.</span>';
    var frontSelect=mode==='section'&&row.id?'<div class="product-card-front-select"><label class="product-front-select-label"><input type="checkbox" data-product-front-select="1" data-product-front-section="'+esc(groupKey)+'" value="'+esc(row.id)+'" '+(frontSelectedProducts[text(row.id)]===true?'checked ':'')+'> 이 상품 선택</label></div>':'',candidateSelect=mode==='candidate'&&row.id?'<div class="product-card-front-select"><label class="product-front-select-label"><input type="checkbox" data-candidate-select="'+esc(groupKey)+'" value="'+esc(row.id)+'" '+(candidateSelectedProducts[text(row.id)]===true?'checked ':'')+'> 이 후보 선택</label></div>':'',latestKey=latestProductKey(row),latestSelect=mode==='latest'&&latestKey?'<div class="product-card-front-select"><label class="product-front-select-label"><input type="checkbox" data-latest-queue-select="1" value="'+esc(latestKey)+'" '+(latestSelectedProducts[latestKey]===true?'checked ':'')+'> 이 상품 선택</label></div>':'';
    return'<article class="product-card" data-review-anchor="product-'+esc(row.id||productUrl||title)+'">'+candidateSelect+frontSelect+latestSelect+'<div class="product-image-frame">'+image+'</div><div class="product-body"><strong class="product-title">'+(productUrl?externalReviewAnchor(productUrl,title,'product-title-link'):esc(title))+'</strong><div class="product-price"><strong>'+esc(priceDisplay)+'</strong></div><div class="small">판매·결제·배송 책임 업체: '+esc(row.supplierName||'-')+'</div><div class="small"><span class="pill '+(ready?'good':'warn')+'">'+esc(row.researchStatus||'미확인')+'</span> <span class="pill info">'+esc(decisionLabel)+'</span>'+(priority?' <span class="pill good">'+esc(priority)+'</span>':'')+'</div>'+settlementHtml+frontPublicationSummary(row)+placementHtml+'<div class="product-links">'+(links.join('')||'<span class="small">확인 가능한 외부 링크가 없습니다.</span>')+'</div><div class="small mono">'+esc(productUrl||'상품 원본 주소 확인 필요')+'</div><div class="product-actions">'+actions+singleFront+'</div></div></article>';
  }
  function productGroupDetails(key,label,rows,kind){
    var count=rows.length,validSection=!!PRODUCT_SECTION_MAP[key],capacity=kind==='section'?'<span class="product-section-capacity '+(count>=100?'warn':'')+'">'+count+'/100</span>':'<span class="small">'+count+'건</span>';
    var controlsBusy=productLoopActive||productAutomationActive||productFrontSyncActive,matchBusy=controlsBusy,autoDisabled=controlsBusy||!productRows.length,autoButton='';
    if(kind==='section'&&validSection)autoButton='<button type="button" class="product-section-ai-button" data-section-ai-auto="'+esc(key)+'" '+(autoDisabled?'disabled':'')+'>이 섹션 AI 자동 배치</button>';
    else if(kind==='candidate'&&validSection)autoButton='<button type="button" class="product-section-ai-button" data-section-ai-auto="'+esc(key)+'" '+(autoDisabled?'disabled':'')+'>이 후보군 AI 자동 배치</button>';
    else if(kind==='candidate'&&key==='assignment_repair')autoButton='<button type="button" class="product-section-ai-button" data-candidate-repair-auto="1" '+(autoDisabled||!count?'disabled':'')+'>배정정보 복구 필요 전체 AI 복구</button>';
    else if(kind==='candidate'&&key==='unassigned')autoButton='<button type="button" class="product-section-ai-button" data-section-ai-auto="__all__" '+(autoDisabled||!count?'disabled':'')+'>미배정 AI 자동 배치</button>';
    var sectionSelect=kind==='section'&&validSection?'<label class="section-select-label"><input type="checkbox" data-section-front-select="1" value="'+esc(key)+'" '+(frontSelectedSections[key]===true?'checked ':'')+(controlsBusy||!count?'disabled ':'')+'> 섹션 선택</label>':'';
    var frontButtons=kind==='section'&&validSection?'<button type="button" class="product-section-front-button" data-section-front-match="'+esc(key)+'" '+(matchBusy?'disabled':'')+'>이 섹션 프론트 매칭</button><button type="button" class="product-section-unmatch-button" data-section-front-unmatch="'+esc(key)+'" '+(controlsBusy||!rows.some(frontPublicationActive)?'disabled':'')+'>이 섹션 매칭 해제</button>':'';
    var workspaceKey=kind==='section'&&validSection?'section_'+key.replace(/[^a-z0-9_-]/gi,'_'):(kind==='candidate'?'candidate_group_'+key.replace(/[^a-z0-9_-]/gi,'_'):'');
    var policyButton=workspaceKey?'<button type="button" class="ghost policy-workspace-button" data-policy-workspace="'+esc(workspaceKey)+'" data-policy-workspace-label="'+esc(label)+(kind==='candidate'?' 후보 관리 대화':' 섹션 운영 대화')+'" data-policy-scope="country">AI 운영·정책 대화</button>':'';
    var safeKey=key.replace(/[^a-z0-9_-]/gi,'_');
    var candidateToolbar=kind==='candidate'?'<div class="section-product-toolbar candidate-bulk-toolbar"><label class="product-front-select-label"><input id="candidateSelectAll-'+esc(safeKey)+'" type="checkbox" data-candidate-select-all="'+esc(key)+'"> 이 후보군 전체 선택</label><span id="candidateSelectedCount-'+esc(safeKey)+'" class="pill info">선택 후보 0건</span><button type="button" class="product-section-ai-button" data-candidate-bulk="ai" data-candidate-group="'+esc(key)+'" disabled>선택 후보 AI로 18개 섹션 자동 배치</button><select class="product-management-select candidate-target-select" data-candidate-target="'+esc(key)+'"><option value="">수동 배치 섹션 선택</option>'+PRODUCT_SECTIONS.map(function(section){return'<option value="'+esc(section.key)+'">'+esc(section.label)+'</option>';}).join('')+'</select><button type="button" class="product-section-front-button" data-candidate-bulk="place" data-candidate-group="'+esc(key)+'" disabled>선택 후보를 18개 섹션 배치 예정으로 이동</button><button type="button" class="secondary" data-candidate-bulk="undecided" data-candidate-group="'+esc(key)+'" disabled>선택 후보 미배정 복원</button><button type="button" class="secondary" data-candidate-bulk="hold" data-candidate-group="'+esc(key)+'" disabled>선택 후보 보류</button><button type="button" class="danger" data-candidate-bulk="reject" data-candidate-group="'+esc(key)+'" disabled>선택 후보 제외</button><button type="button" class="danger" data-candidate-bulk="purge" data-candidate-group="'+esc(key)+'" disabled>선택 후보 영구 제외</button><button type="button" class="secondary" data-candidate-bulk="list_delete" data-candidate-group="'+esc(key)+'" disabled>선택 후보 목록에서만 제거</button></div>':'';
    var productToolbar=kind==='section'&&validSection?'<div class="section-product-toolbar"><label class="product-front-select-label"><input id="sectionProductSelectAll-'+esc(safeKey)+'" type="checkbox" data-section-products-select-all="'+esc(key)+'"> 이 섹션 상품 전체 선택</label><span id="sectionProductSelectedCount-'+esc(safeKey)+'" class="pill info">선택 상품 0건</span><button type="button" class="product-section-front-button" data-selected-products-front="'+esc(key)+'" data-front-operation="match" disabled>선택 상품 매칭</button><button type="button" class="product-section-unmatch-button" data-selected-products-front="'+esc(key)+'" data-front-operation="unmatch" disabled>선택 상품 매칭 해제</button><button type="button" class="product-section-front-button" data-section-front-match="'+esc(key)+'" '+(matchBusy?'disabled':'')+'>이 섹션 전체 상품 매칭</button><button type="button" class="product-section-unmatch-button" data-section-front-unmatch="'+esc(key)+'" '+(controlsBusy||!rows.some(frontPublicationActive)?'disabled':'')+'>이 섹션 전체 상품 매칭 해제</button></div>':'';
    return'<details class="product-group" data-product-group="'+esc(key)+'" data-product-group-kind="'+esc(kind)+'"><summary><span>'+sectionSelect+' <strong>'+esc(label)+'</strong> '+capacity+'</span><span class="product-group-summary-actions">'+policyButton+autoButton+frontButtons+'<span class="pill info" data-group-toggle-label>목록 펼치기</span></span></summary><div class="product-group-body">'+candidateToolbar+productToolbar+'<div class="product-group-grid"></div><div class="product-group-pager"></div></div></details>';
  }
  // Candidate management must keep two views distinct:
  // - an AI/manual placement leaves its former raw/unassigned pool;
  // - the same candidate must remain visible under the assigned Front/section
  //   group so the administrator can reclassify, hold, reject or restore it.
  // Hiding assigned slot candidates here makes them impossible to remove later.
  function candidatePoolRow(row){var decision=productDecision(row);return decision==='undecided'||decision==='slot_candidate';}
  function candidateGroupKey(row){var decision=productDecision(row);return decision==='slot_candidate'?(assignedSectionKey(row)||'assignment_repair'):candidatePlacementKey(row);}
  function candidateGroupRows(groupKey){
    var rows=productRows.filter(candidatePoolRow);
    if(groupKey==='queue_selected'){
      var focused={};queueFocusedCandidateIds.forEach(function(id){focused[text(id)]=true;});
      return rows.filter(function(row){var candidateId=text(row&&row.candidateId),id=text(row&&row.id);return focused[candidateId]===true||focused[id]===true;});
    }
    return rows.filter(function(row){return candidateGroupKey(row)===groupKey;});
  }
  function selectedCandidateIds(groupKey){var valid={};candidateGroupRows(groupKey).forEach(function(row){valid[text(row.id)]=true;});return Object.keys(candidateSelectedProducts).filter(function(id){return candidateSelectedProducts[id]===true&&valid[id];});}
  function syncCandidateSelectionControls(groupKey){var rows=candidateGroupRows(groupKey),ids=selectedCandidateIds(groupKey),safeKey=groupKey.replace(/[^a-z0-9_-]/gi,'_'),all=$('candidateSelectAll-'+safeKey),count=$('candidateSelectedCount-'+safeKey),busy=productAutomationActive||productFrontSyncActive,selectedMap={};ids.forEach(function(id){selectedMap[id]=true;});if(all){all.checked=rows.length>0&&ids.length===rows.length;all.indeterminate=ids.length>0&&ids.length<rows.length;all.disabled=busy||!rows.length;}Array.prototype.forEach.call(document.querySelectorAll('[data-candidate-select]'),function(box){if(box.getAttribute('data-candidate-select')===groupKey)box.checked=selectedMap[text(box.value)]===true;});if(count)count.textContent='선택 후보 '+ids.length+'건';Array.prototype.forEach.call(document.querySelectorAll('[data-candidate-group="'+groupKey+'"]'),function(button){button.disabled=busy||!ids.length;});}
  async function runCandidateBulkAction(groupKey,action){
    var ids=selectedCandidateIds(groupKey);if(!ids.length){show('먼저 처리할 후보를 선택해 주세요.','warn');return;}
    var placement='',select=document.querySelector('[data-candidate-target="'+groupKey+'"]');
    if(action==='place'){placement=text(select&&select.value);if(!PRODUCT_SECTION_MAP[placement]){show('수동 배치할 18개 섹션을 선택해 주세요.','warn');return;}}
    if((action==='hold'||action==='reject'||action==='purge'||action==='list_delete')&&!window.confirm('선택한 후보 '+ids.length+'건을 '+(action==='hold'?'보류':action==='purge'?'영구 제외':action==='list_delete'?'현재 후보 관리 목록에서만 제거':'제외')+' 처리합니다. 프론트 공개·빌드는 실행하지 않습니다. 계속할까요?'))return;
    if(action==='ai'){await runProductAiAutomation('products','',ids);var stillVisible={};candidateGroupRows(groupKey).forEach(function(row){stillVisible[text(row.id)]=true;});ids.forEach(function(id){if(!stillVisible[id])delete candidateSelectedProducts[id];});saveReviewSnapshot();syncCandidateSelectionControls(groupKey);return;}
    var selectedRows=candidateGroupRows(groupKey).filter(function(row){return ids.indexOf(text(row&&row.id))>=0;}),ledgerRows=selectedRows.filter(function(row){return row&&row.ledgerSource==='candidate';});
    var succeeded=0,failed=0;
    try{
      if(ledgerRows.length===selectedRows.length&&ledgerRows.length){
        var candidateIds=Array.from(new Set(ledgerRows.map(function(row){return text(row.candidateId||row.id);}).filter(Boolean))),decision=action==='place'?'slot_candidate':action==='list_delete'?'remove_from_list':action;
        var bulk=await api(CONTROL,'product_candidate_ledger_bulk_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateIds:candidateIds,decision:decision,placementKey:placement||''},30000);
        succeeded=Number(bulk&&bulk.processed||0);failed=Number(bulk&&bulk.failed||0);
        await refreshCandidateLedgerProducts({preserveResearchReport:true});
      }else{
        var lastBulkData=null;
        for(var i=0;i<ids.length;i++){
          try{var itemDecision=action==='place'?'slot_candidate':action==='list_delete'?'remove_from_list':action;var itemData=await api(CONTROL,'product_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',productId:ids[i],decision:itemDecision,placementKey:placement||''},30000);lastBulkData=itemData;succeeded+=1;}catch(itemError){failed+=1;}
        }
        if(lastBulkData){lastProductJson=lastBulkData;rememberReport('product',lastBulkData);renderProductProgress(lastBulkData);renderProducts(lastBulkData.products||[]);saveReviewSnapshot();}
      }
    }catch(error){failed=Math.max(failed,ids.length-succeeded);show(conciseRequestError(error&&error.message,error&&error.status)||'선택 후보 일괄 처리를 완료하지 못했습니다.','fail');}
    ids.forEach(function(id){delete candidateSelectedProducts[id];});saveReviewSnapshot();syncCandidateSelectionControls(groupKey);
    var actionLabel=action==='place'?sectionLabel(placement)+' 섹션으로 수동 배치':action==='undecided'?'미배정 후보로 복원':action==='hold'?'보류':action==='purge'?'영구 제외':action==='list_delete'?'현재 후보 관리 목록에서만 제거':action==='reject'?'제외':action;
    var resultText='요청 '+ids.length+'건 · 성공 '+succeeded+'건 · 실패 '+failed+'건';if(succeeded)show(resultText+' · '+actionLabel+'했습니다. 프론트 공개·GitHub/Netlify 빌드·결제는 실행하지 않았습니다.',failed?'warn':'ok');else show(resultText+' · 처리된 항목이 없습니다. 후보 상태·ID 또는 저장 권한을 확인해 주세요.','fail');
  }
  function renderProductCandidateGroups(){var root=$('productGrid');if(!root)return;var rows=productRows.filter(candidatePoolRow),groups={};rows.forEach(function(row){var key=candidateGroupKey(row);(groups[key]||(groups[key]=[])).push(row);});var keys=[];if(queueFocusedCandidateIds.length){var focused=rows.filter(function(row){var candidate=text(row&&row.candidateId),id=text(row&&row.id);return queueFocusedCandidateIds.indexOf(candidate)>=0||queueFocusedCandidateIds.indexOf(id)>=0;});if(focused.length){groups.queue_selected=focused;keys.push('queue_selected');}}if(groups.assignment_repair&&groups.assignment_repair.length)keys.push('assignment_repair');PRODUCT_SECTIONS.forEach(function(section){if(groups[section.key]&&groups[section.key].length)keys.push(section.key);});if(groups.unassigned&&groups.unassigned.length)keys.push('unassigned');var labels={queue_selected:'대기열에서 선택한 상품 · 아래 버튼으로 AI 자동배치/수동배치/제외 처리',assignment_repair:'배정정보 복구 필요',unassigned:'미배정·추가 확인 필요'};root.innerHTML=keys.length?keys.map(function(key){return productGroupDetails(key,labels[key]||sectionLabel(key),groups[key],'candidate');}).join(''):'<div class="small">현재 관리할 상품 후보가 없습니다.</div>';wireProductGroupDetails(root,groups,'candidate');keys.forEach(syncCandidateSelectionControls);}
  function renderProductSectionBoard(){var root=$('productSectionList');if(!root)return;var groups={};PRODUCT_SECTIONS.forEach(function(section){groups[section.key]=[];});productRows.filter(function(row){return productDecision(row)==='slot_candidate';}).forEach(function(row){var key=productPlacementKey(row);if(groups[key])groups[key].push(row);});root.innerHTML=PRODUCT_SECTIONS.map(function(section){return productGroupDetails(section.key,section.label,groups[section.key]||[],'section');}).join('');wireProductGroupDetails(root,groups,'section');}
  function wireProductGroupDetails(root,groups,kind){
    Array.prototype.forEach.call(root.querySelectorAll('details[data-product-group]'),function(panel){
      function draw(){
        var key=panel.getAttribute('data-product-group'),grid=panel.querySelector('.product-group-grid'),pager=panel.querySelector('.product-group-pager'),allRows=groups[key]||[],stateKey=kind+':'+key,page=clampPage(candidateGroupPages[stateKey]||0,allRows.length,MANAGEMENT_PAGE_SIZE),start=page*MANAGEMENT_PAGE_SIZE,rows=allRows.slice(start,start+MANAGEMENT_PAGE_SIZE);
        candidateGroupPages[stateKey]=page;
        renderInBatches(grid,rows,function(row,index){return productCardHtml(row,start+index,kind,key);},MANAGEMENT_PAGE_SIZE);
        if(pager){pager.innerHTML=pagerMarkup('product_group',stateKey,page,allRows.length,MANAGEMENT_PAGE_SIZE);var previous=pager.querySelector('[data-page-delta="-1"]'),next=pager.querySelector('[data-page-delta="1"]');function move(delta){candidateGroupPages[stateKey]=clampPage(page+delta,allRows.length,MANAGEMENT_PAGE_SIZE);draw();if(grid)grid.scrollIntoView({behavior:'smooth',block:'nearest'});}if(previous)previous.addEventListener('click',function(event){event.preventDefault();event.stopPropagation();move(-1);});if(next)next.addEventListener('click',function(event){event.preventDefault();event.stopPropagation();move(1);});}
        if(kind==='candidate')syncCandidateSelectionControls(key);else syncFrontSelectionControls();
      }
      panel.addEventListener('toggle',function(){
        var label=panel.querySelector('[data-group-toggle-label]');syncDetailsToggle(panel,label);
        if(panel.open){closeOtherHeavyPanels(kind==='candidate'?$('productCandidatePanel'):null,panel);Array.prototype.forEach.call(document.querySelectorAll('details[data-product-group][open]'),function(other){if(other!==panel){other.open=false;var otherGrid=other.querySelector('.product-group-grid');if(otherGrid)otherGrid.innerHTML='';var otherPager=other.querySelector('.product-group-pager');if(otherPager)otherPager.innerHTML='';}});draw();}
        else{productRenderEpoch+=1;var grid=panel.querySelector('.product-group-grid');if(grid)grid.innerHTML='';var pager=panel.querySelector('.product-group-pager');if(pager)pager.innerHTML='';}
      });
    });
  }
  function productExcludedRows(kind){return productRows.filter(function(row){var decision=productDecision(row);return kind==='hold'?decision==='hold':decision==='reject'||decision==='purge';});}
  function renderProductExcludedTable(kind){
    var allRows=productExcludedRows(kind),body=$(kind==='hold'?'productHoldRows':'productRejectRows');if(!body)return;var stateKey='excluded:'+kind,page=clampPage(candidateGroupPages[stateKey]||0,allRows.length,MANAGEMENT_PAGE_SIZE),start=page*MANAGEMENT_PAGE_SIZE,rows=allRows.slice(start,start+MANAGEMENT_PAGE_SIZE);candidateGroupPages[stateKey]=page;
    body.innerHTML=(rows.length?rows.map(function(row,index){var url=safeExternalUrl(row.productUrl||row.url),title=text(row.productName||row.title||row.id),decision=productDecision(row),status=decision==='purge'?'영구 제외':(decision==='reject'?'제외':'보류');return'<tr data-review-anchor="product-excluded-'+esc(kind)+'-'+esc(reviewAnchorToken(row.id||url||title,start+index))+'"><td class="queue-number">'+(start+index+1)+'</td><td class="supplier-select-cell"><input type="checkbox" data-product-exclusion-select="'+esc(kind)+'" value="'+esc(row.id)+'" aria-label="'+esc(title)+' 선택"></td><td>'+(url?externalReviewAnchor(url,title,'queue-primary-link'):'<strong>'+esc(title)+'</strong>')+(url?'<br>'+externalReviewAnchor(url,'상품 원본 열기','queue-review-link'):'')+'</td><td>'+esc(row.supplierName||'-')+'</td><td><span class="product-exclusion-status '+(decision==='purge'?'permanent':'')+'">'+esc(status)+'</span><br><span class="small">'+esc(row.decisionAt||'-')+'</span></td></tr>';}).join(''):'<tr><td colspan="5" class="small">현재 '+(kind==='hold'?'보류':'제외')+' 상품이 없습니다.</td></tr>')+'<tr><td colspan="5">'+pagerMarkup('excluded',kind,page,allRows.length,MANAGEMENT_PAGE_SIZE)+'</td></tr>';syncProductExclusionSelection(kind);
  }
  function renderExcludedLedger(){var supplier=$('supplierControlQueue'),hold=$('productHoldQueue'),reject=$('productRejectQueue');if(supplier&&supplier.open)renderSupplierExcludedRows();else{if($('supplierHoldRows'))$('supplierHoldRows').innerHTML='';if($('supplierBlockedRows'))$('supplierBlockedRows').innerHTML='';}if(hold&&hold.open)renderProductExcludedTable('hold');else if($('productHoldRows'))$('productHoldRows').innerHTML='';if(reject&&reject.open)renderProductExcludedTable('reject');else if($('productRejectRows'))$('productRejectRows').innerHTML='';syncExcludedLedgerCounts();}
  function syncExcludedLedgerCounts(){var holdProducts=productExcludedRows('hold').length,rejectProducts=productExcludedRows('reject').length,total=supplierHoldingRows.length+supplierBlockedRows.length+holdProducts+rejectProducts,panel=$('excludedLedgerPanel');if(panel)panel.classList.remove('hidden');if($('excludedLedgerSummary'))$('excludedLedgerSummary').textContent=total+'건';if($('productHoldToggleLabel'))$('productHoldToggleLabel').textContent='보류 상품 목록 · '+holdProducts+'건';if($('productRejectToggleLabel'))$('productRejectToggleLabel').textContent='제외 상품 목록 · '+rejectProducts+'건';}
  function syncProductExclusionSelection(kind){var boxes=Array.prototype.slice.call(document.querySelectorAll('[data-product-exclusion-select="'+kind+'"]')),selected=boxes.filter(function(box){return box.checked;}),all=$(kind==='hold'?'productHoldSelectAll':'productRejectSelectAll'),count=$(kind==='hold'?'productHoldSelectedCount':'productRejectSelectedCount');if(all){all.checked=boxes.length>0&&selected.length===boxes.length;all.indeterminate=selected.length>0&&selected.length<boxes.length;all.disabled=boxes.length===0;}if(count)count.textContent='선택 '+selected.length+'건';Array.prototype.forEach.call(document.querySelectorAll('[data-product-exclusion-scope="'+kind+'"]'),function(button){button.disabled=selected.length===0;});}
  function affiliateSettlementNotice(message,kind){var el=$('affiliateSettlementNotice');if(!el)return;el.className='notice '+(kind==='ok'?'ok':kind==='fail'?'fail':'warn');el.textContent=message;el.classList.remove('hidden');}
  function closeAffiliateSettlementModal(){affiliateSettlementProductId='';var modal=$('affiliateSettlementModal');if(modal)modal.classList.add('hidden');var notice=$('affiliateSettlementNotice');if(notice){notice.classList.add('hidden');notice.textContent='';}}
  function openAffiliateSettlementModal(productId,requestedStage){var row=productById(productId);if(!row)return;affiliateSettlementProductId=productId;var settlement=row.affiliateSettlement||{},stage=requestedStage||affiliateStage(row),modal=$('affiliateSettlementModal');$('affiliateSettlementProduct').textContent=text(row.productName||row.title||productId)+' · '+text(row.supplierName||'판매처 확인 필요');$('affiliateSettlementStage').value=stage;$('affiliateSettlementCounterparty').value=text(settlement.counterparty||settlement.providerName||row.supplierName);$('affiliateSettlementTrackingUrl').value=text(settlement.trackingUrl||settlement.destinationUrl||row.affiliateOutboundUrl);$('affiliateSettlementProgramId').value=text(settlement.contractId||settlement.programId);$('affiliateSettlementMode').value=text(settlement.settlementMode);$('affiliateSettlementCommission').value=settlement.commissionRate!=null?String(Math.round(Number(settlement.commissionRate)*10000)/100):'';$('affiliateSettlementPayout').value=settlement.payoutPerTransaction!=null?String(settlement.payoutPerTransaction):'';$('affiliateSettlementCurrency').value=text(settlement.currency);$('affiliateSettlementSchedule').value=text(settlement.payoutSchedule);$('affiliateSettlementPayoutVerified').checked=settlement.payoutBasisVerified===true;$('affiliateSettlementTrackingVerified').checked=settlement.trackingVerified===true;$('affiliateSettlementDestinationVerified').checked=settlement.officialDestination===true;$('affiliateSettlementContractVerified').checked=settlement.contractVerified===true;if(modal)modal.classList.remove('hidden');}
  async function saveAffiliateSettlement(){var id=affiliateSettlementProductId,row=productById(id);if(!id||!row)return;var stage=text($('affiliateSettlementStage').value),trackingUrl=safeExternalUrl($('affiliateSettlementTrackingUrl').value),counterparty=text($('affiliateSettlementCounterparty').value),programId=text($('affiliateSettlementProgramId').value),settlementMode=text($('affiliateSettlementMode').value),commissionText=text($('affiliateSettlementCommission').value),payoutText=text($('affiliateSettlementPayout').value),payload={stage:stage,counterparty:counterparty,trackingUrl:trackingUrl||null,programId:programId||null,contractId:stage==='formal_partner'?programId||null:null,settlementMode:settlementMode||null,commissionRate:commissionText!==''?Number(commissionText)/100:null,payoutPerTransaction:payoutText!==''?Number(payoutText):null,currency:text($('affiliateSettlementCurrency').value).toUpperCase()||null,payoutSchedule:text($('affiliateSettlementSchedule').value)||null,payoutBasisVerified:$('affiliateSettlementPayoutVerified').checked,trackingVerified:$('affiliateSettlementTrackingVerified').checked,officialDestination:$('affiliateSettlementDestinationVerified').checked,contractVerified:$('affiliateSettlementContractVerified').checked};var button=$('affiliateSettlementSaveBtn');if(button)button.disabled=true;try{if(row&&row.ledgerSource==='candidate'){await api(CONTROL,'product_candidate_ledger_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateId:text(row.candidateId||row.id),decision:'affiliate_settlement',affiliateSettlement:payload});await refreshCandidateLedgerProducts();}else{var data=await api(CONTROL,'product_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',productId:id,decision:'affiliate_settlement',affiliateSettlement:payload});lastProductJson=data;rememberReport('product',data);renderProductProgress(data);renderProducts(data.products||[]);saveReviewSnapshot();}closeAffiliateSettlementModal();show('상품의 '+affiliateStageLabel(stage)+' 상태와 수익 귀속·정산 조건을 저장했습니다. 실제 지급 실행이나 결제는 수행하지 않았습니다.','ok');}catch(e){affiliateSettlementNotice(text(e&&e.message)||'제휴·정산 상태를 저장하지 못했습니다.','fail');}finally{if(button)button.disabled=false;}}
  async function deferFrontUnmatchBeforeManagementChange(row){
    var candidateId=text(row&&row.candidateId||row&&row.id);
    if(!candidateId||!frontPublicationActive(row))return{ok:true,skipped:true};
    return await api(CONTROL,'product_front_unmatch','POST',{}, {
      countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:'candidate',candidateId:candidateId,
      ledgerMode:'candidate',confirmation:'SITE_UNPUBLISH',deferRelease:true,scopeRefresh:false,compactResponse:true
    },45000);
  }
  async function applyProductDecision(productId,decision,placementKey,skipConfirm){var row=productById(productId),title=text(row&&row.productName||row&&row.title||productId);if(decision==='purge'&&row&&frontPublicationActive(row)&&!skipConfirm){if(!window.confirm('현재 프론트 매칭을 먼저 해제한 뒤 이 상품을 영구 제외·목록 삭제합니다. 계속할까요?'))return false;skipConfirm=true;}var message={slot_candidate:'선택 상품을 '+sectionLabel(placementKey)+' 섹션의 비공개 배치 예정 목록으로 보내고 관리자 결정으로 고정합니다.',hold:'선택 상품을 보류 목록으로 이동하고 관리자 결정으로 고정합니다.',reject:'선택 상품을 제외 목록으로 이동하고 관리자 결정으로 고정합니다.',purge:'선택 상품을 영구 제외합니다. 같은 원장 후보의 자동 승격을 차단합니다.',undecided:'선택 상품을 미배정 후보 목록으로 복원하고 관리자 결정으로 유지합니다.',ai_reclassify:'관리자 고정을 해제하고 다음 AI 자동화의 재분류 대상으로 돌립니다.'}[decision]||'상품 상태를 변경합니다.';if(!skipConfirm&&(decision==='reject'||decision==='purge')&&!window.confirm(message+'\n\n'+title))return false;try{if(row&&['hold','reject','purge','undecided','ai_reclassify'].indexOf(decision)>=0&&frontPublicationActive(row))await deferFrontUnmatchBeforeManagementChange(row);if(row&&row.ledgerSource==='candidate'){var ledgerResult=await api(CONTROL,'product_candidate_ledger_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateId:text(row.candidateId||row.id),decision:decision,placementKey:placementKey||''});await refreshCandidateLedgerProducts();var lp=ledgerResult.actionResult&&ledgerResult.actionResult.placement,ledgerMessage=decision==='slot_candidate'?'상품 1건을 '+sectionLabel(sectionKeyOf(lp)||placementKey)+' 섹션 후보로 지정했습니다.':decision==='hold'?'상품 1건을 보류 목록으로 이동했습니다.':decision==='reject'?'상품 1건을 제외 목록으로 이동했습니다.':decision==='purge'?'상품 1건을 영구 제외했습니다.':decision==='ai_reclassify'?'상품 1건의 관리자 고정을 해제하고 AI 재분류 대상으로 돌렸습니다.':'상품 1건을 미배정 후보 목록으로 복원했습니다.';show(ledgerMessage+' 자동 공개나 결제는 실행하지 않았습니다.','ok');return true;}var data=await api(CONTROL,'product_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',productId:productId,decision:decision,placementKey:placementKey||''});lastProductJson=data;rememberReport('product',data);renderProductProgress(data);renderProducts(data.products||[]);saveReviewSnapshot();var placement=data.actionResult&&data.actionResult.placement,doneMessage=decision==='slot_candidate'?'상품 1건을 '+sectionLabel(sectionKeyOf(placement)||placementKey)+' 섹션에 관리자 우선으로 지정했습니다.':decision==='hold'?'상품 1건을 보류 목록으로 이동했습니다.':decision==='reject'?'상품 1건을 제외 목록으로 이동했습니다.':decision==='purge'?'상품 1건을 영구 제외했습니다.':decision==='ai_reclassify'?'상품 1건의 관리자 고정을 해제하고 AI 재분류 대상으로 돌렸습니다.':'상품 1건을 미배정 후보 목록으로 복원했습니다.';show(doneMessage+' 자동 공개나 결제는 실행하지 않았습니다.','ok');return true;}catch(e){show(text(e.message)||'상품 판정을 저장하지 못했습니다.','fail');return false;}}
  async function applyProductExclusionBulk(kind,decision){
    var ids=Array.prototype.slice.call(document.querySelectorAll('[data-product-exclusion-select="'+kind+'"]:checked')).map(function(box){return text(box.value);}).filter(Boolean);if(!ids.length){show('처리할 상품을 선택해 주세요.','warn');return;}
    if((decision==='reject'||decision==='purge')&&!window.confirm('선택 '+ids.length+'건을 '+(decision==='purge'?'영구 제외':'제외 관리로 이동')+' 처리하시겠습니까?'))return;
    try{var result=await managementCandidateBulk(ids,decision,'');var summary='요청 '+ids.length+'건 · 성공 '+Number(result.processed||0)+'건 · 실패 '+Number(result.failed||0)+'건';show(summary+(decision==='purge'?' · 보류·제외 관리에서 영구 제외했습니다.':' · 관리자 후보 상태를 변경했습니다. 프론트 공개는 실행하지 않았습니다.'),result.failed?'warn':'ok');renderExcludedLedger();}
    catch(error){show(text(error&&error.message)||'선택 상품 일괄 처리를 완료하지 못했습니다.','fail');}
  }
  function latestProductKey(row){return text(row&&row.id||row&&row.productIdentity||row&&row.productUrl||row&&row.url);}
  function latestSelectedIds(){var valid={};latestProductRows.forEach(function(row){var id=latestProductKey(row);if(id)valid[id]=true;});return Object.keys(latestSelectedProducts).filter(function(id){return latestSelectedProducts[id]===true&&valid[id];});}
  function latestProductRef(row){var id=latestProductKey(row),index=Number(row&&row.researchResultIndex);return id&&Number.isFinite(index)&&index>=0?{id:id,resultIndex:Math.floor(index)}:null;}
  function latestRowsForIds(ids){var wanted={};(ids||[]).forEach(function(id){wanted[text(id)]=true;});return latestProductRows.filter(function(row){return wanted[latestProductKey(row)]===true;});}
  function latestRefsForRows(rows){return (rows||[]).map(latestProductRef).filter(Boolean);}

  function ensureLatestProductQueueControls(){
    var grid=$('latestProductGrid');if(!grid||!grid.parentNode)return;
    var toolbar=$('latestProductQueueToolbar');
    if(!toolbar){toolbar=document.createElement('div');toolbar.id='latestProductQueueToolbar';toolbar.className='section-product-toolbar candidate-bulk-toolbar';toolbar.innerHTML='<label class="product-front-select-label"><input id="latestProductSelectAll" type="checkbox"> 최신 상품 전체 선택</label><span id="latestProductSelectedCount" class="pill info">선택 상품 0건</span><button id="latestSelectedQueueStageBtn" type="button" class="product-section-front-button" disabled>선택 상품 전체상품 대기열 등록</button><button id="latestSelectedAiBtn" type="button" class="product-section-ai-button" disabled>선택 상품 AI 검증·자동 배치</button><button id="latestAllQueueStageBtn" type="button" class="secondary" disabled>최신 상품 전체상품 대기열 등록</button><button id="latestAllAiBtn" type="button" class="product-section-ai-button" disabled>최신 상품 전체 AI 검증·자동 배치</button><button id="latestSelectedQueueUnmatchBtn" type="button" class="product-section-unmatch-button" disabled>선택 상품 대기열 매칭 해제</button><button id="latestSelectedQueueDeleteBtn" type="button" class="danger" disabled>선택 상품 목록 삭제</button><span id="latestManualActionState" class="small" aria-live="polite"></span>';grid.parentNode.insertBefore(toolbar,grid);}
  }
  function syncLatestProductQueueControls(){
    ensureLatestProductQueueControls();var ids=latestSelectedIds(),all=$('latestProductSelectAll'),count=$('latestProductSelectedCount'),status=text(lastProductJson&&lastProductJson.status),queueReady=status==='complete'||(productPausedForQueue&&productPauseServerConfirmed),hardBusy=latestQueueActionActive||productQueueStageActive||productAutomationActive||productFrontSyncActive,allStageBusy=hardBusy||productLoopActive||!queueReady,hasRows=latestProductRows.length>0;
    /* Explicitly selected rows are already visible inspected research results, so
       private queue registration/delete/unmatch may proceed while the wider research
       loop continues. Only the whole-current-research action still requires complete
       or durably paused state. This keeps private review responsive without opening
       the public/front publication gate. */
    if(all){all.checked=hasRows&&ids.length===latestProductRows.length;all.indeterminate=ids.length>0&&ids.length<latestProductRows.length;all.disabled=hardBusy||!hasRows;}
    if(count)count.textContent='선택 상품 '+ids.length+'건';
    if($('latestSelectedQueueStageBtn'))$('latestSelectedQueueStageBtn').disabled=hardBusy||!ids.length;
    if($('latestAllQueueStageBtn'))$('latestAllQueueStageBtn').disabled=allStageBusy||!hasRows;
    if($('latestSelectedAiBtn'))$('latestSelectedAiBtn').disabled=hardBusy||!ids.length;
    if($('latestAllAiBtn'))$('latestAllAiBtn').disabled=allStageBusy||!hasRows;
    if($('latestSelectedQueueUnmatchBtn'))$('latestSelectedQueueUnmatchBtn').disabled=hardBusy||!ids.length;
    if($('latestSelectedQueueDeleteBtn'))$('latestSelectedQueueDeleteBtn').disabled=hardBusy||!ids.length;
    Array.prototype.forEach.call(document.querySelectorAll('[data-latest-queue-select]'),function(box){box.checked=latestSelectedProducts[box.value]===true;box.disabled=hardBusy;});
  }
  async function runLatestProductQueueAction(operation,scopeMode,options){
    options=options||{};
    if(!selectedCountry||latestQueueActionActive)return;
    var unmatch=operation==='unmatch',deleting=operation==='delete',selectedIds=latestSelectedIds(),selectedRows=latestRowsForIds(selectedIds),allMode=scopeMode==='all',ids=allMode?latestProductRows.map(latestProductKey).filter(Boolean):selectedIds;
    ids=Array.from(new Set(ids));
    if(!allMode&&!ids.length){show('먼저 최신 상품을 선택해 주세요.','warn');return;}
    if(allMode&&!latestProductRows.length&&Number(lastProductJson&&lastProductJson.summary&&lastProductJson.summary.latestResearchProducts||0)<=0){show('현재 리서치 사이클의 최신 상품이 없습니다.','warn');return;}
    if((unmatch||deleting)&&allMode){show((deleting?'대기열 삭제':'대기열 매칭 해제')+'는 보호를 위해 선택 상품에만 사용할 수 있습니다.','warn');return;}
    if(unmatch&&options.skipConfirm!==true&&!window.confirm('선택 상품 '+ids.length+'건의 비공개 상품 후보·중개수익 대기열 매칭만 해제합니다. 최신 리서치 목록과 리서치 진행상태는 그대로 유지합니다. 계속할까요?'))return;
    if(deleting&&options.skipConfirm!==true&&!window.confirm('선택 상품 '+ids.length+'건을 현재 최신 상품 리서치 목록에서 삭제합니다. 비공개 대기열의 미결정 항목은 함께 정리하고, 이미 배치·공개·관리자 고정 등 후속 상태가 있는 상품은 그 후속 상태만 안전하게 보존합니다. 영구 제외가 아니므로 다음 상품 리서치에서 다시 발견될 수 있습니다. 계속할까요?'))return;
    latestQueueActionActive=true;syncLatestProductQueueControls();var totalHandled=0,totalFailed=0,totalBlocked=0,totalEligible=0,deletedUiKeys={},state=$('productQueueStageState'),manualState=$('latestManualActionState'),requestedScope=scopeSnapshot(),requestedKey=scopeKey(requestedScope);
    try{
      if(unmatch||deleting){
        for(var off=0;off<selectedRows.length;off+=LATEST_MANUAL_ACTION_BATCH){
          if(scopeKey()!==requestedKey)throw new Error('대기열 작업 중 선택 범위가 변경됐습니다.');
          var rowsChunk=selectedRows.slice(off,off+LATEST_MANUAL_ACTION_BATCH),chunkIds=rowsChunk.map(latestProductKey).filter(Boolean),chunkRefs=latestRefsForRows(rowsChunk),progressText=(deleting?'최신 상품 목록 삭제 ':'최신 상품 대기열 매칭 해제 ')+Math.min(off+rowsChunk.length,selectedRows.length)+'/'+selectedRows.length+'건';
          if(state)state.textContent=progressText;if(manualState)manualState.textContent=progressText+' · 10건 단위 안전 처리';
          var result=await api(CONTROL,'product_research_stage_current','POST',{}, {countryCode:requestedScope.country,subdivisionCode:requestedScope.region,jobId:lastProductJson&&lastProductJson.jobId||'',source:'latest_list_manual',operation:deleting?'delete':'unmatch',productIds:chunkIds,productRefs:chunkRefs},20000),part=result&&result.partialQueue||{};
          totalHandled+=Number(part.handled||0);totalFailed+=Number(part.failed||0);totalBlocked+=Number(part.blocked||0);totalEligible+=Number(part.eligible||0);
          if(deleting&&result&&result.ok!==false){var confirmedKeys=Array.isArray(part.deletedKeys)?part.deletedKeys.map(text).filter(Boolean):[];if(confirmedKeys.length){var confirmedMap={};confirmedKeys.forEach(function(key){confirmedMap[key]=true;});rowsChunk.forEach(function(row){var key=latestProductKey(row);if(key&&confirmedMap[key])deletedUiKeys[key]=true;});}else if(Number(part.deleted||0)>=rowsChunk.length){chunkIds.forEach(function(id){deletedUiKeys[id]=true;});}}
          await new Promise(function(resolve){setTimeout(resolve,120);});
        }
      }else{
        /* Latest-list registration must use the exact rows visible to the
           administrator.  The old whole-list path relied on a durable scan
           cursor; once that cursor reached the end, newly eligible rows could
           remain visible while every later click reported handled=0.  Treat
           both selected and whole-list registration as explicit 100-row
           windows, with the server still committing only 10 rows per request. */
        var stageRows=allMode?latestProductRows.slice():selectedRows.slice(),stageLabel=allMode?'최신 상품 전체':'선택 상품',stagedCandidateIds={};
        for(var start=0;start<stageRows.length;start+=100){
          var selectedChunkRows=stageRows.slice(start,start+100),selectedChunkIds=selectedChunkRows.map(latestProductKey).filter(Boolean),selectedChunkRefs=latestRefsForRows(selectedChunkRows),selectedPass=0,selectedStalled=0,selectedRemaining=null;
          while(selectedPass<24){
            if(scopeKey()!==requestedKey)throw new Error('대기열 작업 중 선택 범위가 변경됐습니다.');
            if(state)state.textContent=stageLabel+' 대기열 등록 · '+Math.min(start+selectedChunkRows.length,stageRows.length)+'/'+stageRows.length+'건 · 10건 단위 저장';
            var selectedResult=await api(CONTROL,'product_research_stage_current','POST',{}, {countryCode:requestedScope.country,subdivisionCode:requestedScope.region,jobId:lastProductJson&&lastProductJson.jobId||'',source:'latest_list_manual',operation:'stage',productIds:selectedChunkIds,productRefs:selectedChunkRefs},20000),selectedPart=selectedResult&&selectedResult.partialQueue||{};
            if(selectedPart.migration===true){if(state)state.textContent='기존 대용량 상품 원장을 국가·지역 분할 원장으로 안전 전환 중 · '+Number(selectedPart.migrated||0)+'/'+Number(selectedPart.migrationTotal||0)+'건';selectedPass+=1;await new Promise(function(resolve){setTimeout(resolve,180);});continue;}
            totalHandled+=Number(selectedPart.handled||0);totalFailed+=Number(selectedPart.failed||0);totalBlocked+=Number(selectedPart.blocked||0);totalEligible+=Number(selectedPart.eligible||0);(Array.isArray(selectedPart.candidateIds)?selectedPart.candidateIds:[]).forEach(function(id){id=text(id);if(id)stagedCandidateIds[id]=true;});
            var selectedRemain=Number(selectedPart.remaining||0);if(selectedPart.complete===true||selectedRemain<=0)break;
            if(selectedRemaining!=null&&selectedRemain>=selectedRemaining&&Number(selectedPart.handled||0)<=0)selectedStalled+=1;else selectedStalled=0;
            if(selectedStalled>=3)throw new Error(stageLabel+' 대기열 등록이 반복 정체되어 저장 상태를 유지한 채 중단했습니다.');
            selectedRemaining=selectedRemain;selectedPass+=1;await new Promise(function(resolve){setTimeout(resolve,160);});
          }
          if(selectedPass>=24)throw new Error(stageLabel+' 대기열 안전 반복 한도에 도달했습니다.');
        }
      }
      if(deleting&&Object.keys(deletedUiKeys).length){latestProductRows=latestProductRows.filter(function(row){return deletedUiKeys[latestProductKey(row)]!==true;});Object.keys(deletedUiKeys).forEach(function(id){delete latestSelectedProducts[id];});latestProductPage=clampPage(latestProductPage,latestProductRows.length,MANAGEMENT_PAGE_SIZE);renderLatestProductRows();}try{var saved=await loadProductResearchCompact(requestedScope.country,requestedScope.region);if(saved&&saved.status&&saved.status!=='not_started'){lastProductJson=mergeCompactProductStatus(saved);renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();}}catch(_statusError){}
      try{await refreshLatestResearchRows(requestedScope.country,requestedScope.region,{state:state,label:'최신 상품 리서치 목록'});}catch(_latestRefreshError){}
      try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_ledgerError){}
      lastScopeAuditJson=null;if(activeScopeAudit==='queue'){try{var queueAudit=await api(REVIEW,'diagnostic','GET',scopeParams());queueAudit.scope=auditScopeOf(queueAudit);renderScopeAudit(queueAudit,'queue');}catch(_queueAuditRefreshError){}}
      selectedIds.forEach(function(id){delete latestSelectedProducts[id];});syncLatestProductQueueControls();
      var finalText=(deleting?'최신 상품 목록 삭제':(unmatch?'최신 상품 대기열 매칭 해제':'최신 상품 대기열 등록'))+' 완료 · '+(allMode?'현재 리서치 전체':'선택 '+ids.length+'건')+' · 반영 '+totalHandled+'건'+(totalBlocked?' · 보호/차단 '+totalBlocked+'건':'')+(totalFailed?' · 실패 '+totalFailed+'건':'');if(state)state.textContent=finalText;if(manualState)manualState.textContent=finalText;
      show((deleting?'선택 상품을 현재 최신 리서치 목록에서 삭제했습니다.':(unmatch?'선택 상품의 대기열 매칭을 해제했습니다.':'최신 상품을 상품 후보·중개수익 대기열에 등록했습니다.'))+(totalBlocked?(deleting?' · 후속 배치·공개·관리자 고정 '+totalBlocked+'건은 그대로 보존했습니다.':' · 보호 상태 '+totalBlocked+'건은 변경하지 않았습니다.'):'')+(!unmatch&&!deleting&&totalHandled?' · 전체 상품 후보·대기열에 '+totalHandled+'건 반영했습니다.':''),totalFailed?'warn':'ok');return{ok:totalFailed===0,handled:totalHandled,failed:totalFailed,blocked:totalBlocked,eligible:totalEligible,candidateIds:typeof stagedCandidateIds==='object'?Object.keys(stagedCandidateIds):[]};
    }catch(e){var failText='최신 상품 수동 작업 중단: '+conciseRequestError(e&&e.message,e&&e.status);if(state)state.textContent=failText;if(manualState)manualState.textContent=failText;show(conciseRequestError(e&&e.message,e&&e.status),'warn');return{ok:false,error:e};}
    finally{latestQueueActionActive=false;syncLatestProductQueueControls();}
  }
  function productUrlMatchKey(value){var url=safeExternalUrl(value);if(!url)return'';try{var u=new URL(url);u.hash='';u.hostname=u.hostname.toLowerCase();if(u.pathname.length>1)u.pathname=u.pathname.replace(/\/+$/,'');return u.toString();}catch(_e){return url.replace(/#.*$/,'').replace(/\/+$/,'');}}
  function candidateIdsForLatestRows(rows){var wanted={};(rows||[]).forEach(function(row){var key=productUrlMatchKey(row&&row.productUrl||row&&row.url);if(key)wanted[key]=true;});return Array.from(new Set(productRows.filter(function(row){return row&&row.ledgerSource==='candidate'&&wanted[productUrlMatchKey(row.productUrl||row.url)]===true;}).map(function(row){return text(row.candidateId||row.id);}).filter(Boolean)));}
  async function runLatestAi(scopeMode){
    if(!selectedCountry||latestQueueActionActive||productAutomationActive)return;var allMode=scopeMode==='all',rows=allMode?latestProductRows.slice():latestRowsForIds(latestSelectedIds());if(!rows.length){show(allMode?'현재 최신 상품 리서치 목록이 비어 있습니다.':'먼저 최신 상품을 선택해 주세요.','warn');return;}
    var staged=await runLatestProductQueueAction('stage',allMode?'all':'selected');if(!staged||staged.ok===false&&Number(staged.handled||0)<=0)return;
    var candidateIds=Array.from(new Set((Array.isArray(staged.candidateIds)?staged.candidateIds:[]).concat(candidateIdsForLatestRows(rows)).map(text).filter(Boolean)));if(!candidateIds.length){show((allMode?'최신 상품':'선택 상품')+' 중 비공개 대기열 등록이 확인된 후보가 없습니다. 대기열·배치 전환 검증으로 연결 상태를 확인해 주세요.','warn');return;}
    if(candidateIds.length<rows.length)show((allMode?'최신 상품 ':'선택 ')+rows.length+'건 중 대기열에서 확인된 '+candidateIds.length+'건만 AI 검증·자동 배치합니다. 나머지는 검증 보류·중복 병합 또는 대기열 보호 상태일 수 있습니다.','warn');
    await runCandidateLedgerAiRecovery(candidateIds,{label:allMode?'최신 상품 전체':'선택 최신 상품',confirm:false});try{await runProductTransitionAudit({silent:true});}catch(_auditError){}
  }
  async function runLatestSelectedAi(){return runLatestAi('selected');}
  async function runLatestAllAi(){return runLatestAi('all');}

  function renderLatestProductRows(){
    var root=$('latestProductGrid');if(!root)return;ensureLatestProductQueueControls();
    var rows=Array.isArray(latestProductRows)?latestProductRows:[],valid={};rows.forEach(function(row){var id=latestProductKey(row);if(id)valid[id]=true;});Object.keys(latestSelectedProducts).forEach(function(id){if(!valid[id])delete latestSelectedProducts[id];});
    if(!rows.length){root.innerHTML='<div class="small">이번 리서치 사이클에서 새로 발견되거나 다시 확인된 상품이 아직 없습니다.</div>';syncLatestProductQueueControls();return;}
    latestProductPage=clampPage(latestProductPage,rows.length,MANAGEMENT_PAGE_SIZE);var startIndex=latestProductPage*MANAGEMENT_PAGE_SIZE,pageRows=rows.slice(startIndex,startIndex+MANAGEMENT_PAGE_SIZE);root.innerHTML=pageRows.map(function(row,index){return productCardHtml(row,startIndex+index,'latest','latest');}).join('')+pagerMarkup('latest','',latestProductPage,rows.length,MANAGEMENT_PAGE_SIZE);wireProductImages(root);syncLatestProductQueueControls();
  }


  function captureOpenProductGroup(){var panel=document.querySelector('details[data-product-group][open]');return panel?{key:text(panel.getAttribute('data-product-group')),kind:text(panel.getAttribute('data-product-group-kind')),scrollY:window.scrollY}:null;}
  function restoreOpenProductGroup(state){if(!state||!state.key)return;var panels=Array.prototype.slice.call(document.querySelectorAll('details[data-product-group]')),panel=panels.filter(function(item){return text(item.getAttribute('data-product-group'))===state.key&&text(item.getAttribute('data-product-group-kind'))===state.kind;})[0];if(!panel)return;panel.open=true;setTimeout(function(){try{window.scrollTo(0,Number(state.scrollY||0));}catch(_e){}},0);}
  function renderProducts(rows){
    var openGroup=captureOpenProductGroup(),nextRows=Array.isArray(rows)?rows:[],validProductIds={};nextRows.forEach(function(row){if(row&&row.id&&assignedSectionKey(row))validProductIds[text(row.id)]=true;});Object.keys(frontSelectedProducts).forEach(function(id){if(!validProductIds[id])delete frontSelectedProducts[id];});Object.keys(frontSelectedSections).forEach(function(key){if(!PRODUCT_SECTION_MAP[key])delete frontSelectedSections[key];});
    productRows=Array.isArray(rows)?rows:[];var controlsReady=!!lastProductJson&&productRows.length>0&&!productLoopActive;setButtonEnabled('productAiAutoBtn',controlsReady&&!productAutomationActive&&!productFrontSyncActive);var undecided=productRows.filter(function(row){return productDecision(row)==='undecided';}).length,slotRows=productRows.filter(function(row){return productDecision(row)==='slot_candidate';}),assigned=slotRows.filter(function(row){return!!assignedSectionKey(row);}).length,repair=slotRows.length-assigned,held=productRows.filter(function(row){return productDecision(row)==='hold';}).length,rejected=productRows.filter(function(row){var d=productDecision(row);return d==='reject'||d==='purge';}).length,candidateTotal=undecided+slotRows.length;if($('productCandidateSummary'))$('productCandidateSummary').textContent=candidateTotal+'건';if($('productSectionSummary'))$('productSectionSummary').textContent='실제 배치 예정 '+assigned+'건 / 최대 1,800건';if($('productDecisionStats'))$('productDecisionStats').innerHTML=[['미결정 후보',undecided],['실제 섹션 배치 예정',assigned],['배정정보 복구 필요',repair],['보류',held],['제외·영구 제외',rejected]].map(function(item){return'<div class="product-decision-stat"><span class="small">'+esc(item[0])+'</span><strong>'+esc(item[1])+'</strong></div>';}).join('');syncExcludedLedgerCounts();renderProductSectionBoard();if($('productCandidatePanel')&&$('productCandidatePanel').open)renderProductCandidateGroups();else if($('productGrid'))$('productGrid').innerHTML='';if($('excludedLedgerPanel')&&$('excludedLedgerPanel').open)renderExcludedLedger();syncManagementToggleLabels();syncFrontSelectionControls();syncProductAiFinalizeControl();restoreOpenProductGroup(openGroup);
  }

  function transitionAuditMetric(label,value,note,kind){return'<div class="product-transition-audit-item"><span class="small">'+esc(label)+'</span><strong>'+esc(value)+'</strong><span class="small">'+esc(note||'')+'</span>'+(kind?'<span class="pill '+esc(kind)+'">'+esc(kind==='good'?'정상':'확인')+'</span>':'')+'</div>';}
  function downloadProductTransitionAudit(){if(!lastProductTransitionAuditJson){show('먼저 대기열·배치 전환 검증을 실행해 주세요.','warn');return;}try{var stamp=new Date().toISOString().replace(/[:.]/g,'-'),scope=lastProductTransitionAuditJson.scope||scopeSnapshot(),name='IGDC_PRODUCT_TRANSITION_AUDIT_'+text(scope.country||selectedCountry).toUpperCase()+'_'+text(scope.region||selectedSubdivision||'NATIONWIDE').toUpperCase()+'_'+stamp+'.json',blob=new Blob([JSON.stringify(lastProductTransitionAuditJson,null,2)+'\n'],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(function(){try{a.remove();URL.revokeObjectURL(url);}catch(_e){}},1200);show('읽기 전용 전환 검증 JSON 다운로드를 시작했습니다.','ok');}catch(e){show('검증 JSON 파일을 만들지 못했습니다: '+text(e&&e.message),'fail');}}
  async function runProductTransitionAudit(options){
    options=options||{};if(!selectedCountry)return null;var button=$('productTransitionAuditBtn'),download=$('productTransitionAuditDownloadBtn'),state=$('productTransitionAuditState'),grid=$('productTransitionAuditGrid'),requested=scopeSnapshot(),requestedKey=scopeKey(requested);if(button)button.disabled=true;if(download)download.disabled=true;if(state&&!options.silent){state.className='product-transition-audit-state';state.textContent='현재 리서치 상태·최신 상품·비공개 후보 원장을 다시 읽어 대기열→후보→18개 섹션 연결을 교차 검증 중입니다.';}
    try{
      var status=await loadProductResearchCompact(requested.country,requested.region);if(scopeKey()!==requestedKey)throw new Error('검증 중 선택 범위가 변경됐습니다.');if(status&&status.status&&status.status!=='not_started'){lastProductJson=mergeCompactProductStatus(status);renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);}
      await refreshCandidateLedgerProducts({preserveResearchReport:true});if(scopeKey()!==requestedKey)throw new Error('검증 중 선택 범위가 변경됐습니다.');
      var expectedLatest=Number(status&&status.summary&&status.summary.latestResearchProducts||0);if(expectedLatest>0&&(latestProductRows.length<expectedLatest||!latestProductRows.length)){await refreshLatestResearchRows(requested.country,requested.region,{state:options.silent?null:state,label:'전환 검증 최신 상품',preserveOnFailure:true});}
      var latestUrls={};latestProductRows.forEach(function(row){var key=productUrlMatchKey(row&&row.productUrl||row&&row.url);if(key)latestUrls[key]=true;});
      var total=productRows.length,undecided=0,assigned=0,repair=0,held=0,rejected=0,currentLinked=0;productRows.forEach(function(row){var decision=productDecision(row),key=assignedSectionKey(row),urlKey=productUrlMatchKey(row.productUrl||row.url);if(urlKey&&latestUrls[urlKey])currentLinked+=1;if(decision==='undecided')undecided+=1;else if(decision==='slot_candidate'){if(key)assigned+=1;else repair+=1;}else if(decision==='hold')held+=1;else if(decision==='reject'||decision==='purge')rejected+=1;});
      var summary=status&&status.summary||{},partial=status&&status.pipeline&&status.pipeline.partialQueue||{},eligible=Number(summary.privateResearchQueueEligible||partial.eligible||0),staged=Number(summary.privateResearchQueueStaged||partial.done||0),active=undecided+assigned+repair,excluded=held+rejected,classified=active+excluded,linkGap=Math.max(0,staged-currentLinked),classificationGap=Math.max(0,total-classified),issues=[];if(linkGap>0)issues.push('이번 등록 '+staged+'건 중 최신 리서치와 연결 확인되지 않은 '+linkGap+'건');if(classificationGap>0)issues.push('후보 상태 미분류 '+classificationGap+'건');if(repair>0)issues.push('18개 섹션 배정정보 복구 필요 '+repair+'건');
      var phase=text(status&&status.status),phaseReady=phase==='complete'||(status&&status.pause&&status.pause.paused===true),auditOk=linkGap===0&&classificationGap===0,latestDeleted=Number(status&&status.pipeline&&status.pipeline.latestResearchDeleted||0),removedFromList=productRows.filter(function(row){return text(row&&row.queueControl&&row.queueControl.action).toLowerCase()==='remove_from_list'||text(row&&row.review&&row.review.state).toLowerCase()==='removed_from_list';}).length,frontPrepared=productRows.filter(function(row){var s=text(row&&row.frontPublication&&row.frontPublication.status).toLowerCase();return s==='queued'||s==='publish_requested';}).length,frontLive=productRows.filter(function(row){var s=text(row&&row.frontPublication&&row.frontPublication.status).toLowerCase();return s==='matched'||s==='published'||s==='active';}).length,frontPendingBuild=productRows.filter(function(row){return row&&row.frontPublication&&row.frontPublication.pendingBuild===true;}).length,bridge=window.IGDCCommerceManagementBridge||{},readOnlyCleanupState={latestResearchDeleted:latestDeleted,candidateRemovedFromList:removedFromList,frontPrepared:frontPrepared,frontLive:frontLive,frontPendingBuild:frontPendingBuild,aiExecutionBridgeReady:typeof bridge.preview==='function'&&typeof bridge.execute==='function',perProductSectionReleaseDispatchesBuild:false,observedAt:new Date().toISOString()};
      if(grid)grid.innerHTML=transitionAuditMetric('최신 상품',latestProductRows.length,'이번 리서치 목록','info')+transitionAuditMetric('대기열 적격',eligible,'검증 완료 기준','info')+transitionAuditMetric('이번 대기열 등록',staged,'현재 리서치 실행 원장',staged&&linkGap===0?'good':'info')+transitionAuditMetric('리서치↔대기열 연결',currentLinked,staged?'등록 '+staged+'건과 교차 확인':'등록 전 상태',linkGap===0?'good':'warn')+transitionAuditMetric('후보 관리 목록',active,'미배정·배치·복구 포함','info')+transitionAuditMetric('보류·제외',excluded,'후보 원장에는 보존','info')+transitionAuditMetric('18개 섹션 배치',assigned,'프론트 매칭 전 단계',repair===0?'good':'info')+transitionAuditMetric('배정정보 복구',repair,'AI/수동 재배치 대상',repair===0?'good':'warn')+transitionAuditMetric('읽기 전용 정리 상태',latestDeleted,'리서치 삭제 '+latestDeleted+' · 후보 목록 제거 '+removedFromList+' · AI 실행 '+(readOnlyCleanupState.aiExecutionBridgeReady?'연결':'미연결'),readOnlyCleanupState.aiExecutionBridgeReady?'good':'warn');
      if(state){state.className='product-transition-audit-state '+(auditOk?'complete':'warn');state.textContent=(auditOk?'전환 원장 교차검증 정상':'전환 원장 확인 필요')+' · 후보 원장 전체 '+total+'건 = 관리 '+active+'건 + 보류·제외 '+excluded+'건'+(staged?' · 이번 리서치 대기열 등록 '+staged+'건 중 최신 리서치 연결 '+currentLinked+'건':'')+(issues.length?' · '+issues.join(' · '):'')+(phaseReady?' · 리서치 전환 게이트 사용 가능':' · 리서치가 아직 진행 상태이므로 완료 또는 서버 일시정지 후 추가 등록 가능');}
      lastProductTransitionAuditJson={ok:auditOk,reportType:'igdc-product-transition-audit-readonly',schema:'igdc-product-transition-audit-readonly.v1',scope:requested,status:phase,phaseReady:phaseReady,latest:latestProductRows.length,eligible:eligible,staged:staged,currentLinked:currentLinked,total:total,active:active,excluded:excluded,assigned:assigned,repair:repair,issues:issues,readOnlyCleanupState:readOnlyCleanupState,safety:{readOnly:true,frontPublication:false,githubNetlifyBuild:false,paymentExecution:false}};
      if(lastProductJson){lastProductJson.pipeline=Object.assign({},lastProductJson.pipeline||{},{transitionAuditReadOnly:readOnlyCleanupState});rememberReport('product',lastProductJson);}if(download)download.disabled=false;return lastProductTransitionAuditJson;
    }catch(e){lastProductTransitionAuditJson=null;if(state){state.className='product-transition-audit-state warn';state.textContent='대기열·배치 전환 검증 실패: '+conciseRequestError(e&&e.message,e&&e.status)+' · 기존 원장은 변경하지 않았습니다.';}if(!options.silent)show(conciseRequestError(e&&e.message,e&&e.status),'warn');return{ok:false,error:e};}
    finally{if(button)button.disabled=false;if(download)download.disabled=!lastProductTransitionAuditJson;syncLatestProductQueueControls();}
  }

  function productAiDraft(data){return data&&data.aiAutomationDraft&&typeof data.aiAutomationDraft==='object'?data.aiAutomationDraft:{};}
  function ensureProductAiFinalizeControl(){
    var ai=$('productAiAutoBtn');if(!ai||!ai.parentNode)return;var actions=ai.parentNode,button=$('productAiFinalizeBtn');
    if(!button){button=document.createElement('button');button.id='productAiFinalizeBtn';button.type='button';button.className='secondary';button.disabled=true;button.textContent='AI 정리 최종 완료';actions.insertBefore(button,ai.nextSibling);}
  }
  function syncProductAiFinalizeControl(){
    ensureProductAiFinalizeControl();var button=$('productAiFinalizeBtn'),draft=productAiDraft(lastProductJson),pending=Number(draft.pendingItems||0),ready=!!text(draft.runToken)&&pending>0;
    if(button){button.disabled=productAutomationActive||productFrontSyncActive||!selectedCountry||!ready;button.textContent=ready?'AI 정리 최종 완료 ('+pending+'건)':'AI 정리 최종 완료';}
  }
  async function finalizeProductAiDraft(options){
    options=options||{};var internal=options.internal===true;if(!selectedCountry||(!internal&&productAutomationActive))return{ok:false,reason:'busy'};var draft=productAiDraft(lastProductJson),runToken=text(options.aiRunToken||draft.runToken),remaining=Number(draft.pendingItems||0);
    if(!runToken||remaining<=0){if(!internal)show('최종 완료할 AI 임시 정리 결과가 없습니다.','warn');syncProductAiFinalizeControl();return{ok:false,reason:'empty',remaining:0};}
    if(!internal&&!window.confirm('정상 완료된 AI 임시 정리 '+remaining+'건을 상품 후보·18개 섹션 배치 원장에 최종 확정하시겠습니까?\n\n미완료·오류 이후 상품은 건드리지 않습니다. 프론트 공개·결제는 실행하지 않습니다.'))return{ok:false,reason:'cancelled',remaining:remaining};
    var owns=!internal,state=$('productAiAutomationState'),synced=0,failed=0,passes=0,previous=remaining+1;if(owns)productAutomationActive=true;syncProductAiFinalizeControl();
    try{
      while(remaining>0&&failed===0&&passes<200){passes+=1;if(state){state.className='product-auto-state running';state.textContent='AI 임시 정리 최종 확정 · 남은 '+remaining+'건';}var data=await api(CONTROL,'product_ai_automation','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:'queue_sync',batchSize:10,aiRunToken:runToken});var result=data&&data.aiAutomationResult||{};synced+=Number(result.queueSynced||0);failed+=Number(result.queueSyncFailed||0);remaining=Number(result.queueSyncRemaining||0);lastProductJson=Object.assign({},lastProductJson||{},data,{products:productRows});rememberReport('product',lastProductJson);renderProductProgress(lastProductJson);saveReviewSnapshot();if(remaining>=previous&&Number(result.queueSynced||0)<=0)break;previous=remaining;}
      try{var refreshed=await loadProductResearchCompact(selectedCountry,selectedSubdivision||'NATIONWIDE');if(refreshed&&refreshed.status){lastProductJson=mergeCompactProductStatus(refreshed);rememberReport('product',lastProductJson);renderProductProgress(lastProductJson);saveReviewSnapshot();}}catch(_refreshError){}
      var finalDraft=productAiDraft(lastProductJson),partial=Number(finalDraft.completedItems||0)<Number(finalDraft.targetItems||0);if(state){state.className='product-auto-state '+(failed||remaining?'warn':'complete');state.textContent=(failed||remaining?'AI 최종 확정 일부 완료':(partial?'오류 직전 완료분 최종 확정':'AI 정리 최종 완료'))+' · 확정 '+synced+'건'+(remaining?' · 남음 '+remaining+'건':'')+(failed?' · 실패 '+failed+'건':'')+(partial?' · 미처리분은 그대로 대기':'');}
      if(!internal)show((partial?'정상 완료된 임시 정리분까지만':'AI 임시 정리 결과를')+' 최종 확정했습니다. 프론트 공개는 실행하지 않았습니다.',failed||remaining?'warn':'ok');return{ok:failed===0&&remaining===0,synced:synced,failed:failed,remaining:remaining,partial:partial};
    }catch(e){if(state){state.className='product-auto-state warn';state.textContent='AI 최종 확정 중단 · 직전 정상 확정분은 보존됩니다.';}if(!internal)show(text(e&&e.message)||'AI 최종 확정이 중단됐습니다.','fail');return{ok:false,error:e,synced:synced,failed:failed,remaining:remaining};}
    finally{if(owns)productAutomationActive=false;syncProductAiFinalizeControl();if(owns)renderProducts(productRows);}
  }

  function transientCandidateBatchError(error){var status=Number(error&&error.status)||0;return !status||[408,425,429,500,502,503,504,521,522,523,524].indexOf(status)>=0;}
  async function runCandidateLedgerAiRecovery(targetIds,options){
    options=options||{};var targets=Array.from(new Set((targetIds||[]).map(text).filter(Boolean)));if(!targets.length){show('현재 범위에 재검증·자동 배치할 상품 후보가 없습니다.','warn');return{ok:false,reason:'empty'};}
    if(options.confirm!==false&&!window.confirm('상품 후보 '+targets.length+'건을 다시 검증하고 살아 있는 상품만 섹션 후보로 재정렬하시겠습니까? 최근 정상 검증 기록은 재사용하고 오래되었거나 미확인인 상품만 실제 상세페이지를 다시 확인합니다.\n\n삭제·잘못된 접근·판매처 홈 리다이렉트 상품은 후보에서 보류하고, 정상 예비상품을 다시 배치합니다. 이 단계에서는 프론트 공개·결제를 실행하지 않습니다.'))return{ok:false,reason:'cancelled'};
    productAutomationActive=true;var ledgerState=$('productAiAutomationState'),assignedTotal=0,unassignedTotal=0,invalidTotal=0,inconclusiveTotal=0,changedTotal=0,revalidatedTotal=0,preservedTotal=0,balanceCounts=productSectionCounts(),tourDiningCount=tourDiningPlacementCount(),failedBatches=[];
    if(ledgerState){ledgerState.className='product-auto-state running';ledgerState.textContent=(options.label||'상품 후보')+' '+targets.length+'건을 10건씩 최근 검증 재사용·필요 항목 재검증·자동 배치 중입니다.';}
    try{
      for(var off=0;off<targets.length;off+=10){
        var batch=targets.slice(off,off+10),part=null,lastError=null;
        if(ledgerState)ledgerState.textContent='후보 실제 페이지 재검증·정책 균형 배치 '+Math.min(off+batch.length,targets.length)+'/'+targets.length+'건';
        for(var attempt=0;attempt<3&&!part;attempt++){
          try{part=await api(CONTROL,'product_candidate_ai_recover','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateIds:batch,balanceCounts:balanceCounts,tourDiningAutomaticCount:tourDiningCount},35000);}
          catch(e){lastError=e;if(!transientCandidateBatchError(e)||attempt>=2)break;if(ledgerState)ledgerState.textContent='후보 재검증 '+Math.min(off+batch.length,targets.length)+'/'+targets.length+'건 · 일시 응답 지연으로 '+(attempt+2)+'회차 재확인 중';await new Promise(function(resolve){setTimeout(resolve,700*(attempt+1));});}
        }
        if(!part){failedBatches.push({offset:off,candidateIds:batch.slice(),message:text(lastError&&lastError.message)||'batch_failed'});if(ledgerState)ledgerState.textContent='후보 재검증 '+Math.min(off+batch.length,targets.length)+'/'+targets.length+'건 · 실패 묶음 '+failedBatches.length+'개 기록 · 다음 묶음 계속';continue;}
        if(part.balanceCounts)balanceCounts=part.balanceCounts;if(part.tourDiningAutomaticCount!=null)tourDiningCount=Number(part.tourDiningAutomaticCount||0);assignedTotal+=Number(part.assigned||0);unassignedTotal+=Number(part.unassigned||0);invalidTotal+=Number(part.invalid||0);inconclusiveTotal+=Number(part.inconclusive||0);changedTotal+=Number(part.changedSection||0);revalidatedTotal+=Number(part.revalidated||0);preservedTotal+=Number(part.preserved||0);
      }
      await refreshCandidateLedgerProducts({preserveResearchReport:true});
      try{var researchState=await loadProductResearchCompact(selectedCountry,selectedSubdivision||'NATIONWIDE');if(researchState&&researchState.status&&researchState.status!=='not_started'){lastProductJson=mergeCompactProductStatus(researchState);rememberReport('product',lastProductJson);renderProductProgress(lastProductJson);saveReviewSnapshot();}}catch(_researchStateError){}
      var hasWarn=failedBatches.length||invalidTotal||inconclusiveTotal;if(ledgerState){ledgerState.className='product-auto-state '+(hasWarn?'warn':'complete');ledgerState.textContent='후보 갱신 '+(failedBatches.length?'부분 완료':'완료')+' · 재검증 '+revalidatedTotal+'건 · 정상 배치 '+assignedTotal+'건 · 정책 균형 재분류 '+changedTotal+'건 · 삭제/불량 '+invalidTotal+'건 · 일시 확인보류 '+inconclusiveTotal+'건 · 관리자 고정 유지 '+preservedTotal+'건'+(failedBatches.length?' · 실패 묶음 '+failedBatches.length+'개는 다음 실행에서 재시도 가능':'');}
      show('실제 상품 페이지 '+revalidatedTotal+'건을 다시 확인했습니다.'+(failedBatches.length?' 일시 오류 묶음 '+failedBatches.length+'개는 건너뛰고 나머지 묶음을 계속 처리했으며, 해당 후보는 원장에 그대로 남아 다음 실행에서 재시도할 수 있습니다.':'')+' 프론트 공개·결제는 실행하지 않았습니다.',hasWarn?'warn':'ok');
      return{ok:failedBatches.length===0,revalidated:revalidatedTotal,assigned:assignedTotal,invalid:invalidTotal,inconclusive:inconclusiveTotal,failedBatches:failedBatches};
    }finally{productAutomationActive=false;renderProducts(productRows);syncLatestProductQueueControls();}
  }

  async function runProductAiAutomation(mode,sectionKey,productIds,options){
    options=options||{};
    if(!selectedCountry||productAutomationActive)return;
    if(!lastProductJson||!productRows.length){show('AI 자동 배치할 상품 조사 결과가 없습니다. 상품 조사를 먼저 실행해 주세요.','warn');return;}
    var candidateLedgerMode=candidateLedgerViewActive(),pendingDraft=productAiDraft(lastProductJson);
    if(!candidateLedgerMode&&mode==='all'){
      /* The durable candidate ledger is the correct source for the top-level
         green AI automation button.  A page restored from chunked research
         results can otherwise call the legacy job.products path, which is
         intentionally empty for chunked_v1 jobs and returns 409. */
      try{await refreshCandidateLedgerProducts({preserveResearchReport:true});candidateLedgerMode=candidateLedgerViewActive();}catch(_candidateLedgerRefreshError){}
    }
    if(!candidateLedgerMode&&Number(pendingDraft.pendingItems||0)>0){show('이전에 정상 완료된 AI 임시 정리 '+Number(pendingDraft.pendingItems||0)+'건이 최종 확정 대기 중입니다. 먼저 `AI 정리 최종 완료`를 눌러 확정한 뒤 다음 정리를 시작해 주세요.','warn');syncProductAiFinalizeControl();return;}
    if(candidateLedgerMode){
      var selectedModeLedger=mode==='products',selectedLedgerIds=Array.isArray(productIds)?productIds.map(text).filter(Boolean):[],targets=productRows.filter(function(row){if(row.ledgerSource!=='candidate')return false;if(selectedModeLedger&&selectedLedgerIds.indexOf(text(row.id))<0)return false;var decision=productDecision(row);if(decision==='reject'||decision==='purge')return false;if(mode==='repair')return decision==='slot_candidate'&&!assignedSectionKey(row);if(mode==='section')return assignedSectionKey(row)===sectionKey||candidatePlacementKey(row)===sectionKey;return decision==='undecided'||decision==='slot_candidate'||decision==='hold';}).map(function(row){return text(row.candidateId||row.id);}).filter(Boolean);
      await runCandidateLedgerAiRecovery(targets,{label:selectedModeLedger?'선택 상품':'상품 후보',confirm:options.skipConfirm!==true});return;
    }
    var sectionMode=mode==='section',repairMode=mode==='repair',selectedMode=mode==='products',selectedIds=Array.isArray(productIds)?productIds.map(text).filter(Boolean):[],label=sectionMode?sectionLabel(sectionKey):(repairMode?'배정정보 복구 필요 후보':(selectedMode?'선택 후보 '+selectedIds.length+'건':'현재 국가 전체 18개 섹션'));
    if(selectedMode&&!selectedIds.length){show('AI 자동 배치할 후보를 선택해 주세요.','warn');return;}
    var selectedRowMap={};productRows.forEach(function(row){selectedRowMap[text(row&&row.id)]=row;});
    var selectedAllUndecided=selectedMode&&selectedIds.length>0&&selectedIds.every(function(id){var row=selectedRowMap[id];return !!row&&productDecision(row)==='undecided'&&!productManagementLocked(row);});
    var batchPlacement=!sectionMode&&!repairMode&&(!selectedMode||selectedAllUndecided),batchTargets=batchPlacement?(selectedMode?selectedIds:productRows.filter(function(row){return productDecision(row)==='undecided'&&!productManagementLocked(row);}).map(function(row){return text(row.id);}).filter(Boolean)):[];
    if(batchPlacement&&!batchTargets.length){show('현재 미배정 후보 중 AI 자동 배치할 상품이 없습니다.','warn');return;}
    var message=sectionMode?label+'의 관리자 고정 상품은 보존하고, 해당 섹션에 적합한 비공개 후보를 최대한 다시 정렬·보충합니다.':repairMode?'배정정보가 비어 있거나 잘못된 후보만 다시 분석하여, 판단 가능한 상품을 18개 섹션의 비공개 배치 예정 목록으로 복구합니다. 미배정 후보·보류·제외·관리자 수동 지정은 바꾸지 않습니다.':selectedMode?label+'만 저장된 조사 결과를 기준으로 AI 자동 배치합니다. 선택하지 않은 후보와 관리자 수동 지정은 바꾸지 않습니다.':label+'과 미배정·추가 확인 필요 목록을 전부 분석합니다. 상품 URL·이미지·판매처가 정상인 후보는 공개 전 경고 상태로라도 품목 정책에 맞는 섹션에 최대한 자동 배치합니다.';
    if(options.skipConfirm!==true&&!window.confirm(message+'\n\n보류·제외·영구 제외와 관리자 수동 지정은 덮어쓰지 않으며 사이트 공개·상품 수입·결제는 실행하지 않습니다.'))return;
    productAutomationActive=true;
    var top=$('productAiAutoBtn'),state=$('productAiAutomationState');
    if(top)top.disabled=true;
    Array.prototype.forEach.call(document.querySelectorAll('[data-section-ai-auto]'),function(button){button.disabled=true;});
    if(state){state.className='product-auto-state running';state.textContent=label+' AI 자동 정리를 진행하고 있습니다.';}
    try{
      var data=null,result={},queueSyncedTotal=0,queueFailedTotal=0,queueRemaining=0,autoFinalizeDraft=false,aiRunToken='',temporaryCompleted=0;
      if(batchPlacement){
        var batchSize=10,assignedTotal=0,pendingTotal=0,heldTotal=0,changedTotal=0,manualPreserved=0;autoFinalizeDraft=!selectedMode&&mode==='all';aiRunToken='ai_draft_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10);
        for(var off=0;off<batchTargets.length;off+=batchSize){
          var batch=batchTargets.slice(off,off+batchSize);
          if(state){state.className='product-auto-state running';state.textContent=label+' 정책 임시 정리 '+Math.min(off+batch.length,batchTargets.length)+'/'+batchTargets.length+'건 · 10건 단위 체크포인트 저장';}
          data=await api(CONTROL,'product_ai_automation','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:'placement_batch',productIds:batch,batchSize:batchSize,deferQueueSync:true,aiRunToken:aiRunToken,targetTotal:batchTargets.length,draftMode:autoFinalizeDraft?'automatic':'manual',automaticFinalize:autoFinalizeDraft});
          var partResult=data&&data.aiAutomationResult||{};
          assignedTotal+=Number(partResult.assigned||0);pendingTotal+=Number(partResult.pendingEvidenceAssigned||0);heldTotal+=Number(partResult.held||0);changedTotal+=Number(partResult.changed||0);manualPreserved=Math.max(manualPreserved,Number(partResult.manualPreserved||0));queueRemaining=Number(partResult.temporaryPendingItems||partResult.queueSyncRemaining||0);temporaryCompleted=Number(partResult.temporaryCompletedItems||temporaryCompleted+batch.length);
          lastProductJson=Object.assign({},lastProductJson||{},data,{products:productRows});renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();syncProductAiFinalizeControl();
        }
        if(autoFinalizeDraft){
          if(state){state.className='product-auto-state running';state.textContent=label+' 임시 정리 '+temporaryCompleted+'건 완료 · 최종 확정을 마지막에 1회 진행합니다.';}
          var finalized=await finalizeProductAiDraft({internal:true,aiRunToken:aiRunToken});queueSyncedTotal=Number(finalized.synced||0);queueFailedTotal=Number(finalized.failed||0);queueRemaining=Number(finalized.remaining||0);
        }else if(state){state.className='product-auto-state complete';state.textContent=label+' 임시 정리 '+temporaryCompleted+'건 완료 · 후보 원장 최종 반영 전입니다. `AI 정리 최종 완료`를 누르면 한 번에 마무리합니다.';}
        var refreshed=await loadProductResearchPaged(selectedCountry,selectedSubdivision||'NATIONWIDE',{state:state,label:'AI 정리 후 관리 목록'});lastProductJson=refreshed;rememberReport('product',refreshed);renderProductProgress(refreshed);renderProducts(refreshed.products||[]);saveReviewSnapshot();syncProductAiFinalizeControl();
        var sm=refreshed.summary||{},globalUnassigned=Math.max(0,Number(sm.discovered||productRows.length)-Number(sm.slotCandidates||0)-Number(sm.held||0)-Number(sm.rejected||0)-Number(sm.permanentExcluded||0));
        result={assigned:assignedTotal,pendingEvidenceAssigned:pendingTotal,unassigned:globalUnassigned,held:heldTotal,manualPreserved:manualPreserved,changed:changedTotal,settlementReady:Number(sm.settlementReadyProducts||0),queueSynced:queueSyncedTotal,queueSyncFailed:queueFailedTotal,queueSyncRemaining:queueRemaining,temporaryCompletedItems:temporaryCompleted,temporary:!autoFinalizeDraft};
      }else{
        var pass=0,maxPasses=(sectionMode||repairMode||selectedMode)?1:10,previousRemaining=-1;
        do{
          pass+=1;if(state){state.className='product-auto-state running';state.textContent=label+' AI 자동 정리 '+pass+'단계 진행 중';}
          data=await api(CONTROL,'product_ai_automation','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:sectionMode?'section':(repairMode?'repair':(selectedMode?'products':'placement')),sectionKey:sectionMode?sectionKey:'',productIds:selectedMode?selectedIds:[],compactResponse:true});
          lastProductJson=Object.assign({},lastProductJson||{},data,{products:productRows,latestProducts:latestProductRows});rememberReport('product',lastProductJson);renderProductProgress(lastProductJson);saveReviewSnapshot();result=data.aiAutomationResult||{};
          var remaining=Number(result.enrichmentRemaining||0),attempted=Number(result.enrichmentAttempted||0);if(sectionMode||repairMode||selectedMode||remaining<=0||attempted<=0||pass>=maxPasses||remaining===previousRemaining)break;previousRemaining=remaining;
        }while(true);
        queueRemaining=Number(result.queueSyncRemaining||result.queueSyncDeferred||0);queueSyncedTotal=Number(result.queueSynced||0);queueFailedTotal=Number(result.queueSyncFailed||0);var queuePass2=0,queuePrevious2=queueRemaining;
        while(queueRemaining>0&&queueFailedTotal===0&&queuePass2<80){queuePass2+=1;if(state){state.className='product-auto-state running';state.textContent=label+' 배치 결과를 프론트 후보 원장에 소량 연결 중 · 남은 '+queueRemaining+'건';}var queueData2=await api(CONTROL,'product_ai_automation','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:'queue_sync',batchSize:10});var queueResult2=queueData2.aiAutomationResult||{};queueSyncedTotal+=Number(queueResult2.queueSynced||0);queueFailedTotal+=Number(queueResult2.queueSyncFailed||0);queueRemaining=Number(queueResult2.queueSyncRemaining||0);if(queueRemaining>=queuePrevious2&&Number(queueResult2.queueSynced||0)<=0)break;queuePrevious2=queueRemaining;}
        if(queuePass2>0){try{var refreshed2=await loadProductResearchPaged(selectedCountry,selectedSubdivision||'NATIONWIDE',{state:state,label:'AI 배치 후 관리 목록'});lastProductJson=refreshed2;rememberReport('product',refreshed2);renderProductProgress(refreshed2);renderProducts(refreshed2.products||[]);saveReviewSnapshot();}catch(_refreshError){}}
        result.queueSynced=queueSyncedTotal;result.queueSyncFailed=queueFailedTotal;result.queueSyncRemaining=queueRemaining;
      }
      if(result.temporary===true){if(state){state.className='product-auto-state complete';state.textContent='AI 임시 정리 '+Number(result.temporaryCompletedItems||0)+'건 완료 · 최종 확정 대기 '+queueRemaining+'건 · `AI 정리 최종 완료`를 누르면 정상 완료분만 확정합니다.';}show('10건 단위 AI 임시 정리를 완료했습니다. 아직 후보 원장 최종 확정 전이며 `AI 정리 최종 완료` 버튼으로 한 번에 마무리할 수 있습니다.','ok');}
      else{if(state){state.className='product-auto-state '+(queueFailedTotal||queueRemaining?'warn':'complete');state.textContent=automationResultText(result)+(queueSyncedTotal?' · 프론트 후보 연결 '+queueSyncedTotal+'건':'')+(queueRemaining?' · 후보 연결 대기 '+queueRemaining+'건':'')+(queueFailedTotal?' · 연결 재시도 필요 '+queueFailedTotal+'건':'')+' · 자동 공개·상품 수입·결제 없음';}show(automationResultText(result)+(queueSyncedTotal?' · 프론트 후보 '+queueSyncedTotal+'건 연결':'')+(queueRemaining?' · 남은 후보 연결 '+queueRemaining+'건은 `AI 정리 최종 완료`로 이어서 확정할 수 있습니다.':'')+'으로 정리했습니다. 잘못 분류된 항목만 카드 드롭다운으로 수정하면 관리자 결정이 AI보다 우선 고정됩니다.',queueFailedTotal||queueRemaining?'warn':'ok');}
    }catch(e){
      try{var savedAi=await loadProductResearchCompact(selectedCountry,selectedSubdivision||'NATIONWIDE');lastProductJson=mergeCompactProductStatus(savedAi);rememberReport('product',lastProductJson);renderProductProgress(lastProductJson);saveReviewSnapshot();}catch(_aiStatusError){}
      var draftNow=productAiDraft(lastProductJson),savedPending=Number(draftNow.pendingItems||0),finalizedOnError=null;if(autoFinalizeDraft&&savedPending>0){if(state){state.className='product-auto-state running';state.textContent='AI 자동 정리 오류 · 오류 직전 정상 완료분 '+savedPending+'건만 최종 확정 중';}finalizedOnError=await finalizeProductAiDraft({internal:true,aiRunToken:text(draftNow.runToken||aiRunToken)});}
      if(state){state.className='product-auto-state warn';state.textContent='AI 자동 정리 중단: '+(text(e&&e.message)||'알 수 없는 오류')+(finalizedOnError?' · 오류 직전 정상 완료분 '+Number(finalizedOnError.synced||0)+'건 최종 확정':' · 완료된 10건 단위 임시 저장은 보존')+' · 실패 묶음부터 재개 가능';}
      show((text(e&&e.message)||'AI 자동 정리에 실패했습니다.')+(finalizedOnError?' 오류 직전 정상 완료분까지만 최종 확정했습니다.':' 정상 완료된 10건 단위 임시 저장은 유지됩니다. `AI 정리 최종 완료`로 확정할 수 있습니다.')+' 실패한 묶음부터 재개할 수 있습니다.','fail');
    }finally{
      productAutomationActive=false;renderProducts(productRows);if(top)top.disabled=!(lastProductJson&&productRows.length);
    }
  }

  function pendingFrontManagementChanges(mode,sectionKey,productId,selection){
    var selectedSections=mode==='sections'?(Array.isArray(selection)?selection:[]):[],selectedProducts=mode==='candidates'?(Array.isArray(selection)?selection:[]):[],selectedProductMap={};
    selectedProducts.forEach(function(id){selectedProductMap[text(id)]=true;});
    var changes=[];
    productRows.forEach(function(row){
      var id=text(row&&row.id),candidateId=text(row&&row.candidateId||row&&row.id),currentKey=productPlacementKey(row),currentDecision=productDecision(row),value=text(productPlacementSelections[id]);
      if(!id||!value||value.indexOf('affiliate:')===0)return;
      var desiredDecision=value.indexOf('section:')===0?'slot_candidate':value,desiredKey=desiredDecision==='slot_candidate'?value.slice(8):'';
      var actuallyChanged=desiredDecision==='slot_candidate'?(currentDecision!=='slot_candidate'||desiredKey!==currentKey):(desiredDecision!==currentDecision||currentKey!=='');
      if(!actuallyChanged)return;
      var include=mode==='all';
      if(mode==='section')include=currentKey===sectionKey||desiredKey===sectionKey;
      else if(mode==='sections')include=selectedSections.indexOf(currentKey)>=0||selectedSections.indexOf(desiredKey)>=0;
      else if(mode==='candidate')include=id===text(productId)||candidateId===text(productId);
      else if(mode==='candidates')include=selectedProductMap[id]===true||selectedProductMap[candidateId]===true;
      if(!include)return;
      if(['slot_candidate','hold','reject','undecided','ai_reclassify'].indexOf(desiredDecision)<0)return;
      changes.push({id:id,candidateId:candidateId,row:row,decision:desiredDecision,placementKey:desiredKey,oldSectionKey:currentKey,newSectionKey:desiredKey});
    });
    return changes;
  }
  async function persistFrontManagementChanges(changes,state,label){
    changes=Array.isArray(changes)?changes:[];
    if(!changes.length)return{changedCount:0,changedCandidateIds:[],movedCandidateIds:[],releasedCandidateIds:[]};
    var groups={},changed=[],moved=[],released=[];
    changes.forEach(function(change){
      var key=change.decision+'|'+(change.placementKey||'');
      if(!groups[key])groups[key]={decision:change.decision,placementKey:change.placementKey||'',rows:[]};
      groups[key].rows.push(change);
    });
    var keys=Object.keys(groups);
    for(var g=0;g<keys.length;g++){
      var group=groups[keys[g]],ledgerRows=group.rows.filter(function(change){return change.row&&change.row.ledgerSource==='candidate';}),legacyRows=group.rows.filter(function(change){return !change.row||change.row.ledgerSource!=='candidate';});
      for(var off=0;off<ledgerRows.length;off+=100){
        var chunk=ledgerRows.slice(off,off+100),candidateIds=chunk.map(function(change){return text(change.candidateId);}).filter(Boolean);
        if(state)state.textContent=label+' · 관리자 변경사항 '+Math.min(off+chunk.length,ledgerRows.length)+'/'+ledgerRows.length+'건 원장 저장 중';
        var result=await api(CONTROL,'product_candidate_ledger_bulk_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateIds:candidateIds,decision:group.decision,placementKey:group.placementKey||''},45000);
        if(Number(result&&result.failed||0)>0){var error=new Error('관리자 변경사항 '+Number(result.failed||0)+'건 저장 실패');error.status=409;throw error;}
        chunk.forEach(function(change){changed.push(change.candidateId);if(change.decision==='slot_candidate')moved.push(change.candidateId);else released.push(change.candidateId);});
      }
      for(var i=0;i<legacyRows.length;i++){
        var change=legacyRows[i];
        await api(CONTROL,'product_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',productId:change.id,decision:group.decision,placementKey:group.placementKey||''},45000);
        changed.push(change.candidateId);if(change.decision==='slot_candidate')moved.push(change.candidateId);else released.push(change.candidateId);
      }
    }
    await refreshCandidateLedgerProducts({preserveResearchReport:true});
    changes.forEach(function(change){delete productPlacementSelections[change.id];});
    saveReviewSnapshot();
    return{changedCount:changes.length,changedCandidateIds:Array.from(new Set(changed.filter(Boolean))),movedCandidateIds:Array.from(new Set(moved.filter(Boolean))),releasedCandidateIds:Array.from(new Set(released.filter(Boolean)))};
  }
  async function runProductFrontSync(operation,mode,sectionKey,productId,selection){
    if(!selectedCountry||productFrontSyncActive)return;
    if(!lastProductJson){show('프론트에 매칭할 상품 조사 결과가 없습니다. 상품 조사를 먼저 실행해 주세요.','warn');return;}
    // Keep every administrator scope independent. A single section, selected
    // sections, selected products and all 18 sections resolve their own exact
    // target set here; only the final durable write/build machinery is shared.
    // Do not normalize section/all into another UI scope: that previously made
    // the controls behave as one chained action instead of separate commands.
    var unmatch=operation==='unmatch',sectionMode=mode==='section',sectionsMode=mode==='sections',candidateMode=mode==='candidate',candidatesMode=mode==='candidates',selectedSections=sectionsMode?(Array.isArray(selection)?selection:[]):[],selectedProducts=candidatesMode?(Array.isArray(selection)?selection:[]):[],selectedProduct=candidateMode?productById(productId):null,label=candidateMode?(text(selectedProduct&&selectedProduct.productName||selectedProduct&&selectedProduct.title||productId)+' · 상품 1건'):(candidatesMode?'선택 상품 '+selectedProducts.length+'건':(sectionsMode?(selectedSections.length===1?sectionLabel(selectedSections[0]):'선택 섹션 '+selectedSections.length+'개'):(sectionMode?sectionLabel(sectionKey):'18개 전체 섹션'))),confirmation=unmatch?'SITE_UNPUBLISH':'SITE_PUBLISH';
    if(sectionsMode&&!selectedSections.length){show('매칭할 섹션을 먼저 선택해 주세요.','warn');return;}if(candidatesMode&&!selectedProducts.length){show('매칭할 상품을 먼저 선택해 주세요.','warn');return;}
    var replacementRun=!unmatch&&(mode==='all'||sectionMode||sectionsMode),pendingManagement=unmatch?[]:pendingFrontManagementChanges(mode,sectionKey,productId,selection),selectedProductMap={};selectedProducts.forEach(function(id){selectedProductMap[text(id)]=true;});
    var targetRows=productRows.filter(function(row){
      var key=assignedSectionKey(row),id=text(row&&row.id),placed=productDecision(row)==='slot_candidate'&&!!key;
      // The 18-section board owns only rows that still have a valid placement.
      // Match and unmatch are publication controls, not assignment controls:
      // matching requires a placed row; unmatching requires that same placed
      // row to have an active/pending publication marker.
      if(!key)return false;
      // Matching may also repair a row whose durable publication marker is
      // already live/pending.  Scope selection is still exact because a valid
      // assigned section key is required above.
      var eligible=unmatch?(placed&&frontPublicationActive(row)):(placed||frontPublicationLive(row));
      if(!eligible)return false;
      if(candidateMode)return id===text(productId);
      if(candidatesMode)return selectedProductMap[id]===true;
      if(sectionMode)return key===sectionKey;
      if(sectionsMode)return selectedSections.indexOf(key)>=0;
      return true;
    });
    var targetIds=targetRows.map(function(row){return text(row.id);}).filter(Boolean);
    if(!targetIds.length&&!pendingManagement.length&&!replacementRun){show(unmatch?'선택 범위에 매칭 해제할 상품이 없습니다.':'선택 범위에 최종 재검증·프론트 적용할 상품이 없습니다.','warn');return;}
    var explanation=unmatch?label+'의 기존 프론트 매칭 해제를 요청합니다.':label+'의 현재 배치 상품을 프론트 공개 원장에 적용합니다.'+(pendingManagement.length?' 화면에서 바꾼 관리자 위치·상태 '+pendingManagement.length+'건을 먼저 원장에 확정 저장합니다.':'')+' 최근 검증이 살아 있는 상품은 저장된 검증을 재사용하고, 오래됐거나 실제 공개 중인 상품만 다시 확인합니다. 삭제·잘못된 접근·판매처 홈 리다이렉트 상품은 제거하고 대체 후보가 없으면 기존 샘플 fallback을 유지합니다.';
    if(!window.confirm(explanation+'\n\n'+(unmatch?'프론트에서 해당 매칭을 해제하시겠습니까?\n변경은 소량 묶음으로 저장한 뒤 마지막에 스냅샷 빌드를 1회만 실행합니다.':'프론트 실상품 매칭 절차를 실행하시겠습니까?\n선택 범위는 현재 관리자 원장을 기준으로 다시 구성합니다. 기존 실상품은 최신 배치로 치환되고 남는 슬롯은 샘플로 복귀합니다. 마지막 빌드는 1회만 실행합니다.')))return;
    productFrontSyncActive=true;
    var state=$('productFrontSyncState'),batchSize=8,maxConcurrent=2,requestTimeout=75000,aggregate={requested:0,queued:0,persisted:0,pendingBuild:0,blocked:0,revalidated:0,remoteChecked:0,freshReused:0,invalid:0,inconclusive:0,withdrawn:0,changedSection:0,items:[],persistedCandidateIds:[],changedCandidateIds:[],preparation:{requested:0,prepared:0,blocked:0},batchErrors:[]},publishPersistedMap={},changedMap={},completed=0,managementCommit={changedCount:0,changedCandidateIds:[],movedCandidateIds:[],releasedCandidateIds:[]};
    if(state){state.className='front-sync-state running';state.textContent=label+' '+(unmatch?'매칭 해제':'프론트 실상품 매칭')+' · '+targetIds.length+'건을 처리합니다. 최근 정상 검증은 재사용하고 필요한 상품만 다시 확인합니다.';}
    renderProducts(productRows);
    try{
      if(pendingManagement.length){
        if(state){state.className='front-sync-state running';state.textContent=label+' · 화면에서 바꾼 위치·상태 '+pendingManagement.length+'건을 관리자 원장에 먼저 저장합니다.';}
        managementCommit=await persistFrontManagementChanges(pendingManagement,state,label);
        (managementCommit.changedCandidateIds||[]).forEach(function(id){if(id)changedMap[text(id)]=true;});
        selectedProductMap={};selectedProducts.forEach(function(id){selectedProductMap[text(id)]=true;});
        targetRows=productRows.filter(function(row){
          var key=assignedSectionKey(row),id=text(row&&row.id),candidateId=text(row&&row.candidateId||row&&row.id),placed=productDecision(row)==='slot_candidate'&&!!key;
          if(!key)return false;
          var eligible=unmatch?(placed&&frontPublicationActive(row)):(placed||frontPublicationLive(row));
          if(!eligible)return false;
          if(candidateMode)return id===text(productId)||candidateId===text(productId);
          if(candidatesMode)return selectedProductMap[id]===true||selectedProductMap[candidateId]===true||(managementCommit.movedCandidateIds||[]).indexOf(candidateId)>=0;
          if(sectionMode)return key===sectionKey||(managementCommit.movedCandidateIds||[]).indexOf(candidateId)>=0;
          if(sectionsMode)return selectedSections.indexOf(key)>=0||(managementCommit.movedCandidateIds||[]).indexOf(candidateId)>=0;
          return true;
        });
        targetIds=Array.from(new Set(targetRows.map(function(row){return text(row&&row.candidateId||row&&row.id);}).filter(Boolean)));
      }
      var action=unmatch?'product_front_unmatch':'product_front_match',batches=[];
      for(var offset=0;offset<targetIds.length;offset+=batchSize)batches.push({offset:offset,ids:targetIds.slice(offset,offset+batchSize)});
      var nextBatch=0;
      async function requestFrontBatch(batch){
        var lastError=null;
        for(var attempt=0;attempt<2;attempt++){
          try{return await api(CONTROL,action,'POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',mode:'candidates',candidateIds:batch,ledgerMode:'candidate',confirmation:confirmation,deferRelease:true,scopeRefresh:false,compactResponse:true,reuseFreshValidation:true,freshValidationMinutes:720},requestTimeout);}
          catch(error){lastError=error;if(!isGatewayDelay(error)||attempt>0)throw error;if(state){state.className='front-sync-state running';state.textContent=label+' · 일시적인 게이트웨이 지연을 감지했습니다. 저장 원장을 버리지 않고 같은 묶음을 1회 재확인합니다.';}await new Promise(function(resolve){setTimeout(resolve,1200);});}
        }
        throw lastError||new Error('front_batch_failed');
      }
      async function processBatch(batchInfo){
        var batch=batchInfo.ids;
        try{
          var part=await requestFrontBatch(batch);
          var r=part.frontSyncResult||{},p=r.preparation||{},refresh=r.refresh||{};
          aggregate.requested+=Number(r.requested||p.requested||batch.length);aggregate.queued+=Number(r.queued||0);aggregate.persisted+=Number(r.persisted||0);aggregate.pendingBuild+=Number(r.pendingBuild||0);aggregate.blocked+=Number(r.blocked||p.blocked||0);aggregate.revalidated+=Number(refresh.revalidated||0);aggregate.remoteChecked+=Number(refresh.remoteChecked||0);aggregate.freshReused+=Number(refresh.freshReused||0);aggregate.invalid+=Number(refresh.invalid||0);aggregate.inconclusive+=Number(refresh.inconclusive||0);aggregate.withdrawn+=Number(refresh.withdrawn||refresh.withdrawRequested||0);aggregate.changedSection+=Number(refresh.changedSection||0);aggregate.items=aggregate.items.concat(Array.isArray(r.items)?r.items:[]);aggregate.preparation.requested+=Number(p.requested||0);aggregate.preparation.prepared+=Number(p.prepared||0);aggregate.preparation.blocked+=Number(p.blocked||0);aggregate.release=r.release||aggregate.release;
          (Array.isArray(r.items)?r.items:[]).forEach(function(item){var id=text(item&&item.candidateId),status=text(item&&item.status).toLowerCase();if(!id||!item||item.persisted!==true)return;changedMap[id]=true;if(!unmatch&&status==='publish_requested')publishPersistedMap[id]=true;});
          // The preparation ledger is the durable authority.  Do not let a
          // compact/repair response omit the final build simply because its
          // item array used a different status label.
          (Array.isArray(p.preparedCandidateIds)?p.preparedCandidateIds:[]).forEach(function(id){id=text(id);if(!id)return;changedMap[id]=true;if(!unmatch)publishPersistedMap[id]=true;});
          (Array.isArray(refresh.withdrawCandidateIds)?refresh.withdrawCandidateIds:[]).forEach(function(id){id=text(id);if(id)changedMap[id]=true;});
        }catch(batchFailure){
          aggregate.batchErrors.push({offset:batchInfo.offset,candidateIds:batch.slice(),message:text(batchFailure&&batchFailure.message)||'batch_failed'});aggregate.blocked+=batch.length;aggregate.items.push.apply(aggregate.items,batch.map(function(id){return{candidateId:id,status:'batch_failed',queued:false,persisted:false,reason:text(batchFailure&&batchFailure.message)||'batch_failed'};}));
        }finally{
          completed+=batch.length;
          if(state){state.className='front-sync-state running';state.textContent=label+' · '+Math.min(completed,targetIds.length)+'/'+targetIds.length+'건 저장 처리 · 최근 검증 재사용 '+aggregate.freshReused+'건 · 실제 재확인 '+aggregate.remoteChecked+'건 · 오류 묶음 '+aggregate.batchErrors.length+'건';}
        }
      }
      async function worker(){while(true){var index=nextBatch++;if(index>=batches.length)return;await processBatch(batches[index]);}}
      var workers=[];for(var w=0;w<Math.min(maxConcurrent,batches.length);w++)workers.push(worker());await Promise.all(workers);

      aggregate.persistedCandidateIds=Object.keys(publishPersistedMap);aggregate.changedCandidateIds=Array.from(new Set(Object.keys(changedMap).concat(managementCommit.changedCandidateIds||[])));
      var needsFinalize=aggregate.persistedCandidateIds.length>0||aggregate.changedCandidateIds.length>0||aggregate.withdrawn>0||Number(managementCommit.changedCount||0)>0||replacementRun;
      if(needsFinalize){
        try{
          if(state){state.className='front-sync-state running';state.textContent=label+' · 원장 저장 완료 · 전체 변경분 스냅샷 갱신을 마지막에 1회 요청 중';}
          var finalizeOperation=unmatch?'unmatch':(aggregate.persistedCandidateIds.length?'match':'refresh'),finalizeIds=Array.from(new Set((aggregate.persistedCandidateIds.length?aggregate.persistedCandidateIds:aggregate.changedCandidateIds).concat(managementCommit.changedCandidateIds||[])));
          var finalized=await api(CONTROL,'product_front_finalize','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',operation:finalizeOperation,confirmation:unmatch?'SITE_UNPUBLISH':'SITE_PUBLISH',candidateIds:finalizeIds,changedCount:Math.max(aggregate.changedCandidateIds.length,aggregate.withdrawn,aggregate.persistedCandidateIds.length),ledgerMode:'candidate',compactResponse:true},90000);
          var finalResult=finalized.frontSyncResult||{},finalRelease=finalResult.release||{};aggregate.finalize=finalResult;aggregate.release=finalRelease;if(finalRelease.queued===true){aggregate.queued=1;aggregate.pendingBuild=0;}else{aggregate.queued=0;aggregate.pendingBuild=Math.max(1,Number(finalResult.pendingBuild||aggregate.changedCandidateIds.length||aggregate.persistedCandidateIds.length||1));}
        }catch(finalizeFailure){aggregate.queued=0;aggregate.pendingBuild=Math.max(1,aggregate.pendingBuild||aggregate.changedCandidateIds.length||aggregate.persistedCandidateIds.length||1);aggregate.batchErrors.push({offset:'finalize',candidateIds:aggregate.changedCandidateIds.slice(),message:text(finalizeFailure&&finalizeFailure.message)||'finalize_failed'});}
      }
      try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_refreshFailure){}
      var result=aggregate,requested=Number(result.requested||0),prepared=Number(result.preparation&&result.preparation.prepared||0),queued=Number(result.queued||0),persisted=Number(result.persisted||0),pendingBuild=Number(result.pendingBuild||0),blocked=Number(result.blocked||0),reasonCounts={};
      (Array.isArray(result.items)?result.items:[]).forEach(function(item){if(!item||item.queued===true||item.persisted===true)return;var reason=text(item.reason)||text(item.status)||'blocked';reasonCounts[reason]=(reasonCounts[reason]||0)+1;});
      var topReasons=Object.keys(reasonCounts).sort(function(a,b){return reasonCounts[b]-reasonCounts[a];}).slice(0,3).map(function(reason){return reason+' '+reasonCounts[reason]+'건';}),reasonText=topReasons.length?' · 주요 차단: '+topReasons.join(' / '):'',batchErrorCount=result.batchErrors.length;
      var detail=' · 검증 재사용 '+Number(result.freshReused||0)+'건 · 실제 재확인 '+Number(result.remoteChecked||0)+'건 · 삭제/불량 '+Number(result.invalid||0)+'건 · 일시 확인보류 '+Number(result.inconclusive||0)+'건 · 기존 매칭 제거 '+Number(result.withdrawn||0)+'건 · 공개원장 준비 '+prepared+'건 · 원장 변경 '+result.changedCandidateIds.length+'건'+(queued?' · 최종 스냅샷 빌드 호출 1회':'')+(pendingBuild?' · 다음 배포 대기 '+pendingBuild+'건':'');
      if(state){state.className='front-sync-state '+(batchErrorCount||blocked||pendingBuild?'warn':'complete');state.textContent=label+' · 요청 '+requested+'/'+targetIds.length+'건 · 원장 변경 '+result.changedCandidateIds.length+'건 · 빌드 호출 '+queued+'건 · 차단 '+blocked+'건'+detail+reasonText+(batchErrorCount?' · 묶음 오류 '+batchErrorCount+'건(나머지는 계속 처리됨)':'');}
      var message=(unmatch?'프론트 매칭 해제':'프론트 실상품 갱신 적용')+' '+requested+'/'+targetIds.length+'건 처리 · 검증 재사용 '+Number(result.freshReused||0)+'건 · 실제 재확인 '+Number(result.remoteChecked||0)+'건 · 삭제/불량 '+Number(result.invalid||0)+'건 · 기존 매칭 제거 '+Number(result.withdrawn||0)+'건 · 원장 변경 '+result.changedCandidateIds.length+'건.';
      if(queued)message+=' 전체 변경분을 반영하는 스냅샷 빌드를 마지막에 1회 호출했습니다.';if(pendingBuild)message+=' 다음 정상 배포 대기 '+pendingBuild+'건.';if(blocked)message+=' 안전 게이트/묶음 차단 '+blocked+'건.'+reasonText;if(batchErrorCount)message+=' 묶음 오류 '+batchErrorCount+'건은 기록했으며 다른 상품 처리는 중단하지 않았습니다.';show(message,batchErrorCount||blocked||pendingBuild?'warn':'ok');
    }finally{productFrontSyncActive=false;renderProducts(productRows);syncFrontSelectionControls();}
  }

  function readProductPauseAutoQueue(){try{return localStorage.getItem(PRODUCT_PAUSE_AUTO_QUEUE_KEY)==='1';}catch(_e){return false;}}
  function saveProductPauseAutoQueue(value){productPauseAutoQueue=value===true;try{localStorage.setItem(PRODUCT_PAUSE_AUTO_QUEUE_KEY,productPauseAutoQueue?'1':'0');}catch(_e){}syncProductQueueStageControls();}
  function ensureProductQueueStageControls(){
    var ai=$('productAiAutoBtn');if(!ai||!ai.parentNode)return;
    var actions=ai.parentNode,manual=$('productQueueStageCurrentBtn'),auto=$('productQueueAutoBtn');
    if(!manual){manual=document.createElement('button');manual.id='productQueueStageCurrentBtn';manual.type='button';manual.className='secondary';manual.disabled=true;manual.textContent='현재 조사분 대기열 등록';actions.insertBefore(manual,ai);}
    if(!auto){auto=document.createElement('button');auto.id='productQueueAutoBtn';auto.type='button';auto.className='ghost';auto.textContent='일시정지 자동 대기열: OFF';actions.insertBefore(auto,ai);}
    if(!$('productQueueStageState')){var state=document.createElement('div');state.id='productQueueStageState';state.className='product-auto-state';state.textContent='리서치 완료 후 또는 서버 일시정지 확인 후 현재 조사분 대기열 등록 버튼이 활성화됩니다. 리서치와 대기열 저장은 서로 분리되어 동시에 DB를 쓰지 않습니다.';var anchor=$('productAiAutomationState');if(anchor&&anchor.parentNode)anchor.parentNode.insertBefore(state,anchor);else actions.parentNode.insertBefore(state,actions.nextSibling);}
    productPauseAutoQueue=readProductPauseAutoQueue();
  }
  function currentResearchQueueEligible(data){data=data||lastProductJson||{};return Number(data.summary&&data.summary.privateResearchQueueEligible||data.pipeline&&data.pipeline.partialQueue&&data.pipeline.partialQueue.eligible||0);}
  function currentResearchQueueInspected(data){data=data||lastProductJson||{};return Number(data.summary&&data.summary.inspected||0);}
  function syncProductQueueStageControls(){
    var manual=$('productQueueStageCurrentBtn'),auto=$('productQueueAutoBtn'),state=$('productQueueStageState'),pauseButton=$('productResearchPauseBtn'),status=text(lastProductJson&&lastProductJson.status),eligible=currentResearchQueueEligible(lastProductJson),inspected=currentResearchQueueInspected(lastProductJson),stageSummary=lastProductJson&&lastProductJson.pipeline&&lastProductJson.pipeline.stageSummary||{},failed=Number(stageSummary.failed||0),readyState=(productPausedForQueue&&productPauseServerConfirmed)||status==='complete',resumable=['discovering','inspecting','staging'].indexOf(status)>=0;
    if(manual)manual.disabled=productQueueStageActive||productLoopActive||!selectedCountry||!readyState||Math.max(eligible,inspected)<=0;if(pauseButton)pauseButton.disabled=!selectedCountry||productQueueStageActive||!resumable||(productPausedForQueue&&productPauseServerConfirmed);
    if(auto){auto.disabled=productQueueStageActive||!selectedCountry;auto.textContent='일시정지 자동 대기열: '+(productPauseAutoQueue?'ON':'OFF');}
    if(state&&!productQueueStageActive){state.textContent=status==='complete'?'리서치 완료 · 검증 완료 상품 '+Math.max(eligible,inspected)+'건 · 현재 조사분 대기열 등록 버튼으로 비공개 대기열에 등록할 수 있습니다.':(productPausedForQueue&&productPauseServerConfirmed?'서버 일시정지 확인 완료 · 현재까지 검증 완료 상품 '+Math.max(eligible,inspected)+'건 · '+(productPauseAutoQueue?'자동 대기열 등록 ON':'현재 조사분 수동 등록 가능'):'리서치 진행 중 · 대기열 등록은 완료 또는 서버 일시정지 확인 뒤 활성화됩니다.');}
  }
  function productPauseCheckpoint(){var row=lastProductJson||{};return{jobId:row.jobId||null,status:row.status||'not_started',startedAt:row.startedAt||null,finishedAt:row.finishedAt||null,updatedAt:row.updatedAt||null,scope:scopeSnapshot('product-pause'),progress:row.progress||{},summary:row.summary||{},pipeline:row.pipeline||{},lastError:row.lastError||null};}
  async function requestProductPause(){
    if(!selectedCountry||productStopRequested)return productPauseServerConfirmed;var requested=scopeSnapshot(),button=$('productResearchPauseBtn');productStopRequested=true;productPausedForQueue=true;productPauseServerConfirmed=false;if(button)button.disabled=true;syncProductQueueStageControls();if($('productResearchState'))$('productResearchState').textContent='상품 조사 일시정지 요청을 별도 실행 원장에 저장하고 현재 처리 중인 한 묶음의 안전 종료를 기다리는 중입니다.';
    var saved=false,lastError=null;
    for(var attempt=0;attempt<3&&!saved;attempt++){
      try{var result=await api(CONTROL,'product_research_pause_control','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:lastProductJson&&lastProductJson.jobId||'',mode:'pause',automaticQueue:productPauseAutoQueue,checkpoint:productPauseCheckpoint()},8000);if(result&&result.pause&&result.pause.paused===true){lastProductJson=Object.assign({},lastProductJson||{},{pause:result.pause});productPauseServerConfirmed=true;saved=true;}}
      catch(e){lastError=e;if(attempt<2)await new Promise(function(resolve){setTimeout(resolve,400+attempt*500);});}
    }
    if(saved){show('일시정지 요청을 별도 실행 원장에 저장했습니다. 현재 처리 중인 묶음까지만 정리한 뒤 '+(productPauseAutoQueue?'검증 완료분을 자동 대기열 등록합니다.':'수동 대기열 등록 버튼을 활성화합니다.'),'warn');}
    else{show((text(lastError&&lastError.message)||'일시정지 제어 요청 응답이 지연됐습니다.')+' 브라우저의 중단 요청은 유지하고, 현재 묶음이 끝난 뒤 서버의 일시정지 저장을 다시 확인합니다.','warn');}
    syncProductQueueStageControls();return saved;
  }
  async function confirmProductPauseAfterLoop(requested){
    if(!productStopRequested)return true;if(productPauseServerConfirmed)return true;var checkpoint=productPauseCheckpoint(),jobId=lastProductJson&&lastProductJson.jobId||'';
    for(var attempt=0;attempt<3;attempt++){
      try{var result=await api(CONTROL,'product_research_pause_control','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:jobId,mode:'pause',automaticQueue:productPauseAutoQueue,checkpoint:checkpoint},8000);if(result&&result.pause&&result.pause.paused===true){productPauseServerConfirmed=true;productPausedForQueue=true;lastProductJson=Object.assign({},lastProductJson||{},{pause:result.pause});return true;}}
      catch(_pauseConfirmError){}
      try{var saved=await loadProductResearchCompact(requested.country,requested.region);if(saved&&saved.pause&&saved.pause.paused===true){lastProductJson=mergeCompactProductStatus(saved);productPauseServerConfirmed=true;productPausedForQueue=true;return true;}}catch(_pauseStatusError){}
      if(attempt<2)await new Promise(function(resolve){setTimeout(resolve,600*(attempt+1));});
    }
    productPauseServerConfirmed=false;return false;
  }
  async function stageCurrentResearchQueue(options){
    options=options||{};if(!selectedCountry||productQueueStageActive)return null;
    var requested=options.requested||scopeSnapshot(),requestedKey=scopeKey(requested),state=$('productQueueStageState'),automatic=options.automatic===true,lastResult=null,totalAttempted=0,totalHandled=0,totalFailed=0,previousRemaining=null,stalled=0,maxPasses=320;
    productQueueStageActive=true;syncProductQueueStageControls();
    if(state)state.textContent=(automatic?'일시정지 자동 대기열 등록':'현재 조사분 수동 대기열 등록')+'을 시작합니다. 상품 점검이 완료된 항목만 10건 단위로 안전 등록합니다.';
    try{
      for(var pass=0;pass<maxPasses;pass++){
        if(scopeKey()!==requestedKey)throw new Error('대기열 등록 중 선택 범위가 변경됐습니다.');
        var result=null,requestError=null;
        for(var attempt=0;attempt<3&&!result;attempt++){
          try{result=await api(CONTROL,'product_research_stage_current','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:lastProductJson&&lastProductJson.jobId||'',source:automatic?'pause_auto':'administrator_manual'},20000);}
          catch(e){requestError=e;if(attempt<2)await new Promise(function(resolve){setTimeout(resolve,600*(attempt+1));});}
        }
        if(!result)throw requestError||new Error('현재 조사분 대기열 등록 요청이 중단됐습니다.');
        var part=result&&result.partialQueue||{};lastResult=result;
        if(part.migration===true){
          if(state)state.textContent='기존 대용량 상품 원장을 국가·지역 분할 원장으로 안전 전환 중 · '+Number(part.migrated||0)+'/'+Number(part.migrationTotal||0)+'건 · 리서치 진행점과 기존 후보 원장은 유지됩니다.';
          previousRemaining=null;stalled=0;await new Promise(function(resolve){setTimeout(resolve,180);});continue;
        }
        totalAttempted+=Number(part.attempted||0);totalHandled+=Number(part.handled||0);totalFailed+=Number(part.failed||0);
        var remaining=Number(part.remaining||0);if(state)state.textContent=(automatic?'자동':'수동')+' 대기열 등록 · 처리 '+Number(part.done||0)+'/'+Number(part.eligible||0)+' · 남음 '+remaining+(Number(part.failed||0)?' · 이번 등록 실패 '+Number(part.failed||0):'');
        if(part.complete===true||remaining<=0)break;
        if(previousRemaining!=null&&remaining>=previousRemaining&&Number(part.handled||0)<=0)stalled+=1;else stalled=0;previousRemaining=remaining;
        if(stalled>=4)throw new Error('대기열 등록이 반복 정체되어 저장된 체크포인트를 유지한 채 안전 중단했습니다.');
        if(Number(part.attempted||0)<=0){await new Promise(function(resolve){setTimeout(resolve,220);});continue;}
        await new Promise(function(resolve){setTimeout(resolve,180);});
      }
      if(lastResult&&lastResult.partialQueue&&lastResult.partialQueue.complete!==true&&Number(lastResult.partialQueue.remaining||0)>0)throw new Error('대기열 안전 반복 한도에 도달했습니다. 현재 저장 지점부터 다시 실행할 수 있습니다.');
      try{var saved=await loadProductResearchCompact(requested.country,requested.region);if(saved&&saved.status&&saved.status!=='not_started'){lastProductJson=mergeCompactProductStatus(saved);renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();}}catch(_statusError){}
      try{if(Number(lastProductJson&&lastProductJson.summary&&lastProductJson.summary.latestResearchProducts||0)>0)await refreshLatestResearchRows(requested.country,requested.region,{state:state,label:'최신 상품 리서치 목록'});}catch(_latestRefreshError){}
      try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_ledgerError){}
      lastScopeAuditJson=null;
      if(activeScopeAudit==='queue'){try{var queueAudit=await api(REVIEW,'diagnostic','GET',scopeParams());queueAudit.scope=auditScopeOf(queueAudit);renderScopeAudit(queueAudit,'queue');}catch(_queueAuditRefreshError){}}
      if(state){var remainingFinal=Number(lastResult&&lastResult.partialQueue&&lastResult.partialQueue.remaining||0);state.textContent=(automatic?'일시정지 자동':'현재 조사분 수동')+' 대기열 등록 '+(remainingFinal?'부분 완료':'완료')+' · 이번 요청 '+totalAttempted+'건 · 반영 '+totalHandled+'건'+(totalFailed?' · 실패 '+totalFailed+'건':'')+(remainingFinal?' · 남음 '+remainingFinal+'건':'');}
      show((automatic?'일시정지 시점까지의 검증 완료 상품을 자동':'현재 시점까지 검증 완료된 상품을 수동')+'으로 비공개 대기열에 등록했습니다.'+(totalFailed?' 실패 '+totalFailed+'건은 다음 등록에서 다시 시도할 수 있습니다.':''),totalFailed?'warn':'ok');
      return lastResult;
    }catch(e){if(state)state.textContent='현재 조사분 대기열 등록 중단: '+conciseRequestError(e&&e.message,e&&e.status);show(conciseRequestError(e&&e.message,e&&e.status),'warn');return null;}
    finally{productQueueStageActive=false;syncProductQueueStageControls();}
  }

  async function runProductResearch(options){
    options=options||{};if(!selectedCountry||productLoopActive)return;
    var requested=scopeSnapshot(),requestedKey=scopeKey(requested);
    if(lastProductJson&&text(lastProductJson.status)==='candidate_ledger'){
      try{var savedResearch=await loadProductResearchCompact(requested.country,requested.region);if(savedResearch&&['discovering','inspecting','staging'].indexOf(text(savedResearch.status))>=0&&savedResearch.progress&&savedResearch.progress.resumable===true){lastProductJson=mergeCompactProductStatus(savedResearch);renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();}}catch(_savedResearchError){}
    }
    var serverPaused=!!(lastProductJson&&lastProductJson.pause&&lastProductJson.pause.paused===true),serverResumable=!!(lastProductJson&&lastProductJson.progress&&lastProductJson.progress.resumable===true),resumePaused=(productPausedForQueue===true||serverPaused||serverResumable)&&lastProductJson&&['discovering','inspecting','staging'].indexOf(text(lastProductJson.status))>=0,hasPriorResearch=!!(lastProductJson&&lastProductJson.status&&lastProductJson.status!=='not_started');
    if(hasPriorResearch&&!resumePaused&&!options.automatic&&!window.confirm('기존에 리스트업된 상품과 관리자 판정은 그대로 둡니다. 현재 활성 공급업체 전체를 첫 업체부터 다시 리서치하고, 기존 상품과 정확히 중복되는 항목은 새 항목으로 추가하지 않으며 새로 발견된 상품만 기존 후보 원장에 누적합니다. 다시 시작하시겠습니까?'))return;
    hide();productStopRequested=false;productLoopActive=true;if(!resumePaused){productPausedForQueue=false;productPauseServerConfirmed=false;}var button=$('productResearchBtn');button.disabled=true;button.textContent='실상품 전체 재리서치 진행 중';setButtonEnabled('productResearchPauseBtn',true);if($('productResearchState'))$('productResearchState').textContent=(options.automatic?'공급업체 검증 완료 후 실상품 전체 재리서치를 자동으로 시작했습니다. ':'')+'리서치 버튼을 실행할 때마다 현재 비공개 공급업체 후보 전체를 다시 조사합니다. 기존 업체와 신규 업체를 구분해 집계하되 둘 다 공식 사이트를 리서치하며, 동일 상품은 기존 후보를 최신 상태로 갱신하고 신규 상품만 추가합니다.';
    var researchFailureText='',pauseAutoStageAfterLoop=false;
    try{
      var data;
      if(resumePaused){
        // Resume is a durable server transition. Do not continue a paused job
        // until the small runtime control row confirms resume.
        await api(CONTROL,'product_research_pause_control','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:lastProductJson&&lastProductJson.jobId||'',mode:'resume'},8000);
        data=await loadProductResearchCompact(requested.country,requested.region);productPausedForQueue=false;productPauseServerConfirmed=false;
        if($('productResearchState'))$('productResearchState').textContent='서버에 저장된 상품 리서치를 저장된 진행 지점부터 계속합니다. 이미 대기열에 등록한 상품은 중복 생성하지 않습니다.';
      }else{
        var baselineData=await refreshCandidateLedgerProducts({preserveResearchReport:true}),baselineCount=Array.isArray(baselineData&&baselineData.products)?baselineData.products.length:productRows.length;
        if($('productResearchState'))$('productResearchState').textContent='1차 · 저장된 상품 후보 원장 '+baselineCount+'건 유지 완료 · 2차 · 현재 책임 공급업체 비공개 후보 전체의 공식 상품 리서치를 시작합니다. 기존 업체도 재확인하고 신규 업체는 별도 집계합니다.';
        data=await api(CONTROL,'product_research_begin','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,restart:true,retryStaging:false,refreshSources:true,fullRescan:true,candidateLedgerBaseline:true,candidateLedgerBaselineCount:baselineCount},20000);
      }
      while(true){
        if(scopeKey()!==requestedKey){productStopRequested=true;show('상품 조사 중 선택 범위가 바뀌어 화면 진행을 중단했습니다. 서버 작업은 원래 범위에서 재개할 수 있습니다.','warn');break;}
        if(data&&data.compact===true){lastProductJson=Object.assign({},lastProductJson||{},data,{products:productRows});}
        else{lastProductJson=data;if(Array.isArray(data.products))renderProducts(data.products);rememberReport('product',data);saveReviewSnapshot();}
        renderProductProgress(lastProductJson);
        if(data.status==='complete'){
          productPausedForQueue=false;productPauseServerConfirmed=false;
          if(data.compact===true){data=await loadProductResearchPaged(requested.country,requested.region,{state:$('productResearchState'),label:'완료 상품 관리 목록'});lastProductJson=data;renderProducts(data.products||[]);try{var completedLatest=await loadLatestResearchPaged(requested.country,requested.region,{state:$('productResearchState'),label:'완료 최신 상품 목록',preserveOnFailure:true});if(completedLatest&&Array.isArray(completedLatest.rows)&&(completedLatest.rows.length||completedLatest.complete===true))latestProductRows=completedLatest.rows;}catch(_latestCompleteError){}lastProductJson=Object.assign({},data,{products:productRows,latestProducts:latestProductRows});renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();data=lastProductJson;}
          var completedProducts=Array.isArray(data.products)?data.products:productRows,queueEligible=Number(data.summary&&data.summary.privateResearchQueueEligible||0);
          show(completedProducts.length?'상품 리서치를 완료했습니다. 최신 상품 목록을 확인한 뒤 현재 조사분 대기열 등록 버튼을 누르면 검증 완료 상품 '+queueEligible+'건을 비공개 후보·중개수익 대기열로 순차 등록합니다.':'상품 리서치는 끝났지만 확인 가능한 실제 상품 목록을 만들지 못했습니다. 업체 공식 사이트와 JSON 경로를 점검하세요.',completedProducts.length?'ok':'warn');
          try{await refreshCandidateLedgerProducts({preserveResearchReport:true});}catch(_ledgerRefreshError){}
          break;
        }
        if(productStopRequested){productPausedForQueue=true;pauseAutoStageAfterLoop=productPauseAutoQueue===true;show('상품 조사를 일시정지했습니다. 지금까지의 결과는 관리 DB에 보존됐습니다.'+(productPauseAutoQueue?' 현재 처리 중인 요청이 끝난 뒤 검증 완료 상품을 자동으로 비공개 대기열에 등록합니다.':' 현재 조사분 대기열 등록 버튼으로 수동 등록할 수 있습니다.'),'warn');syncProductQueueStageControls();break;}
        await new Promise(function(resolve){setTimeout(resolve,300);});
        var stepError=null,stepCompleted=false,consecutiveGatewayFailures=0;
        while(!stepCompleted&&consecutiveGatewayFailures<3){
          var beforeMark=productProgressMark(lastProductJson||data);
          try{data=await api(CONTROL,'product_research_step','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:data.jobId,compact:true},20000);stepCompleted=true;}
          catch(requestError){
            stepError=requestError;var resumed=null;
            try{resumed=await loadProductResearchCompact(requested.country,requested.region);if(resumed&&resumed.status!=='not_started'){var afterMark=productProgressMark(resumed);lastProductJson=mergeCompactProductStatus(resumed);renderProductProgress(lastProductJson);rememberReport('product',lastProductJson);saveReviewSnapshot();if(afterMark!==beforeMark||resumed.status==='complete'){data=resumed;stepCompleted=true;break;}}}catch(_resumeError){}
            if(productStopRequested||(resumed&&resumed.pause&&resumed.pause.paused===true)){productPausedForQueue=true;if(resumed&&resumed.pause&&resumed.pause.paused===true)productPauseServerConfirmed=true;data=resumed||lastProductJson||data;stepCompleted=true;break;}
            if(!transientResearchRequestError(requestError))break;
            consecutiveGatewayFailures+=1;
            if(consecutiveGatewayFailures>=3){
              if($('productResearchState'))$('productResearchState').textContent='연속된 502/504/521·네트워크 지연을 감지했습니다. 무거운 요청 재시도를 중단하고 현재 체크포인트를 안전 일시정지로 전환합니다.';
              productPausePersistPromise=requestProductPause();try{await productPausePersistPromise;}catch(_safePauseError){}productPausePersistPromise=null;pauseAutoStageAfterLoop=productPauseAutoQueue===true;data=resumed||lastProductJson||data;stepCompleted=true;break;
            }
            if($('productResearchState'))$('productResearchState').textContent='일시적인 조사 응답 지연을 감지했습니다. 저장된 체크포인트를 확인했습니다. '+consecutiveGatewayFailures+'/3 · 잠시 뒤 다음 묶음을 재시도합니다.';
            await new Promise(function(resolve){setTimeout(resolve,900*consecutiveGatewayFailures);});
          }
        }
        if(!stepCompleted)throw stepError||new Error('상품 조사 단계를 안전 재시도했지만 완료하지 못했습니다.');
      }
    }
    catch(e){
      var recovered=false,saved=null;
      try{saved=await loadProductResearchCompact(requested.country,requested.region);if(saved&&saved.status&&saved.status!=='not_started'){lastProductJson=mergeCompactProductStatus(saved);renderProductProgress(lastProductJson);setButtonEnabled('productResearchDownloadBtn',true);saveReviewSnapshot();recovered=true;}}catch(_statusError){}
      var pauseRecovered=productStopRequested===true||!!(saved&&saved.pause&&saved.pause.paused===true);
      if(pauseRecovered){productPausedForQueue=true;if(saved&&saved.pause&&saved.pause.paused===true)productPauseServerConfirmed=true;pauseAutoStageAfterLoop=productPauseAutoQueue===true;if($('productResearchState'))$('productResearchState').textContent='일시정지 요청을 감지했습니다. 502/504/521 응답이 있었더라도 현재 묶음 종료 후 서버 저장 상태를 재확인합니다.';show('상품 조사 중단 요청을 복구했습니다. 서버 일시정지 저장이 확인된 뒤 '+(productPauseAutoQueue?'검증 완료분을 자동 대기열 등록합니다.':'현재 조사분 대기열 등록 버튼을 활성화합니다.'),'warn');}
      else{researchFailureText=(conciseRequestError(e&&e.message,e&&e.status)||'상품 리서치 요청이 중단됐습니다.')+(recovered?' · 서버에 저장된 진행 상태를 복구했습니다.':' · 기존 상품 후보 원장은 그대로 유지됐으며 공급업체 리서치 시작 단계에서 중단됐습니다.');if($('productResearchState'))$('productResearchState').textContent=researchFailureText;show(researchFailureText,'fail');}
    }
    finally{
      if(productPausePersistPromise){try{await productPausePersistPromise;}catch(_pausePersistError){}}
      productPausePersistPromise=null;
      if(productStopRequested&&!productPauseServerConfirmed){var pauseConfirmed=await confirmProductPauseAfterLoop(requested);if(!pauseConfirmed){productPausedForQueue=false;if($('productResearchState'))$('productResearchState').textContent='상품 조사 중단 요청은 유지됐지만 서버 일시정지 원장 저장 확인이 지연되고 있습니다. 대기열 등록은 중복 작업 방지를 위해 잠시 잠금 상태입니다. 상태 새로고침 후 다시 확인하세요.';show('서버 일시정지 저장을 아직 확인하지 못해 대기열 등록을 안전 잠금했습니다. 기존 조사 원장은 삭제하지 않습니다.','warn');}}
      productLoopActive=false;button.disabled=false;setButtonEnabled('productResearchPauseBtn',false);
      if((productPausedForQueue&&productPauseServerConfirmed)||text(lastProductJson&&lastProductJson.status)==='complete'){try{if(Number(lastProductJson&&lastProductJson.summary&&lastProductJson.summary.latestResearchProducts||0)>0)await refreshLatestResearchRows(requested.country,requested.region,{state:$('productResearchState'),label:'최신 상품 리서치 목록'});}catch(_latestPauseRefreshError){}}
      if(!researchFailureText&&productPauseServerConfirmed)renderProductProgress(lastProductJson||{});else if(!researchFailureText&&$('productResearchState')&&productPausedForQueue)$('productResearchState').textContent='상품 조사가 안전하게 일시정지됐습니다. 서버에 저장된 진행점부터 계속할 수 있습니다.';else if(researchFailureText&&$('productResearchState'))$('productResearchState').textContent=researchFailureText;renderProducts(productRows);syncProductQueueStageControls();
      // Queue registration starts only after the research loop has released its
      // active flag AND the durable pause row is confirmed, so the two workloads
      // never contend for the same function/DB after a gateway timeout.
      if(productPausedForQueue&&productPauseServerConfirmed&&pauseAutoStageAfterLoop)await stageCurrentResearchQueue({automatic:true,requested:requested});
    }
  }

  var SIGNAL_LABELS={local_products:'지역 생산품·협동조합',manufacturer_brands:'제조사·브랜드 상품',food_household_essentials:'식품·식료품·생활필수품',beauty_personal_care:'뷰티·개인용품',fashion:'의류·신발·가방',electronics_accessories:'전자제품·액세서리',home_appliances_living:'가전·주방·가구·생활',baby_family_education:'유아·가족·교육',agriculture_fishery_forestry:'농·수·임산물',travel_local_services:'여행·지역 서비스'};
  function renderActiveSignals(status){
    var effective=status&&status.effective||{},sources=Array.isArray(effective.sourcePlans)?effective.sourcePlans:[],weights=effective.categoryWeights||{},active=effective.active===true;
    var top=Object.keys(SIGNAL_LABELS).map(function(key){return{key:key,weight:Number(weights[key])||0};}).sort(function(a,b){return b.weight-a.weight;}).filter(function(row){return row.weight!==0;}).slice(0,3);
    var sourceText=sources.length?sources.map(function(row){return(row.type==='global'?'세계':'권역')+' · 유효 '+esc(row.validUntil||'-')+' · 감쇠 '+esc(row.decay==null?'-':row.decay);}).join(' / '):'적용된 세계·권역 AI 가중치 없음';
    $('activeSignalState').innerHTML=(active?'<span class="pill good">AI 방향 반영 중</span> ':'<span class="pill info">기본 순환</span> ')+sourceText+(top.length?'<br>우선 탐색: '+top.map(function(row){return esc(SIGNAL_LABELS[row.key])+' '+(row.weight>0?'+':'')+esc(row.weight)+'%';}).join(' · '):'');
  }
  function renderSignalReport(data){
    data=data||{};lastSignalReport=data;var scope=data.scope||{},regional=scope.type==='regional',weights=data.categoryWeights||{},signals=Array.isArray(data.signals)?data.signals:[],ai=data.ai||{},evidence=data.evidence||{},apply=data.apply||{},policy=data.policy||{};
    $('signalTitle').textContent=regional?'권역 AI 점검 결과 · '+(scope.regionNameKo||scope.regionNameEn||scope.regionGroup):'전 세계 흐름 AI 점검 결과';
    $('signalOverview').textContent=text(data.overview)||'AI 판단 요약이 없습니다.';
    $('signalMeta').innerHTML='AI '+esc(ai.provider||'-')+' · 확신도 '+esc(ai.confidence||0)+'% · 근거 '+esc(evidence.count||0)+'건 · 적용 기준 '+esc(apply.eligible?'충족':'미충족')+'<br>유효 권고 '+esc(apply.validUntil||'-')+' · 신뢰 게이트 변경 없음 · 상품 자동 반입 없음';
    $('signalWeights').innerHTML=Object.keys(SIGNAL_LABELS).map(function(key){var value=Number(weights[key])||0,cls=value>0?'weight-up':value<0?'weight-down':'weight-zero';return'<div class="weight-row"><span>'+esc(SIGNAL_LABELS[key])+'</span><span class="'+cls+'">'+(value>0?'+':'')+esc(value)+'%</span></div>';}).join('');
    $('signalEvents').innerHTML=signals.length?signals.map(function(row){var audiences=Array.isArray(row.audiences)?row.audiences.join(', '):'',risks=Array.isArray(row.risks)?row.risks.join(', '):'';return'<article class="signal-row"><strong>'+esc(row.title||row.type||'신호')+'</strong> <span class="pill '+(Number(row.confidence)>=75?'good':'info')+'">확신 '+esc(row.confidence||0)+'%</span><div class="small">'+esc(row.geography||'')+(row.horizon?' · '+esc(row.horizon):'')+'<br>'+esc(row.summary||'')+(audiences?'<br>대상층: '+esc(audiences):'')+(risks?'<br>주의: '+esc(risks):'')+'</div></article>';}).join(''):'<div class="small">근거가 충분한 주요 신호가 없습니다.</div>';
    var confidenceMinimum=Number(policy.confidenceMinimum||60),evidenceMinimum=Number(policy.evidenceMinimum||3),nonZero=Object.keys(weights).filter(function(key){return Number(weights[key])!==0;}).length,expired=!!(apply.validUntil&&Date.parse(apply.validUntil)<=Date.now()),reasons=[];
    if(ai.provider!=='openai')reasons.push('OpenAI 구조화 분석 미완료');
    if(Number(ai.confidence||0)<confidenceMinimum)reasons.push('AI 확신도 '+Number(ai.confidence||0)+'% / 최소 '+confidenceMinimum+'%');
    if(Number(evidence.count||0)<evidenceMinimum)reasons.push('확인 근거 '+Number(evidence.count||0)+'건 / 최소 '+evidenceMinimum+'건');
    if(!signals.length)reasons.push('근거에 연결된 유효 신호 없음');
    if(!nonZero)reasons.push('변경할 품목군 비중 없음');
    if(expired)reasons.push('권고 유효기간 만료');
    var eligible=apply.eligible===true&&!expired,reasonsFromServer=Array.isArray(apply.blockingReasons)?apply.blockingReasons:[];if(reasonsFromServer.length)reasons=reasonsFromServer;
    $('applySignalBtn').disabled=!eligible;$('applySignalBtn').title=eligible?'관리자가 확인한 AI 권고를 품목군 탐색 비중에만 반영합니다.':'안전 잠금: '+(reasons.join(' · ')||text(apply.reason)||'적용 기준 미충족');
    var state=$('signalApplyState');if(state){state.className='signal-apply-state '+(eligible?'ready':'blocked');state.textContent=eligible?'운영 반영 가능: 근거·확신도·유효 신호·비중 변화 기준을 통과했습니다. 관리자 확인 후 반영할 수 있습니다.':'운영 반영 안전 잠금: '+(reasons.join(' · ')||text(apply.reason)||'적용 기준을 통과하지 못했습니다.')+' JSON 다운로드와 수동 검토는 계속 가능합니다.';}
    $('signalPanel').classList.remove('hidden');
    rememberReport(data&&data.reportType==='igdc-regional-market-signal-check'?'regional':'global',data);
  }
  function signalProgressElement(type){return $(type==='regional'?'regionalSignalProgress':'globalSignalProgress');}
  function rememberSignalJob(type,data){if(!data)return;var regional=type==='regional';if(regional){lastRegionalJson=data;setButtonEnabled('regionalSignalDownloadBtn',true);}else{lastGlobalJson=data;setButtonEnabled('globalSignalDownloadBtn',true);}setButtonEnabled('downloadSignalJsonBtn',true);}
  function renderSignalJobProgress(type,data){
    data=data||{};var p=data.progress||{},collection=p.collection||{},analysis=p.analysis||{},status=text(data.status||'not_started'),labels={not_started:'시작 전',collecting:'근거를 출처별로 수집 중',analyzing:'수집 근거 AI 분석 중',complete:'AI 점검 완료'},el=signalProgressElement(type),message=(labels[status]||status)+' · 근거 수집 '+Number(collection.done||0)+'/'+Number(collection.total||0)+' · AI 분석 '+Number(analysis.done||0)+'/'+Number(analysis.total||1);
    if(data.evidence)message+=' · 확인 근거 '+Number(data.evidence.count||0)+'건';if(data.lastError)message+=' · 최근 오류 '+text(data.lastError.message||data.lastError);
    if(el)el.textContent=message;
    $('signalPanel').classList.remove('hidden');$('signalTitle').textContent=type==='regional'?'권역 AI 단계별 점검 · '+(data.scope&&data.scope.regionNameKo||data.scope&&data.scope.regionNameEn||selectedRegion):'전 세계 흐름 AI 단계별 점검';$('signalOverview').textContent=status==='complete'?'분석 결과를 정리했습니다.':message;$('signalMeta').textContent='각 검색 경로와 AI 분석을 별도 요청으로 저장합니다. 중간에 중단되어도 같은 버튼으로 이어서 진행합니다.';
  }
  async function runMarketSignal(type){
    var regional=type==='regional',btn=regional?$('regionalSignalBtn'):$('globalSignalBtn'),regionAtStart=selectedRegion;if(regional&&!regionAtStart){show('먼저 권역을 선택해 주세요.','warn');return;}if(signalLoopActive)return;hide();signalLoopActive=true;btn.disabled=true;var originalText=btn.textContent,params={scopeType:regional?'regional':'global',regionGroup:regional?regionAtStart:null};
    try{
      var existing=regional?lastRegionalJson:lastGlobalJson,restart=!!(existing&&existing.status==='complete'&&existing.report);if(restart&&!window.confirm((regional?'선택 권역':'전 세계')+' AI 점검을 새로 시작하시겠습니까? 이전 결과는 관리 DB에 보존됩니다.'))return;
      var data=await api(CONTROL,'signal_research_begin','POST',{},Object.assign({},params,{restart:restart}));
      while(true){
        if(regional&&selectedRegion!==regionAtStart){show('점검 중 선택 권역이 바뀌어 화면 진행을 중단했습니다. 원래 권역 작업은 저장돼 있습니다.','warn');break;}
        rememberSignalJob(type,data);renderSignalJobProgress(type,data);var pr=data.progress&&data.progress.collection||{};btn.textContent=(regional?'권역':'세계')+' 점검 '+Number(pr.done||0)+'/'+Number(pr.total||0);
        if(data.status==='complete'){var report=data.report||data;renderSignalReport(report);rememberReport(type,report);show((regional?'권역 상황':'전 세계 흐름')+' AI 점검을 완료했습니다. JSON 다운로드가 활성화됐습니다.',report.apply&&report.apply.eligible?'ok':'warn');break;}
        await new Promise(function(resolve){setTimeout(resolve,450);});data=await api(CONTROL,'signal_research_step','POST',{},params);
      }
    }catch(e){
      try{var saved=await api(CONTROL,'signal_research_status','GET',{scopeType:regional?'regional':'global',regionGroup:regional?regionAtStart:''});rememberSignalJob(type,saved);renderSignalJobProgress(type,saved);if(saved.status==='complete'&&saved.report){renderSignalReport(saved.report);rememberReport(type,saved.report);}}catch(_statusError){}
      show((text(e.message)||'세계·권역 AI 점검 요청이 중단됐습니다.')+' 완료된 근거 수집 단계는 관리 DB에 보존됐습니다. 같은 버튼으로 이어서 진행하세요.','fail');
    }finally{signalLoopActive=false;btn.disabled=false;btn.textContent=originalText;}
  }
  async function applyMarketSignal(){
    if(!lastSignalReport)return;var scope=lastSignalReport.scope||{};if(scope.type==='regional'&&scope.regionGroup!==selectedRegion){show('현재 선택 권역과 점검 결과 권역이 다릅니다. 해당 권역을 다시 선택해 점검해 주세요.','warn');return;}$('applySignalBtn').disabled=true;
    try{var data=await api(CONTROL,'market_signal_apply','POST',{}, {report:lastSignalReport});show('AI 세계·권역 권고를 품목군 탐색 비중에 반영했습니다. 신뢰도·업체 승인·상품 공개 조건은 변경하지 않았습니다.','ok');var status=await api(CONTROL,'signal_status','GET',{regionGroup:selectedRegion});renderActiveSignals(status);presentJson({reportType:lastSignalReport.reportType,scope:lastSignalReport.scope,generatedAt:new Date().toISOString(),appliedResult:data,sourceReport:lastSignalReport});}catch(e){$('applySignalBtn').disabled=!(lastSignalReport.apply&&lastSignalReport.apply.eligible);show(text(e.message)||'AI 권고 반영에 실패했습니다.','fail');}
  }

  function setPresetButtons(disabled){['globalAutoModeBtn','globalPauseBtn'].forEach(function(id){var el=$(id);if(el)el.disabled=!!disabled;});}
  async function applyOperatingPreset(preset){
    if(preset==='global_auto'&&!window.confirm('지원되는 전 세계 국가를 자동 운영으로 전환합니다. 기존 권역·국가·지역 예외 설정은 상속으로 정리됩니다. 계속하시겠습니까?'))return;
    if(preset==='global_pause'&&!window.confirm('전체 예약 자동화를 중지합니다. 기존 후보와 점검 기록은 보존됩니다. 계속하시겠습니까?'))return;
    hide();setPresetButtons(true);
    try{
      var data=await api(CONTROL,'operating_preset_apply','POST',{}, {preset:preset});
      presentJson(data);
      await reloadData(false);
      var messages={global_auto:'지원되는 전 세계 국가 자동 운영을 시작했습니다. 시간당 순환 처리되며 기존 후보와 관리자 기록은 보존됩니다.',global_pause:'전체 예약 자동화를 중지했습니다. 기존 후보·점검 기록과 국가별 세부 설정은 보존됩니다.'};
      show(messages[preset]||'운영 설정을 반영했습니다.','ok');
    }catch(e){show(text(e.message)||'운영 전환 설정을 반영하지 못했습니다.','fail');}
    finally{setPresetButtons(false);}
  }

  function renderResearchProgress(data){
    if(!data)return;var p=data.progress||{},s=p.search||{},i=p.inspection||{},r=p.ranking||{},status=text(data.status||'not_started'),labels={not_started:'시작 전',searching:'검색 경로 조사',inspecting:'업체 페이지 증빙 조사',ranking:'AI 신뢰 평가',complete:'검색·증빙·AI 평가 완료',committed:'비공개 후보 원장 실행 완료'};
    if($('countryResearchProgress')){var sm=data.summary||{},preserved=Number(sm.preservedExisting||0),newTarget=Number(sm.newCandidateTarget||0),newRanked=Number(sm.newRanked||0),targetTotal=Number(sm.targetTotalCandidates||0);$('countryResearchProgress').textContent=(labels[status]||status)+' · 검색 '+Number(s.done||0)+'/'+Number(s.total||0)+' · 증빙 '+Number(i.done||0)+'/'+Number(i.total||0)+' · AI 평가 '+Number(r.done||0)+'/'+Number(r.total||0)+' · 기존 보존 '+preserved+(targetTotal?' · 목표 '+targetTotal:'')+(targetTotal?' · 신규 목표 '+newTarget+' · 신규 확보 '+newRanked:'')+' · 최종 후보 '+Number(sm.ranked||0)+(sm.duplicateResearchSkipped===true?' · 기존 업체 중복 리서치 없음':'')+(data.lastError?' · 최근 오류: '+text(data.lastError.message):'');}
    var complete=status==='complete'||status==='committed';setButtonEnabled('runNowBtn',complete&&Array.isArray(data.candidates)&&data.candidates.length>0);if($('previewRunBtn'))$('previewRunBtn').textContent=researchLoopActive?('정상 진행 중 · '+(labels[status]||status)):complete?'새 책임 공급업체 검색':(p.resumable?'책임 공급업체 검색 계속':'책임 공급업체 단계별 검색');
  }
  function isGatewayDelay(error){var status=Number(error&&error.status)||0;return status===502||status===503||status===504;}
  async function readScopePart(label,endpoint,action,params,fallback){
    var lastError=null;
    for(var attempt=0;attempt<2;attempt++){
      try{return{ok:true,label:label,data:await api(endpoint,action,'GET',params||{})};}
      catch(error){lastError=error;if(!isGatewayDelay(error)||attempt>0)break;await new Promise(function(resolve){setTimeout(resolve,900);});}
    }
    return{ok:false,label:label,data:fallback,error:lastError};
  }
  async function loadScope(reason){
    if(!selectedCountry)return;var passive=reason==='restore-passive';if(!passive)hide();$('refreshScopeBtn').disabled=true;
    var requested=scopeParams(),requestedKey=scopeKey(requested),failures=[];
    var cachedScope=lastScopeCache&&lastScopeCache.scope||{},sameCachedScope=lastScopeCache&&scopeKey(cachedScope)===requestedKey;
    var cachedScopeData=sameCachedScope&&lastScopeCache.scopeData||null,cachedQueueData=sameCachedScope&&lastScopeCache.queueData||null,cachedResearchData=sameCachedScope&&lastScopeCache.researchData||null;
    var scopeFallback=cachedScopeData||{ok:true,country:country(requested.country),effective:effective(requested.country,requested.region==='NATIONWIDE'?'':requested.region),marketSignals:{},candidates:[]};
    var researchFallback=cachedResearchData||{ok:true,status:'not_started',candidates:[],summary:{},progress:{}};
    var cachedProductData=sameCachedScope&&lastScopeCache.productData||null;
    var directProductScope=lastProductJson&&lastProductJson.scope||{},cachedProductScope=cachedProductData&&cachedProductData.scope||{};
    var preservedProductData=text(directProductScope.country).toUpperCase()===requested.country&&text(directProductScope.region||'NATIONWIDE').toUpperCase()===requested.region?lastProductJson:(text(cachedProductScope.country).toUpperCase()===requested.country&&text(cachedProductScope.region||'NATIONWIDE').toUpperCase()===requested.region?cachedProductData:null);
    var productFallback=preservedProductData||{ok:true,status:'not_started',products:[],summary:{},progress:{}};
    try{
      var scopePart=await readScopePart('국가 책임 공급업체 원장',CONTROL,'scope',requested,scopeFallback);if(scopeKey()!==requestedKey)return;
      var scopeData=scopePart.data||scopeFallback;if(!scopePart.ok)failures.push(scopePart);
      renderAi(scopeData.candidates||[]);renderActiveSignals(scopeData.marketSignals||{});

      /* Candidate summary + rows share the same live DB projection. Read them once. */
      var queueFallback=cachedQueueData||{ok:true,summary:{},candidates:[]};
      var queuePart=await readScopePart('상품 후보 원장',REVIEW,'dashboard',Object.assign({},requested,{compact:'1'}),queueFallback);if(scopeKey()!==requestedKey)return;
      if(!queuePart.ok)failures.push(queuePart);var queueData=queuePart.data||queueFallback;renderSummary(queueData&&queueData.summary||{},scopeData,'저장 원장 기준');renderQueue(queueData&&queueData.candidates||[]);

      var researchPart=await readScopePart('책임 공급업체 리서치',CONTROL,'research_status',requested,researchFallback);if(scopeKey()!==requestedKey)return;
      if(!researchPart.ok)failures.push(researchPart);var researchData=researchPart.data||researchFallback;renderResearchProgress(researchData);
      if((researchData.status==='complete'||researchData.status==='committed')&&((Array.isArray(researchData.candidates)&&researchData.candidates.length)||(Array.isArray(researchData.holdingCandidates)&&researchData.holdingCandidates.length)||(Array.isArray(researchData.blockedCandidates)&&researchData.blockedCandidates.length))){lastCountryPreview=researchData;lastCountryJson=researchData;setButtonEnabled('countryRunDownloadBtn',true);renderSummary(researchData,{candidates:researchData.candidates||[]},'완료된 단계별 검색 결과');}
      renderAi(researchData.candidates||[],researchData.holdingCandidates||[],researchData.blockedCandidates||[]);

      /* Product cards come from the private candidate ledger, while research control
         state comes from the separate compact product job.  Keeping these two
         authorities separate prevents a ledger refresh from replacing a saved
         complete/paused research state and disabling the latest-list controls. */
      var productData=candidateLedgerProductData(queueData||{candidates:[]});renderProducts(productData.products||[]);
      var productStatusFallback=preservedProductData&&text(preservedProductData.status)!=='candidate_ledger'?preservedProductData:{ok:true,status:'not_started',scope:{country:requested.country,region:requested.region},summary:{},progress:{}};
      var productStatusPart=await readScopePart('상품 리서치 실행 상태',CONTROL,'product_research_status',{country:requested.country,region:requested.region,compact:'1'},productStatusFallback);if(scopeKey()!==requestedKey)return;if(!productStatusPart.ok)failures.push(productStatusPart);var productStatus=productStatusPart.data||productStatusFallback;
      if(productStatus&&productStatus.status&&productStatus.status!=='not_started')lastProductJson=Object.assign({},productStatus,{products:productRows,latestProducts:latestProductRows});else lastProductJson=productData;renderProductProgress(lastProductJson);setButtonEnabled('productResearchBtn',researchData.status==='complete'||researchData.status==='committed'||productData.products.length>0||text(lastProductJson.status)!=='not_started');if(productData.products.length||text(lastProductJson.status)!=='not_started')setButtonEnabled('productResearchDownloadBtn',true);
      lastScopeCache={scope:requested,scopeData:scopeData,summaryData:queueData&&queueData.summary||sameCachedScope&&lastScopeCache.summaryData||{},queueData:queueData||queueFallback,researchData:researchData,productData:lastProductJson};
      saveReviewSnapshot();

      if(failures.length){
        var delayed=failures.map(function(row){return row.label;}).join(' · '),prefix=reason==='ip'?'현재 접속 IP 범위 적용은 정상입니다. ':' ';
        if(!passive)show(prefix+'일부 상세 원장 응답이 지연되었습니다: '+delayed+'. 같은 범위의 마지막 정상 원장과 버튼 상태는 그대로 보존했습니다. 범위 읽기로 지연된 부분만 다시 확인할 수 있습니다.','warn');
      }else if(!passive)show(scopeName()+' 범위를 읽었습니다.','ok');
      restoreReviewReturn();
    }catch(e){if(scopeKey()===requestedKey)show((reason==='ip'?'현재 접속 IP 범위는 적용됐지만 상세 원장을 읽는 중 오류가 발생했습니다: ':'범위를 읽는 중 오류가 발생했습니다: ')+(text(e.message)||'알 수 없는 오류'),'fail');}
    finally{$('refreshScopeBtn').disabled=false;}
  }
  async function runAutomation(dry){
    if(!selectedCountry||researchLoopActive)return;if(dry!==true){show('먼저 책임 공급업체 단계별 검색을 완료한 뒤 공급업체 후보 원장 등록을 눌러 주세요.','warn');return;}
    var requested=scopeSnapshot(),requestedKey=scopeKey(requested),restart=!!(lastCountryPreview&&(lastCountryPreview.status==='complete'||lastCountryPreview.status==='committed'));if(restart&&!window.confirm('현재 완료된 검색 결과는 관리 DB에 보존되어 있습니다. 같은 국가 범위에서 새 리서치를 시작하시겠습니까?'))return;
    closeManagementPanels();closeSupplierControlQueue();hide();researchStopRequested=false;researchLoopActive=true;var btn=$('previewRunBtn'),autoProductAfter=false;btn.disabled=true;setButtonEnabled('researchPauseBtn',true);setButtonEnabled('runNowBtn',false);
    try{
      var data=await api(CONTROL,'research_begin','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,restart:restart});
      while(true){
        if(scopeKey()!==requestedKey){researchStopRequested=true;show('검색 중 선택 범위가 바뀌어 화면 진행을 중단했습니다. 서버에 저장된 작업은 해당 범위에서 다시 이어갈 수 있습니다.','warn');break;}
        if(!data.scope)data.scope=requested;else{data.scope.source=requested.source;data.scope.detectedGeo=requested.detectedGeo;}lastCountryPreview=data;rememberReport('country',data);renderResearchProgress(data);renderSummary(data,{candidates:data.candidates||[]},'단계별 리서치 진행');if((Array.isArray(data.candidates)&&data.candidates.length)||(Array.isArray(data.holdingCandidates)&&data.holdingCandidates.length)||(Array.isArray(data.blockedCandidates)&&data.blockedCandidates.length))renderAi(data.candidates||[],data.holdingCandidates||[],data.blockedCandidates||[]);saveReviewSnapshot();
        if(data.status==='complete'||data.status==='committed'){var hasCandidates=Array.isArray(data.candidates)&&data.candidates.length>0;setButtonEnabled('runNowBtn',hasCandidates);setButtonEnabled('productResearchBtn',hasCandidates);if(hasCandidates&&(!lastProductJson||lastProductJson.status==='not_started')){autoProductAfter=true;if($('productResearchState'))$('productResearchState').textContent='공급업체 리서치를 완료했습니다. 실제 상품 이미지·상품명·원본 링크 리서치를 자동으로 이어서 시작합니다.';}show(hasCandidates?'모든 계획 검색·업체 증빙·AI 신뢰 평가를 완료했습니다. 이어서 실제 상품 이미지·원본 링크 리서치를 시작합니다.':'단계별 리서치는 완료됐지만 실행할 책임 공급업체 후보가 없습니다. JSON의 검색 경로와 제외 근거를 확인해 주세요.',hasCandidates?'ok':'warn');break;}
        if(researchStopRequested){show('진행을 일시정지했습니다. 지금까지의 검색·증빙 결과는 관리 DB에 보존됐으며 같은 버튼으로 이어서 진행합니다.','warn');break;}
        await new Promise(function(resolve){setTimeout(resolve,250);});data=await api(CONTROL,'research_step','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:data.jobId});
      }
    }catch(e){
      try{var saved=await api(CONTROL,'research_status','GET',{country:requested.country,region:requested.region});lastCountryPreview=saved;rememberReport('country',saved);renderResearchProgress(saved);if((Array.isArray(saved.candidates)&&saved.candidates.length)||(Array.isArray(saved.holdingCandidates)&&saved.holdingCandidates.length)||(Array.isArray(saved.blockedCandidates)&&saved.blockedCandidates.length))renderAi(saved.candidates||[],saved.holdingCandidates||[],saved.blockedCandidates||[]);}catch(_statusError){}
      show((text(e&&e.message)||'단계별 검색 요청이 중단됐습니다.')+' 지금까지 완료된 단계는 관리 DB에 보존됐습니다. 검색 계속 버튼으로 같은 지점부터 재개하세요.','fail');
    }finally{researchLoopActive=false;btn.disabled=false;setButtonEnabled('researchPauseBtn',false);}
    if(autoProductAfter)setTimeout(function(){runProductResearch({automatic:true});},120);
  }
  async function commitCountryPreview(){
    if(!selectedCountry)return;
    if(!lastCountryPreview||!Array.isArray(lastCountryPreview.candidates)||!lastCountryPreview.candidates.length){show('등록할 공급업체 검색 결과가 없습니다. 먼저 책임 공급업체 검색을 완료해 주세요.','warn');setButtonEnabled('runNowBtn',false);return;}
    var requested=scopeSnapshot(),requestedKey=scopeKey(requested),previewScope=lastCountryPreview.scope||{};
    if(text(previewScope.country).toUpperCase()!==text(requested.country).toUpperCase()||(text(previewScope.region||'NATIONWIDE').toUpperCase()!==text(requested.region||'NATIONWIDE').toUpperCase())){invalidateJson();show('현재 선택 범위와 검색 결과 범위가 달라 실행을 중단했습니다. 다시 검색해 주세요.','warn');return;}
    hide();var btn=$('runNowBtn');btn.disabled=true;$('previewRunBtn').disabled=true;
    try{
      var data=lastCountryPreview.jobId?await api(CONTROL,'research_commit','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,jobId:lastCountryPreview.jobId}):await api(CONTROL,'commit_preview','POST',{}, {countryCode:requested.country,subdivisionCode:requested.region,candidates:lastCountryPreview.candidates,sourceRunId:lastCountryPreview.runId||null,sourceStartedAt:lastCountryPreview.startedAt||null});
      if(scopeKey()!==requestedKey){invalidateJson();show('원장 등록 중 선택 범위가 바뀌어 결과를 폐기했습니다. 현재 범위를 다시 읽어 주세요.','warn');return;}
      if(!data.scope)data.scope=requested;else{data.scope.source=requested.source;data.scope.detectedGeo=requested.detectedGeo;}
      var holdingRows=Array.isArray(lastCountryPreview&&lastCountryPreview.holdingCandidates)?lastCountryPreview.holdingCandidates:[],blockedRows=Array.isArray(lastCountryPreview&&lastCountryPreview.blockedCandidates)?lastCountryPreview.blockedCandidates:[];
      lastCountryPreview=null;rememberReport('country',data);renderSummary(data,{candidates:data.candidates||[]},'공급업체 후보 원장 등록 완료');renderAi(data.candidates||[],holdingRows,blockedRows);
      var refreshedAfterCommit=false;
      try{await reloadData(false);await loadScope('commit-refresh');refreshedAfterCommit=true;}catch(_reloadError){}
      if(!refreshedAfterCommit){renderSummary(data,{candidates:data.candidates||[]},'공급업체 후보 원장 등록 완료');renderAi(data.candidates||[],holdingRows,blockedRows);}
      presentJson(data);
      show('검색 결과를 비공개 책임 공급업체 후보 원장에 등록했습니다. 상품 리서치·대기열 심사·사이트 게재는 실행하지 않았습니다.',data.ok?'ok':'warn');
    }catch(e){
      var failure=e&&e.payload&&typeof e.payload==='object'?e.payload:{ok:false,reportType:'igdc-country-responsible-supplier-preview-commit-error',generatedAt:new Date().toISOString(),scope:requested,error:text(e&&e.message),code:text(e&&e.code)};
      rememberReport('country',failure);show(text(e&&e.message)||'공급업체 후보 원장 등록에 실패했습니다. 오류 JSON을 내려받아 확인할 수 있습니다.','fail');
      setButtonEnabled('runNowBtn',!!(lastCountryPreview&&lastCountryPreview.candidates&&lastCountryPreview.candidates.length));
    }finally{$('previewRunBtn').disabled=false;}
  }

  async function globalControlDiagnostic(){
    hide();var button=$('globalSituationBtn');if(button)button.disabled=true;
    try{var data=await api(CONTROL,'global_control_diagnostic','GET',{});rememberReport('globalControl',data);show('전 세계 자동화 관제 상태, 예약 범위, 공급업체·상품 리서치 작업과 오류 상태를 점검했습니다.','ok');}
    catch(e){show(text(e.message)||'전체 관제 상황 점검에 실패했습니다.','fail');}
    finally{if(button)button.disabled=false;}
  }
  async function diagnostic(){
    hide();var diagnosticButtons=[$('diagnosticBtn'),$('runCurrentDiagnosticBtn')].filter(Boolean);diagnosticButtons.forEach(function(button){button.disabled=true;});var requested=scopeSnapshot(),requestedKey=scopeKey(requested),p={country:requested.country,region:requested.region};
    try{
      var all=[],$state=stateEl;function step(label){if($state)$state.textContent='통합 점검 준비 · '+label;return new Promise(function(resolve){requestAnimationFrame(function(){setTimeout(resolve,0);});});}
      await step('운영 제어');all[0]=await api(CONTROL,'diagnostic','GET',{});if(scopeKey()!==requestedKey)return;
      await step('상품 후보 대기열');all[1]=await api(REVIEW,'diagnostic','GET',p);if(scopeKey()!==requestedKey)return;
      await step('선택 국가·지역');all[2]=await api(CONTROL,'scope','GET',p);if(scopeKey()!==requestedKey)return;
      await step('시장 신호');all[3]=await api(CONTROL,'signal_status','GET',{regionGroup:requested.regionGroup});
      if(scopeKey()!==requestedKey){invalidateJson();show('점검 중 선택 범위가 바뀌어 이전 결과를 폐기했습니다. 현재 범위에서 다시 점검해 주세요.','warn');return;}
      var report={ok:true,reportType:'igdc-integrated-commerce-control-diagnostic',generatedAt:new Date().toISOString(),scope:requested,control:all[0],queue:all[1],automationScope:all[2],marketSignals:all[3]};rememberReport('diagnostic',report);saveReviewSnapshot();show('통합 점검 JSON을 생성했습니다. 전체 원문은 다운로드 버튼으로 바로 내려받을 수 있습니다.','ok');
    }
    catch(e){var failure=e&&e.payload&&typeof e.payload==='object'?e.payload:{ok:false,reportType:'igdc-integrated-commerce-control-diagnostic-error',generatedAt:new Date().toISOString(),scope:requested,error:text(e&&e.message),code:text(e&&e.code)};rememberReport('diagnostic',failure);show(text(e&&e.message)||'통합 점검에 실패했습니다. 오류 JSON을 내려받을 수 있습니다.','fail');}
    finally{diagnosticButtons.forEach(function(button){button.disabled=false;});}
  }
  function reportScope(data){var s=data&&data.scope||{};return{country:text(s.country).toUpperCase(),region:text(s.region||'NATIONWIDE').toUpperCase()||'NATIONWIDE'};}
  function download(){
    if(!lastJson){var raw=text($('jsonOutput').textContent),parsed=parseJson(raw);if(parsed)lastJson=parsed;}
    if(!lastJson){show('다운로드할 점검·실행 JSON이 없습니다. 먼저 점검 또는 실행을 완료해 주세요.','warn');return;}
    var type=text(lastJson.reportType),scope=lastJson.scope||{},stamp=new Date().toISOString().replace(/[:.]/g,'-'),name='';
    if(type==='igdc-global-automation-control-diagnostic')name='IGDC_GLOBAL_AUTOMATION_CONTROL_'+stamp+'.json';
    else if(type==='igdc-global-market-signal-persisted-research')name='IGDC_GLOBAL_MARKET_SIGNAL_PROGRESS_'+stamp+'.json';
    else if(type==='igdc-regional-market-signal-persisted-research')name='IGDC_REGION_MARKET_SIGNAL_PROGRESS_'+text(scope.regionGroup).toUpperCase()+'_'+stamp+'.json';
    else if(type==='igdc-country-product-reference-persisted-research'||type==='igdc-country-product-reference-research-status')name='IGDC_PRODUCT_RESEARCH_'+text(scope.country).toUpperCase()+'_'+text(scope.region||'NATIONWIDE').toUpperCase()+'_'+stamp+'.json';
    else if(type==='igdc-global-market-signal-check')name='IGDC_GLOBAL_MARKET_SIGNAL_'+stamp+'.json';
    else if(type==='igdc-regional-market-signal-check'){if(scope.regionGroup!==selectedRegion){show('선택 권역과 점검 JSON 권역이 달라 다운로드를 중단했습니다.','warn');return;}name='IGDC_REGION_MARKET_SIGNAL_'+text(scope.regionGroup).toUpperCase()+'_'+stamp+'.json';}
    else if(type==='igdc-country-automation-operating-preset')name='IGDC_AUTOMATION_PRESET_'+text(lastJson.preset).toUpperCase()+'_'+stamp+'.json';
    else{var report=reportScope(lastJson);if(!report.country||scopeKey(report)!==scopeKey()){invalidateJson();show('선택 범위와 점검 JSON 범위가 달라 이전 결과를 폐기했습니다. 현재 범위에서 다시 점검해 주세요.','warn');return;}name='IGDC_COUNTRY_REGION_CONTROL_'+report.country+'_'+report.region+'_'+stamp+'.json';}
    try{var compact=lastJson&&lastJson.reportType==='igdc-integrated-commerce-control-diagnostic',raw=JSON.stringify(lastJson,null,compact?0:2)+'\n',blob=new Blob([raw],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(function(){try{a.remove();URL.revokeObjectURL(url);}catch(_e){}},1500);show('전체 JSON 다운로드를 시작했습니다.','ok');}catch(e){show('JSON 파일을 만들지 못했습니다: '+text(e.message),'fail');}
  }
  async function reloadData(loadSelected,preserveUi){if(!preserveUi)closeQueuePanel();queueControlScopeKey='';hide();$('reloadBtn').disabled=true;try{await ensureSession(false);var catalogData=await api(CONTROL,'catalog','GET',{}),fallback=await staticRegistry();catalog=catalogData||{};try{locations=await api(REVIEW,'locations','GET',{});}catch(_locationError){locations={countries:[]};}if(!(sessionResumeActive&&geo&&geo.country))geo=await geoData();regions=(catalog.registry&&catalog.registry.regions)||fallback.regions||[];countries=(catalog.countries&&catalog.countries.length?catalog.countries:fallback.countries)||[];settings=catalog.settings||[];if(!catalog.registry)catalog.registry={};catalog.registry.regions=regions;catalog.countries=countries;mapSettings();if(geo&&geo.country){var geoCountry=country(geo.country);if(geoCountry)geo.worldRegion=geoCountry.regionGroup;}if(!regions.length||!countries.length)throw new Error('전 세계 국가 레지스트리를 불러오지 못했습니다. 자동화 모드와 무관한 구성 오류입니다.');var detected=geo&&geo.resolved?(geo.country+(geo.region?' / '+geo.region:'')):(geo&&geo.excluded?'제외 국가 IP':'IP 국가 미확인');$('detectedScope').textContent='현재 접속 IP: '+detected;if(!selectedCountry){var restored=savedScope(),restoredCountry=country(restored.country),geoCountry=geo&&geo.country&&country(geo.country);selectedCountry=restoredCountry?restoredCountry.code:(geoCountry?geoCountry.code:(country('KR')?'KR':(countries[0]&&countries[0].code||'')));selectionSource=restoredCountry?(restored.source||'saved-scope'):(geoCountry?'ip-detected':'default-country');var c=country(selectedCountry);selectedRegion=c&&c.regionGroup||geo&&geo.worldRegion||restored.regionGroup||regions[0]&&regions[0].id||'';var preferredRegion=restoredCountry?restored.region:(geo&&geo.country===selectedCountry&&geo.region?geo.region:'NATIONWIDE');selectedSubdivision=validSubdivision(c,preferredRegion||'NATIONWIDE');}renderAll();if(loadSelected!==false)await loadScope();}catch(e){show(text(e.message)||'관제 데이터를 불러오지 못했습니다.','fail');}finally{$('reloadBtn').disabled=false;}}
  function managementSanitizeKey(value){return text(value).replace(/[^a-z0-9_-]/gi,'_');}
  function managementSectionKeyFromWorkspace(workspaceKey,prefix){var suffix=text(workspaceKey).slice(prefix.length);for(var i=0;i<PRODUCT_SECTIONS.length;i++){if(managementSanitizeKey(PRODUCT_SECTIONS[i].key)===suffix)return PRODUCT_SECTIONS[i].key;}return'';}
  function managementCandidateGroupKeyFromWorkspace(workspaceKey){var suffix=text(workspaceKey).slice('candidate_group_'.length),keys=['queue_selected','assignment_repair','unassigned'].concat(PRODUCT_SECTIONS.map(function(row){return row.key;}));for(var i=0;i<keys.length;i++){if(managementSanitizeKey(keys[i])===suffix)return keys[i];}return'';}
  function managementWorkspaceRows(workspaceKey){
    var key=text(workspaceKey);
    if(key==='latest_product_research')return latestProductRows.slice();
    if(key==='whole_product_queue')return queueCandidateRows.slice();
    if(key==='product_candidate_management')return productRows.filter(candidatePoolRow);
    if(key==='distribution_18_sections')return productRows.filter(function(row){return productDecision(row)==='slot_candidate';});
    if(key==='excluded_ledger_management')return productRows.filter(function(row){var d=productDecision(row);return d==='hold'||d==='reject'||d==='purge';});
    if(key.indexOf('candidate_group_')===0){var group=managementCandidateGroupKeyFromWorkspace(key);return group?candidateGroupRows(group):[];}
    if(key.indexOf('section_')===0){var section=managementSectionKeyFromWorkspace(key,'section_');return section?sectionRows(section):[];}
    if(key==='product_research_control')return productRows.slice();
    return[];
  }
  function managementRowId(row){return text(row&&(row.candidateId||row.id||row.productIdentity||row.productUrl||row.url));}
  function managementRowUrl(row){return safeExternalUrl(row&&(row.productUrl||row.url||row.checkoutUrl||row.official_url));}
  function managementRowImage(row){return safeExternalImageUrl(row&&(row.imageUrl||row.imageOriginalUrl||row.image||row.thumbnailUrl||row.thumbnail_url));}
  function managementDocumentLink(url){var value=text(url).toLowerCase();return /\.(pdf|docx?|xlsx?|pptx?|zip)(?:[?#]|$)/.test(value)||/(?:^|\/)(?:report|reports|document|documents|download|downloads|repository|publication|publications)(?:\/|$)/.test(value);}
  function managementSelectedIds(workspaceKey,rows){
    var key=text(workspaceKey),ids=[];
    if(key==='latest_product_research')ids=latestSelectedIds();
    else if(key==='whole_product_queue')ids=selectedQueueIds();
    else if(key==='excluded_ledger_management')ids=Array.prototype.slice.call(document.querySelectorAll('[data-product-exclusion-select]:checked')).map(function(box){return text(box.value);});
    else if(key.indexOf('candidate_group_')===0){var group=managementCandidateGroupKeyFromWorkspace(key);ids=group?selectedCandidateIds(group):[];}
    else if(key.indexOf('section_')===0){var section=managementSectionKeyFromWorkspace(key,'section_');ids=section?selectedProductIds(section):[];}
    else if(key==='product_candidate_management')ids=Object.keys(candidateSelectedProducts).filter(function(id){return candidateSelectedProducts[id]===true;});
    else if(key==='distribution_18_sections')ids=Object.keys(frontSelectedProducts).filter(function(id){return frontSelectedProducts[id]===true;});
    var valid={};rows.forEach(function(row){var id=managementRowId(row);if(id)valid[id]=true;});return Array.from(new Set(ids.filter(function(id){return valid[id];})));
  }
  function managementFilterRows(workspaceKey,rows,filter,query){
    filter=text(filter).toLowerCase();query=text(query).toLowerCase();if(filter==='all')return rows.slice();if(filter==='selected'){var selected=new Set(managementSelectedIds(workspaceKey,rows));return rows.filter(function(row){return selected.has(managementRowId(row));});}
    if(filter==='missing_thumbnail')return rows.filter(function(row){return !managementRowImage(row);});
    if(filter==='missing_url')return rows.filter(function(row){return !text(row&&(row.productUrl||row.url||row.checkoutUrl||row.official_url));});
    if(filter==='invalid_url')return rows.filter(function(row){return !!text(row&&(row.productUrl||row.url||row.checkoutUrl||row.official_url))&&!managementRowUrl(row);});
    if(filter==='document_link')return rows.filter(function(row){var raw=text(row&&(row.productUrl||row.url||row.checkoutUrl||row.official_url));return !!raw&&managementDocumentLink(raw);});
    if(filter==='duplicate_url'){var counts={};rows.forEach(function(row){var key=productUrlMatchKey(managementRowUrl(row));if(key)counts[key]=(counts[key]||0)+1;});var kept={};return rows.filter(function(row){var key=productUrlMatchKey(managementRowUrl(row));if(!key||counts[key]<2)return false;if(!kept[key]){kept[key]=true;return false;}return true;});}
    if(filter==='title_contains'&&query)return rows.filter(function(row){return text(row&&(row.productName||row.title||row.sourceTitle)).toLowerCase().indexOf(query)>=0;});
    if(filter==='url_contains'&&query)return rows.filter(function(row){return text(row&&(row.productUrl||row.url||row.checkoutUrl||row.official_url)).toLowerCase().indexOf(query)>=0;});
    if(filter==='supplier_contains'&&query)return rows.filter(function(row){return text(row&&(row.supplierName||row.providerName||row.supplier&&row.supplier.name)).toLowerCase().indexOf(query)>=0;});
    return[];
  }
  function managementOperationAllowed(workspaceKey,operation){
    var key=text(workspaceKey),op=text(operation).toLowerCase();
    if(['queue_register','latest_delete','queue_unmatch'].indexOf(op)>=0)return key==='latest_product_research';
    if(op==='remove_from_list')return key==='whole_product_queue'||key==='product_candidate_management'||key==='distribution_18_sections'||key.indexOf('candidate_group_')===0||key.indexOf('section_')===0||key==='product_research_control';
    if(op==='purge')return key==='excluded_ledger_management';
    if(op==='ai_place')return key==='latest_product_research'||key==='product_candidate_management'||key==='distribution_18_sections'||key.indexOf('candidate_group_')===0||key.indexOf('section_')===0||key==='product_research_control';
    if(['hold','reject','restore'].indexOf(op)>=0)return key==='product_candidate_management'||key==='distribution_18_sections'||key==='excluded_ledger_management'||key.indexOf('candidate_group_')===0||key.indexOf('section_')===0||key==='product_research_control';
    return false;
  }
  function managementContext(workspaceKey){
    var rows=managementWorkspaceRows(workspaceKey),selected=managementSelectedIds(workspaceKey,rows),urls={},duplicates=0;rows.forEach(function(row){var key=productUrlMatchKey(managementRowUrl(row));if(key)urls[key]=(urls[key]||0)+1;});Object.keys(urls).forEach(function(key){if(urls[key]>1)duplicates+=urls[key]-1;});
    return{workspaceKey:text(workspaceKey),countryCode:selectedCountry||null,subdivisionCode:selectedSubdivision||'NATIONWIDE',total:rows.length,selected:selected.length,missingThumbnail:managementFilterRows(workspaceKey,rows,'missing_thumbnail').length,missingUrl:managementFilterRows(workspaceKey,rows,'missing_url').length,invalidUrl:managementFilterRows(workspaceKey,rows,'invalid_url').length,documentLink:managementFilterRows(workspaceKey,rows,'document_link').length,duplicateUrl:duplicates,frontPublicationAllowed:false,maxCandidatePool:3000,pageSize:MANAGEMENT_PAGE_SIZE};
  }
  function previewManagementActions(workspaceKey,actions){
    var rows=managementWorkspaceRows(workspaceKey),claimed={},preview=[],totalTargets=0;
    (Array.isArray(actions)?actions:[]).forEach(function(action,index){var op=text(action&&action.operation).toLowerCase(),filter=text(action&&action.filter||'selected').toLowerCase();if(!managementOperationAllowed(workspaceKey,op))return;var targets=managementFilterRows(workspaceKey,rows,filter,text(action&&action.query)),ids=[];targets.forEach(function(row){var id=managementRowId(row);if(!id||claimed[id])return;claimed[id]=true;ids.push(id);});if(!ids.length)return;preview.push({index:index,operation:op,filter:filter,sectionKey:text(action&&action.sectionKey),query:text(action&&action.query),note:text(action&&action.note),targetIds:ids,count:ids.length});totalTargets+=ids.length;});
    return{ok:true,workspaceKey:text(workspaceKey),scope:{countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE'},actions:preview,totalTargets:totalTargets,publicPublication:false,generatedAt:new Date().toISOString()};
  }
  async function managementCandidateBulk(ids,decision,placementKey){
    var wanted=new Set((ids||[]).map(text)),rows=productRows.filter(function(row){return wanted.has(managementRowId(row));}),ledger=rows.filter(function(row){return row.ledgerSource==='candidate';}),legacy=rows.filter(function(row){return row.ledgerSource!=='candidate';}),processed=0,failed=0,failures=[];
    for(var off=0;off<ledger.length;off+=100){var chunk=ledger.slice(off,off+100).map(function(row){return text(row.candidateId||row.id);}).filter(Boolean);try{var result=await api(CONTROL,'product_candidate_ledger_bulk_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',candidateIds:chunk,decision:decision,placementKey:placementKey||''},30000);processed+=Number(result&&result.processed||0);failed+=Number(result&&result.failed||0);(result&&result.failures||[]).slice(0,20).forEach(function(f){failures.push(f);});}catch(error){failed+=chunk.length;failures.push({error:text(error&&error.message)||'bulk_failed'});}}
    var last=null;for(var i=0;i<legacy.length;i++){try{last=await api(CONTROL,'product_candidate_action','POST',{}, {countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE',productId:text(legacy[i].id),decision:decision,placementKey:placementKey||''},30000);processed+=1;}catch(error){failed+=1;failures.push({id:text(legacy[i].id),error:text(error&&error.message)||'item_failed'});}}
    if(last){lastProductJson=last;rememberReport('product',last);renderProductProgress(last);renderProducts(last.products||[]);}else await refreshCandidateLedgerProducts({preserveResearchReport:true});saveReviewSnapshot();return{processed:processed,failed:failed,failures:failures};
  }
  async function executeManagementPreview(preview){
    if(!preview||!Array.isArray(preview.actions)||!preview.actions.length)return{ok:false,processed:0,failed:0,summary:'실행할 관리 작업이 없습니다.'};var processed=0,failed=0,details=[];
    for(var i=0;i<preview.actions.length;i++){var action=preview.actions[i],ids=action.targetIds||[],result=null;try{
      if(action.operation==='queue_register'||action.operation==='latest_delete'||action.operation==='queue_unmatch'){Object.keys(latestSelectedProducts).forEach(function(id){delete latestSelectedProducts[id];});ids.forEach(function(id){latestSelectedProducts[id]=true;});result=await runLatestProductQueueAction(action.operation==='queue_register'?'stage':action.operation==='latest_delete'?'delete':'unmatch','selected',{skipConfirm:true});processed+=Number(result&&result.handled||0);failed+=Number(result&&result.failed||0);}
      else if(action.operation==='ai_place'){if(preview.workspaceKey==='latest_product_research'){Object.keys(latestSelectedProducts).forEach(function(id){delete latestSelectedProducts[id];});ids.forEach(function(id){latestSelectedProducts[id]=true;});var stage=await runLatestProductQueueAction('stage','selected',{skipConfirm:true});var candidateIds=candidateIdsForLatestRows(latestRowsForIds(ids));if(candidateIds.length)await runProductAiAutomation('products','',candidateIds,{skipConfirm:true});processed+=candidateIds.length;failed+=Math.max(0,ids.length-candidateIds.length)+Number(stage&&stage.failed||0);}else{await runProductAiAutomation('products','',ids,{skipConfirm:true});processed+=ids.length;}}
      else if(action.operation==='remove_from_list'){
        if(preview.workspaceKey==='whole_product_queue'){for(var q=0;q<ids.length;q+=100){var qids=ids.slice(q,q+100),qd=await api(QUEUE_CONTROL,'bulk_action','POST',{}, {candidateIds:qids,decision:'remove_from_list',countryCode:selectedCountry,subdivisionCode:selectedSubdivision||'NATIONWIDE'});processed+=Number(qd&&qd.processed||0);failed+=Number(qd&&qd.failures&&qd.failures.length||0);}await refreshCandidateLedgerProducts({preserveResearchReport:true});}
        else{result=await managementCandidateBulk(ids,'remove_from_list','');processed+=Number(result.processed||0);failed+=Number(result.failed||0);}
      }
      else{var decision=action.operation==='restore'?'undecided':action.operation;result=await managementCandidateBulk(ids,decision,action.sectionKey||'');processed+=Number(result.processed||0);failed+=Number(result.failed||0);}
      details.push({operation:action.operation,requested:ids.length,ok:true});
    }catch(error){failed+=ids.length;details.push({operation:action.operation,requested:ids.length,ok:false,error:text(error&&error.message)||'execution_failed'});}}
    renderQueue(queueCandidateRows);renderProducts(productRows);return{ok:failed===0,processed:processed,failed:failed,details:details,summary:'AI 승인 관리 실행 · 요청 대상 '+preview.totalTargets+'건 · 처리 '+processed+'건 · 실패 '+failed+'건 · 프론트 공개·GitHub/Netlify 빌드 없음'};
  }
  window.IGDCCommerceManagementBridge={getContext:function(workspaceKey){return managementContext(workspaceKey);},preview:function(workspaceKey,actions){return previewManagementActions(workspaceKey,actions);},execute:function(preview){return executeManagementPreview(preview);}};

  function wire(){if(wired)return;wired=true;document.addEventListener('click',function(event){var target=event.target&&event.target.closest?event.target.closest('a[data-review-link]'):null;if(target)navigateReviewLink(target,event);},true);window.addEventListener('pageshow',function(event){if(event.persisted===true){hydrateReviewSnapshot();restoreReviewReturn();}});window.addEventListener('pagehide',saveReviewSnapshot);document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')saveReviewSnapshot();});document.addEventListener('click',function(event){var link=event.target&&event.target.closest?event.target.closest('a[href]'):null;if(!link)return;try{var target=new URL(link.href,location.href);if(target.origin===location.origin)saveReviewSnapshot();}catch(_e){}},true);document.addEventListener('keydown',function(event){if(event.key==='Escape'&&$('affiliateSettlementModal')&&!$('affiliateSettlementModal').classList.contains('hidden'))closeAffiliateSettlementModal();});if($('globalSituationBtn'))$('globalSituationBtn').addEventListener('click',function(e){e.preventDefault();e.stopImmediatePropagation();globalControlDiagnostic();},true);$('globalAutoModeBtn').addEventListener('click',function(){applyOperatingPreset('global_auto');});$('globalPauseBtn').addEventListener('click',function(){applyOperatingPreset('global_pause');});$('saveMasterBtn').addEventListener('click',async function(){try{await saveSetting({scopeType:'master',mode:$('masterMode').value,intervalDays:Number($('masterInterval').value),maxCandidates:20});show('전체 마스터 설정을 저장했습니다.','ok');}catch(e){show(text(e.message),'fail');}});$('saveScopeBtn').addEventListener('click',async function(){if(!selectedCountry)return;var type=selectedSubdivision==='NATIONWIDE'?'country':'subdivision';try{await saveSetting({scopeType:type,countryCode:selectedCountry,subdivisionCode:selectedSubdivision,mode:$('scopeMode').value,intervalDays:Number($('scopeInterval').value),maxCandidates:Number($('maxCandidates').value),expandSubdivisions:$('expandSubdivisions').value==='true'});show('선택 범위 설정을 저장했습니다.','ok');}catch(e){show(text(e.message),'fail');}});$('useGeoBtn').addEventListener('click',function(){if(!geo||!geo.resolved){show('현재 배포 요청에서 지원되는 국가 IP를 확인하지 못했습니다.','warn');return;}invalidateJson();selectedCountry=geo.country;selectionSource='ip-detected';var c=country(selectedCountry);selectedSubdivision=validSubdivision(c,geo.region||'NATIONWIDE');selectedRegion=geo.worldRegion||c&&c.regionGroup||'';renderAll();show('현재 접속 IP 범위를 적용했습니다. 상세 원장을 순차적으로 읽습니다.','ok');loadScope('ip');});$('reloadBtn').addEventListener('click',function(){sessionResumeActive=false;geo=null;reloadData(true);});$('refreshScopeBtn').addEventListener('click',function(){loadScope('manual');});$('previewRunBtn').addEventListener('click',function(){runAutomation(true);});if($('researchPauseBtn'))$('researchPauseBtn').addEventListener('click',function(){researchStopRequested=true;$('researchPauseBtn').disabled=true;});$('runNowBtn').addEventListener('click',commitCountryPreview);$('diagnosticBtn').addEventListener('click',diagnostic);$('globalSignalBtn').addEventListener('click',function(){runMarketSignal('global');});$('regionalSignalBtn').addEventListener('click',function(){runMarketSignal('regional');});$('applySignalBtn').addEventListener('click',applyMarketSignal);$('countryCheckJumpBtn').addEventListener('click',function(){$('countryCheckPanel').scrollIntoView({behavior:'smooth',block:'start'});});$('downloadCurrentJsonBtn').addEventListener('click',download);if($('globalSignalDownloadBtn'))$('globalSignalDownloadBtn').addEventListener('click',function(){downloadRemembered('global');});if($('regionalSignalDownloadBtn'))$('regionalSignalDownloadBtn').addEventListener('click',function(){downloadRemembered('regional');});if($('downloadSignalJsonBtn'))$('downloadSignalJsonBtn').addEventListener('click',function(){downloadRemembered(lastSignalReport&&lastSignalReport.scope&&lastSignalReport.scope.type==='regional'?'regional':'global');});if($('countryRunDownloadBtn'))$('countryRunDownloadBtn').addEventListener('click',function(){downloadRemembered('country');});if($('diagnosticDownloadBtn'))$('diagnosticDownloadBtn').addEventListener('click',function(){downloadRemembered('diagnostic');});if($('globalControlDownloadBtn'))$('globalControlDownloadBtn').addEventListener('click',function(){downloadRemembered('globalControl');});if($('supplierManualRegisterBtn'))$('supplierManualRegisterBtn').addEventListener('click',registerManualSupplier);wireQueueControls();if($('supplierControlQueue'))$('supplierControlQueue').addEventListener('toggle',syncSupplierControlToggleLabel);ensureProductQueueStageControls();syncProductQueueStageControls();ensureProductAiFinalizeControl();syncProductAiFinalizeControl();ensureLatestProductQueueControls();syncLatestProductQueueControls();if($('latestProductSelectAll'))$('latestProductSelectAll').addEventListener('change',function(){var checked=this.checked;latestProductRows.forEach(function(row){var id=latestProductKey(row);if(id)latestSelectedProducts[id]=checked;});syncLatestProductQueueControls();});if($('latestSelectedQueueStageBtn'))$('latestSelectedQueueStageBtn').addEventListener('click',function(){runLatestProductQueueAction('stage','selected');});if($('latestSelectedAiBtn'))$('latestSelectedAiBtn').addEventListener('click',runLatestSelectedAi);if($('latestAllQueueStageBtn'))$('latestAllQueueStageBtn').addEventListener('click',function(){runLatestProductQueueAction('stage','all');});if($('latestAllAiBtn'))$('latestAllAiBtn').addEventListener('click',runLatestAllAi);if($('latestSelectedQueueUnmatchBtn'))$('latestSelectedQueueUnmatchBtn').addEventListener('click',function(){runLatestProductQueueAction('unmatch','selected');});if($('latestSelectedQueueDeleteBtn'))$('latestSelectedQueueDeleteBtn').addEventListener('click',function(){runLatestProductQueueAction('delete','selected');});if($('latestProductPanel'))$('latestProductPanel').addEventListener('change',function(event){var box=event.target&&event.target.closest?event.target.closest('[data-latest-queue-select]'):null;if(!box)return;latestSelectedProducts[box.value]=box.checked;syncLatestProductQueueControls();});if($('latestProductPanel'))$('latestProductPanel').addEventListener('click',function(event){var button=event.target&&event.target.closest?event.target.closest('[data-management-pager=\"latest\"] [data-page-delta]'):null;if(!button)return;event.preventDefault();latestProductPage=clampPage(latestProductPage+Number(button.getAttribute('data-page-delta')||0),latestProductRows.length,MANAGEMENT_PAGE_SIZE);renderLatestProductRows();});if($('productResearchBtn'))$('productResearchBtn').addEventListener('click',runProductResearch);if($('productResearchPauseBtn'))$('productResearchPauseBtn').addEventListener('click',function(){productPausePersistPromise=requestProductPause();});if($('productQueueStageCurrentBtn'))$('productQueueStageCurrentBtn').addEventListener('click',function(){stageCurrentResearchQueue({automatic:false});});if($('productQueueAutoBtn'))$('productQueueAutoBtn').addEventListener('click',function(){saveProductPauseAutoQueue(!productPauseAutoQueue);if(productPauseAutoQueue&&productPausedForQueue&&!productLoopActive)stageCurrentResearchQueue({automatic:true});});if($('productResearchDownloadBtn'))$('productResearchDownloadBtn').addEventListener('click',function(){downloadRemembered('product');});if($('productTransitionAuditBtn'))$('productTransitionAuditBtn').addEventListener('click',function(){runProductTransitionAudit({silent:false});});if($('productTransitionAuditDownloadBtn'))$('productTransitionAuditDownloadBtn').addEventListener('click',downloadProductTransitionAudit);if($('productAiAutoBtn'))$('productAiAutoBtn').addEventListener('click',function(){runProductAiAutomation('all','');});if($('productAiFinalizeBtn'))$('productAiFinalizeBtn').addEventListener('click',function(){finalizeProductAiDraft({internal:false});});if($('productFrontMatchBtn'))$('productFrontMatchBtn').addEventListener('click',function(){runProductFrontSync('match','all','');});if($('productFrontUnmatchBtn'))$('productFrontUnmatchBtn').addEventListener('click',function(){runProductFrontSync('unmatch','all','');});if($('affiliateSettlementCloseBtn'))$('affiliateSettlementCloseBtn').addEventListener('click',closeAffiliateSettlementModal);if($('affiliateSettlementCancelBtn'))$('affiliateSettlementCancelBtn').addEventListener('click',closeAffiliateSettlementModal);if($('affiliateSettlementSaveBtn'))$('affiliateSettlementSaveBtn').addEventListener('click',saveAffiliateSettlement);if($('affiliateSettlementModal'))$('affiliateSettlementModal').addEventListener('click',function(event){if(event.target===$('affiliateSettlementModal'))closeAffiliateSettlementModal();});if($('scopeAuditRefreshBtn'))$('scopeAuditRefreshBtn').addEventListener('click',function(){openScopeAudit(activeScopeAudit||'queue',true);});if($('scopeAuditOpenBtn'))$('scopeAuditOpenBtn').addEventListener('click',openFullScopeAudit);if($('scopeAuditDownloadBtn'))$('scopeAuditDownloadBtn').addEventListener('click',downloadScopeAudit);if($('scopeAuditCloseBtn'))$('scopeAuditCloseBtn').addEventListener('click',closeScopeAudit);$('returnBtn').addEventListener('click',function(){var q=new URLSearchParams(location.search),p=q.get('returnPath');location.href=p&&p.charAt(0)==='/'?p:'/admin.html';});$('countrySearch').addEventListener('input',renderCountries);$('clearSearchBtn').addEventListener('click',function(){$('countrySearch').value='';renderCountries();});$('showRegionBtn').addEventListener('click',function(){regionOnly=!regionOnly;$('showRegionBtn').textContent=regionOnly?'현재 권역만':'전 세계 전체';renderCountries();});wireHeavyPanels();var productPanel=$('productResearchPanel');if(productPanel){productPanel.addEventListener('click',function(event){var sectionAuto=event.target&&event.target.closest?event.target.closest('[data-section-ai-auto]'):null;if(sectionAuto){event.preventDefault();event.stopPropagation();var aiKey=sectionAuto.getAttribute('data-section-ai-auto');runProductAiAutomation(aiKey==='__all__'?'all':'section',aiKey==='__all__'?'':aiKey);return;}var productSectionRelease=event.target&&event.target.closest?event.target.closest('[data-product-section-release]'):null;if(productSectionRelease){event.preventDefault();event.stopPropagation();var releaseId=productSectionRelease.getAttribute('data-product-section-release');if(window.confirm('이 상품을 현재 18개 섹션 배치 예정 목록에서 해제하고 미배정 후보로 돌리시겠습니까?\n\n이 작업은 GitHub/Netlify 프론트 빌드를 실행하지 않습니다.'))applyProductDecision(releaseId,'undecided','',true);return;}var sectionFrontMatch=event.target&&event.target.closest?event.target.closest('[data-section-front-match]'):null;if(sectionFrontMatch){event.preventDefault();event.stopPropagation();runProductFrontSync('match','section',sectionFrontMatch.getAttribute('data-section-front-match'));return;}var sectionFrontUnmatch=event.target&&event.target.closest?event.target.closest('[data-section-front-unmatch]'):null;if(sectionFrontUnmatch){event.preventDefault();event.stopPropagation();runProductFrontSync('unmatch','section',sectionFrontUnmatch.getAttribute('data-section-front-unmatch'));return;}var apply=event.target&&event.target.closest?event.target.closest('[data-product-management-apply]'):null;if(apply){var id=apply.getAttribute('data-product-management-apply'),value=productPlacementSelections[id]||'';if(value.indexOf('affiliate:')===0){openAffiliateSettlementModal(id,value.slice(10));return;}var decision=value.indexOf('section:')===0?'slot_candidate':value,key=decision==='slot_candidate'?value.slice(8):'';if(!decision){show('관리 작업을 먼저 선택해 주세요.','warn');return;}applyProductDecision(id,decision,key);return;}var action=event.target&&event.target.closest?event.target.closest('[data-product-action]'):null;if(action){applyProductDecision(action.getAttribute('data-product-id'),action.getAttribute('data-product-action'),productPlacementSelections[action.getAttribute('data-product-id')]||'');}});productPanel.addEventListener('change',function(event){var management=event.target&&event.target.getAttribute&&event.target.getAttribute('data-product-management-select');if(management){productPlacementSelections[management]=event.target.value;var card=event.target.closest('.product-card'),button=card&&card.querySelector('[data-product-management-apply]');if(button)button.disabled=!event.target.value;return;}var kind=event.target&&event.target.getAttribute&&event.target.getAttribute('data-product-exclusion-select'),all=event.target&&event.target.getAttribute&&event.target.getAttribute('data-product-exclusion-select-all');if(all){Array.prototype.forEach.call(document.querySelectorAll('[data-product-exclusion-select="'+all+'"]'),function(box){box.checked=event.target.checked;});syncProductExclusionSelection(all);}else if(kind)syncProductExclusionSelection(kind);});productPanel.addEventListener('click',function(event){var pager=event.target&&event.target.closest?event.target.closest('[data-management-pager="excluded"] [data-page-delta]'):null;if(pager){event.preventDefault();var wrap=pager.closest('[data-management-pager="excluded"]'),kind=wrap&&wrap.getAttribute('data-management-pager-key'),rows=productExcludedRows(kind),stateKey='excluded:'+kind;candidateGroupPages[stateKey]=clampPage((candidateGroupPages[stateKey]||0)+Number(pager.getAttribute('data-page-delta')||0),rows.length,MANAGEMENT_PAGE_SIZE);renderProductExcludedTable(kind);return;}var button=event.target&&event.target.closest?event.target.closest('[data-product-exclusion-bulk]'):null;if(button)applyProductExclusionBulk(button.getAttribute('data-product-exclusion-scope'),button.getAttribute('data-product-exclusion-bulk'));});Array.prototype.forEach.call(productPanel.querySelectorAll('#supplierControlQueue,#productHoldQueue,#productRejectQueue'),function(details){details.addEventListener('toggle',function(){var label=details.querySelector('[data-detail-toggle-label]');if(label)syncDetailsToggle(details,label);if(details.open&&$('excludedLedgerPanel')&&$('excludedLedgerPanel').open){if(details.id==='supplierControlQueue')renderSupplierExcludedRows();else if(details.id==='productHoldQueue')renderProductExcludedTable('hold');else renderProductExcludedTable('reject');}else if(!details.open){var body=details.querySelector('tbody');if(body)body.innerHTML='';}});});}}
  function wireCandidateBulkControls(){
    var panel=$('productResearchPanel');if(!panel)return;
    panel.addEventListener('pointerdown',function(event){var target=event.target;if(!target||!target.getAttribute)return;if(target.getAttribute('data-candidate-select-all')){if(target.indeterminate)target.setAttribute('data-clear-indeterminate','1');else target.removeAttribute('data-clear-indeterminate');}});
    panel.addEventListener('change',function(event){var target=event.target;if(!target||!target.getAttribute)return;var groupKey=target.getAttribute('data-candidate-select');if(groupKey){candidateSelectedProducts[target.value]=target.checked===true;syncCandidateSelectionControls(groupKey);saveReviewSnapshot();return;}groupKey=target.getAttribute('data-candidate-select-all');if(groupKey){var checked=target.getAttribute('data-clear-indeterminate')==='1'?false:target.checked===true;target.removeAttribute('data-clear-indeterminate');candidateGroupRows(groupKey).forEach(function(row){var id=text(row.id);if(checked)candidateSelectedProducts[id]=true;else delete candidateSelectedProducts[id];});syncCandidateSelectionControls(groupKey);saveReviewSnapshot();}});
    panel.addEventListener('click',function(event){var repair=event.target&&event.target.closest?event.target.closest('[data-candidate-repair-auto]'):null;if(repair){event.preventDefault();event.stopPropagation();runProductAiAutomation('repair','');return;}var button=event.target&&event.target.closest?event.target.closest('[data-candidate-bulk]'):null;if(!button)return;event.preventDefault();event.stopPropagation();runCandidateBulkAction(button.getAttribute('data-candidate-group'),button.getAttribute('data-candidate-bulk'));});
  }
  function wireFrontSelectionControls(){
    if($('allSectionsSelect'))$('allSectionsSelect').addEventListener('change',function(){var checked=$('allSectionsSelect').checked===true;PRODUCT_SECTIONS.forEach(function(section){frontSelectedSections[section.key]=checked;});syncFrontSelectionControls();saveReviewSnapshot();});
    if($('selectedSectionsMatchBtn'))$('selectedSectionsMatchBtn').addEventListener('click',function(){runProductFrontSync('match','sections','','',selectedSectionKeys());});
    if($('allSectionsMatchBtn'))$('allSectionsMatchBtn').addEventListener('click',function(){runProductFrontSync('match','all','','');});
    if($('selectedSectionsUnmatchBtn'))$('selectedSectionsUnmatchBtn').addEventListener('click',function(){runProductFrontSync('unmatch','sections','','',selectedSectionKeys());});
    if($('allSectionsUnmatchBtn'))$('allSectionsUnmatchBtn').addEventListener('click',function(){runProductFrontSync('unmatch','all','','');});
    var panel=$('productResearchPanel');if(!panel)return;
    panel.addEventListener('click',function(event){var selected=event.target&&event.target.closest?event.target.closest('[data-selected-products-front]'):null;if(!selected)return;event.preventDefault();event.stopPropagation();var sectionKey=selected.getAttribute('data-selected-products-front'),operation=selected.getAttribute('data-front-operation')==='unmatch'?'unmatch':'match';runProductFrontSync(operation,'candidates','','',selectedProductIds(sectionKey));});
    panel.addEventListener('change',function(event){var target=event.target;if(!target||!target.getAttribute)return;if(target.hasAttribute('data-section-front-select')){frontSelectedSections[target.value]=target.checked===true;syncFrontSelectionControls();saveReviewSnapshot();return;}if(target.hasAttribute('data-product-front-select')){frontSelectedProducts[target.value]=target.checked===true;syncFrontSelectionControls();saveReviewSnapshot();return;}var sectionKey=target.getAttribute('data-section-products-select-all');if(sectionKey){sectionRows(sectionKey).forEach(function(row){frontSelectedProducts[text(row.id)]=target.checked===true;});syncFrontSelectionControls();saveReviewSnapshot();}});
  }
  async function boot(){
    prepareReviewReturn();wire();wireCandidateBulkControls();wireFrontSelectionControls();if($('runCurrentDiagnosticBtn'))$('runCurrentDiagnosticBtn').addEventListener('click',diagnostic);keepJsonPanelVisible('통합 점검 JSON을 실행하면 이 영역에 요약이 표시되고 전체 원문 다운로드가 활성화됩니다.');
    var restored=hydrateReviewSnapshot();restoreReviewReturn();
    await reloadData(false,restored);
    var dataRestored=restored&&applySessionDataResume();
    if(!dataRestored)await loadScope(restored?'session-resume':'initial');
    if(restored){sessionResumeActive=true;applySessionUiResume();restoreReviewReturn();stateEl.textContent=dataRestored?'관리 작업 범위·원장·화면 위치를 현재 브라우저 세션에서 즉시 복원했습니다. 실제 프론트는 방문자의 접속 IP로 계속 라우팅됩니다.':'관리 범위를 복원하고 최신 원장을 읽었습니다. 실제 프론트는 방문자의 접속 IP로 계속 라우팅됩니다.';saveReviewSnapshot();}
  }
  document.addEventListener('igdc:member-auth-ready',function(){acceptedToken='';acceptedSession=null;if(sessionResumeActive||returnRestoreActive||Date.now()-lastPassiveRestoreAt<15000){ensureSession(false).catch(function(){});return;}reloadData(false).then(function(){loadScope('auth-refresh');});});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
